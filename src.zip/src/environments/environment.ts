
// const Base_URL = 'http://localhost:9090';
const Base_URL = 'http://localhost:8087';

export const environment = { 
    production: false,
    BASE_URL: Base_URL,
};