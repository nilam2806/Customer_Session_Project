// environment.production.ts

const Base_URL = 'http://192.168.97.42:8087';
// const Base_URL = 'http://192.168.97.42:9090';

export const environment = { 
    production: true,
    BASE_URL: Base_URL,
};
