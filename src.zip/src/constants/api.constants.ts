// api.constants.ts

import { environment } from "environments/environment";

export const APP_URL = environment.BASE_URL+'/api/v1';

export const SESSION_URL = APP_URL+'/session';
export const REGISTER_URL = APP_URL+'/users/save';
export const Filter_URL = APP_URL+'/session';
export const get_tags = APP_URL+'/tag/get/';
export const get_all_tags = APP_URL+'/tag/allTags';
export const ALL_SESSION_URL = SESSION_URL+'/sessions';

//get-session-data.service
// export const LOGIN_URL = APP_URL+'/login';
export const LOGIN_URL = APP_URL+'/users/login';
export const ACTIVE_SESSIONS_URL = SESSION_URL+'/activeSessions';
export const ARCHIVED_SESSIONS_URL = SESSION_URL+'/archivedsessions';
export const UPDATE_SESSION_URL = SESSION_URL+'/update';
export const CREATE_SESSION_URL = SESSION_URL+'/create';
export const GET_ALL_CUSTOMERS_URL = APP_URL+'/customers/allCustomers';
export const ARCHIVE_SESSION_URL= SESSION_URL+'/archive/';
export const GET_CUST_DETAIL_BY_ID = APP_URL+'/customers/';

export const CREATE_CUSTOMER_GROUP = APP_URL+'/customerGroup/create';


//manager-customer-group.service
export const GROUP_LIST = APP_URL+'/customerGroup/getGroupList';
export const GET_ALL_CUST = APP_URL+'/customers/allCustomers';
export const UPDATE_GROUP = APP_URL+'/customerGroup/update';
export const GET_BY_NAME = APP_URL+'/customerGroup/getCustomerByGroupName/'; 
export const DELETE_GROUP = APP_URL+'/customerGroup/';
// export const CUST_SESSION_BY_GROUP = APP_URL+ '/customerGroup/getCustomerAndSessionByGroupName/';
export const CUST_SESSION_BY_GROUP = APP_URL+ '/session/groupName/';



export const getSessionDataByCustomerId = Filter_URL+'/customerID/';
export const getSessionDataByCustomerpriority = Filter_URL+'/priorityLevel/';
export const getSessionDataByCustomerpotentiallead = Filter_URL+'/potentialLead/';
export const getCustomersDetailbyName = APP_URL+'/customers/getByName/'; 
export const getSessionDataByDateCritera = Filter_URL+'/session/sessions';




