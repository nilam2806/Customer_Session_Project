import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HomeComponent } from './home.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HomeComponent],
      imports: [RouterTestingModule]
    });
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the HomeComponent', () => {
    expect(component).toBeTruthy();
  });

  it('should have a title', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.navbar-brand').textContent).toContain('Angular App');
  });

  it('should have welcome text', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.welcome-text').textContent).toContain('Welcome To Customer Session Portal');
  });

  it('should have a login button', () => {
    const compiled = fixture.nativeElement;
    const button = compiled.querySelector('.button-container button');
    expect(button).toBeTruthy();
    expect(button.textContent).toContain('Login');
    expect(button.getAttribute('color')).toBe('accent');
    expect(button.getAttribute('routerLink')).toBe('/login');
  });
});