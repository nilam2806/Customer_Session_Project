import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'app/service/loginservice/login.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup | undefined;
  showError: boolean = false;
  loading: boolean = false;
  hidePassword: boolean = true; // Track password visibility
  loggedInUser: string | undefined;
  constructor(
    private service: LoginService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
    this.loggedInUser = localStorage.getItem('loggedInUser');
  }

  submitForm() {
    this.loading = true;
    this.service.login(this.loginForm.value).subscribe(
      (response) => {
        
        if (response.jwt != null) {
          Swal.fire({
            icon: 'success',
            title: 'Login Successful!',
            showConfirmButton: false,
            timer: 1500,
          });
          const jwtToken = response.jwt;
          const loggedInUser = response.loggedInUser;
          localStorage.setItem('jwt', jwtToken);
          localStorage.setItem('loggedInUser', loggedInUser);
          this.loggedInUser = loggedInUser; // Assign loggedInUser here
          this.router.navigateByUrl("/rmdashboard");
        }
      },
      (error) => {
        console.error(error);
        if (error.status === 401 && error.error && error.error.message === 'Invalid credentials') {
          this.showError = true;
          setTimeout(() => {
            this.showError = false;
          }, 5000);
        } else {

          if (error.status === 0 || error.status === 501 || error.status === 502 || error.status === 503) {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Backend server currently is unreachable. Please try again later.',
            });
          } else {
            this.showError = true;
            setTimeout(() => {
              this.showError = false;
            }, 5000);
          }
        }
      }
    ).add(() => {
      this.loading = false;
    });
  }

  togglePasswordVisibility(): void {
    this.hidePassword = !this.hidePassword;
  }
}