import { ComponentFixture, TestBed, waitForAsync, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { LoginComponent } from './login.component';
import { of, throwError } from 'rxjs';
import { LoginService } from 'app/service/loginservice/login.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let loginService: LoginService;
  let httpMock: HttpTestingController;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [LoginComponent],
        imports: [ReactiveFormsModule, RouterTestingModule, HttpClientModule, HttpClientTestingModule],
        providers: [LoginService],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    loginService = TestBed.inject(LoginService);
    httpMock = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the login form with empty fields', () => {
    expect(component.loginForm?.get('email')?.value).toBe('');
    expect(component.loginForm?.get('password')?.value).toBe('');
  });

  it('should mark form as invalid when empty', () => {
    expect(component.loginForm?.valid).toBeFalsy();
  });

  it('should mark form as valid when fields are filled', () => {
    component.loginForm?.patchValue({
      email: 'test@example.com',
      password: 'password123',
    });
    expect(component.loginForm?.valid).toBeTruthy();
  });

  it('should call submitForm method on form submission', () => {
    const submitFormSpy = jest.spyOn(component, 'submitForm');
    const form = fixture.nativeElement.querySelector('form');
    form.dispatchEvent(new Event('ngSubmit'));
    fixture.detectChanges();
    expect(submitFormSpy).toHaveBeenCalled();
  });

  it('should call service login method and navigate on successful login', () => {
    const response = { jwt: 'fakeToken' };
    const loginSpy = jest.spyOn(loginService, 'login').mockReturnValue(of(response));
    const navigateSpy = jest.spyOn((component as any).router, 'navigateByUrl');

    component.loginForm?.patchValue({
      email: 'test@example.com',
      password: 'password123',
    });
    component.submitForm();

    expect(loginSpy).toHaveBeenCalledWith({
      email: 'test@example.com',
      password: 'password123',
    });

    expect(localStorage.getItem('jwt')).toBe('fakeToken');
    expect(navigateSpy).toHaveBeenCalledWith('/rmdashboard');
  });

  it('should display error message for invalid credentials', fakeAsync(() => {
    const errorResponse = { status: 401, error: { message: 'Invalid credentials' } };
    jest.spyOn(loginService, 'login').mockReturnValue(throwError(errorResponse));

    component.loginForm?.patchValue({
      email: 'test@example.com',
      password: 'password123',
    });
    component.submitForm();
    tick();

    expect(component.showError).toBeTruthy();
  }));

  it('should display error message for other errors', fakeAsync(() => {
    const errorResponse = { status: 500 };
    jest.spyOn(loginService, 'login').mockReturnValue(throwError(errorResponse));

    component.loginForm?.patchValue({
      email: 'test@example.com',
      password: 'password123',
    });
    component.submitForm();
    tick();

    expect(component.showError).toBeTruthy();
  }));

  it('should toggle password visibility', () => {
    expect(component.hidePassword).toBeTruthy(); // Initially password is hidden
    component.togglePasswordVisibility();
    expect(component.hidePassword).toBeFalsy(); // Password should be visible after toggle
    component.togglePasswordVisibility();
    expect(component.hidePassword).toBeTruthy(); // Password should be hidden after second toggle
  });

  it('should show error message for invalid email format', () => {
    const emailControl = component.loginForm?.get('email');
    emailControl?.setValue('invalidemail');
    emailControl?.markAsDirty();
    expect(emailControl?.hasError('email')).toBeTruthy();
  });

  it('should show error message for invalid email domain', () => {
    const emailControl = component.loginForm?.get('email');
    emailControl?.setValue('test@invalid.com');
    emailControl?.markAsDirty();
    expect(emailControl?.hasError('invalidDomain')).toBeTruthy();
  });

  it('should hide error message after specified duration', fakeAsync(() => {
    component.showError = true;
    expect(component.showError).toBeTruthy();
    tick(5001);
    expect(component.showError).toBeFalsy();
  }));
  

  
});