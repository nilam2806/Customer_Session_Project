import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EditSessionFormComponent } from './edit-session-form.component';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';

describe('EditSessionFormComponent', () => {
  let component: EditSessionFormComponent;
  let fixture: ComponentFixture<EditSessionFormComponent>;
  let dialogRefMock: Partial<MatDialogRef<EditSessionFormComponent>>;
  let sessionServiceMock: Partial<SessionService>;

  beforeEach(async () => {
    dialogRefMock = {
      close: jest.fn() // Mock the close method
    };

    sessionServiceMock = {
      updateSession: jest.fn().mockReturnValue({ subscribe: jest.fn() }) // Mock the updateSession method
    };

    await TestBed.configureTestingModule({
      declarations: [EditSessionFormComponent],
      imports: [MatDialogModule, HttpClientTestingModule],
      providers: [
        FormBuilder,
        { provide: MatDialogRef, useValue: dialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: SessionService, useValue: sessionServiceMock }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSessionFormComponent);
    component = fixture.componentInstance;
    // Initialize popupForm FormGroup and its controls
    component.popupForm = new FormBuilder().group({
      enableFollowUpOn: new FormControl(false),
      followupOn: new FormControl('')
      // Add other controls as needed
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});