import { Component, Inject, NgModule, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';
import { formatDate } from '@angular/common';
 
@Component({
  selector: 'app-edit-session-form',
  templateUrl: './edit-session-form.component.html',
  styleUrls: ['./edit-session-form.component.css']
})
export class EditSessionFormComponent implements OnInit {
  editSessionForm: FormGroup;
  popupForm: FormGroup;
  enableFollowUpOn: boolean = false;
  checkFolloUp = false;
  isReadonly = true;
  fieldsDisabled: boolean = false;
 
  toggleReadonly() {
    this.isReadonly = !this.isReadonly;
  }
 
 
  constructor(
    private dialogRef: MatDialogRef<EditSessionFormComponent>,
    @Inject(MAT_DIALOG_DATA) public session: any,
    private fb: FormBuilder,
    private sessionService: SessionService // Inject the SessionService
  ) { }
 
 
  updateForm() {
    
  
    // Get the current date in the desired format
    const currentDate = formatDate(new Date(), 'yyyy-MM-dd', 'en-US');
  
    // Combine the current date with the existing remarks
    const updatedRemarks = `${currentDate}: ${this.popupForm.value.remarks}`;
  
    
  
    var updatedData: any;
    if (this.popupForm.value.remarks === "") {
      updatedData = {
        sessionId: this.popupForm.value.sessionId,
        sessionName: this.popupForm.value.sessionName,
        potentialLead: this.popupForm.value.potentialLead,
        priorityLevel: this.popupForm.value.priorityLevel,
        followupOn: this.popupForm.value.followupOn,
      };
    } else {
      updatedData = {
        sessionId: this.popupForm.value.sessionId,
        sessionName: this.popupForm.value.sessionName,
        potentialLead: this.popupForm.value.potentialLead,
        priorityLevel: this.popupForm.value.priorityLevel,
        followupOn: this.popupForm.value.followupOn,
        remarks: [{ remark: updatedRemarks }],
      };
    }
  
    this.sessionService.updateSession(updatedData).subscribe(res => {
      
      
      window.location.reload();
    });
  }
  
 
  ngOnInit(): void {
    this.initForm();
    
    this.popupForm = this.fb.group({
 
      customerName: [this.session.customerName], // Assuming you have a customerName field in your session object
      sessionName: [this.session.sessionName], // Set sessionName to the value from the session object
      followupOn: [this.session.followupOn, Validators.required], // Set followupOn to the value from the session object and make it required
      potentialLead: [this.session.potentialLead], // Set potentialLead to the value from the session object
      priorityLevel: [this.session.priorityLevel], // Set priorityLevel to the value from the session object
      // Add other form controls as needed
      modifiedBy: [''],
      wealthMode: [{value: '', disabled: true}],
      financialGoal: [{value: '', disabled: true}],
      createdOn: [''],
      preferredProduct: [{value: '', disabled: true}],
      customerId: [''],
      isActive: [''],
      sessionId: [''],
      remarks: ['']
    });
    let remk = this.session.remarks;
    this.session.remarks = "";
    this.popupForm.patchValue(this.session);
    this.session.remarks = remk;
    
    
  }
 
  private initForm(): void {
    this.editSessionForm = this.fb.group({
      potentialLead: [this.session.potentialLead === 'YES' ? 'Yes' : 'No', Validators.required],
      priorityLevel: [this.session.PriorityLevel, Validators.required],
      preferredProduct: [this.session.preferredProduct, Validators.required],
    });
  }
 
  saveChanges(): void {
    if (this.editSessionForm.valid) {
      const updatedSessionData = {
        sessionId: this.session.sessionId,
        sessionName: this.editSessionForm.value.customerName,
        priorityLevel: this.editSessionForm.value.priority,
        potentialLead: this.editSessionForm.value.potentialLead === 'Yes' ? 'YES' : 'NO',
        preferredProduct: this.editSessionForm.value.preferredProduct,
      };
 
      this.sessionService.updateSession(updatedSessionData).subscribe(
        (response) => {
          
          this.dialogRef.close(response);
        },
        (error) => {
          console.error('Error updating session:', error);
        }
      );
    }
  }
 
  toggleFollowUp(): void {
    this.enableFollowUpOn = !this.enableFollowUpOn;
    const followupOnControl = this.popupForm.get('followupOn');
    if (followupOnControl) {
      if (this.enableFollowUpOn) {
        followupOnControl.enable();
      } else {
      }
    }
  }
 
  toggleFollowUp1(){
    this.checkFolloUp = !this.checkFolloUp;
  }
 
  closeForm(): void {
    this.dialogRef.close();
  }
 
  onSave(): void {
    this.dialogRef.close(true);
  }
 
 
  private updateEnableFollowUpOn(): void {
    const followupOnControl = this.popupForm.get('followupOn');
    if (followupOnControl && followupOnControl.value) {
      this.enableFollowUpOn = true;
      followupOnControl.enable();
    } else {
      this.enableFollowUpOn = false;
      followupOnControl.disable();
    }
  }
}