import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-view-session-details',
  templateUrl: './view-session-details.component.html',
  styleUrls: ['./view-session-details.component.css']
})
export class SessionDetailsModalComponent {

  editedSession: any;
  fieldsDisabled: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<SessionDetailsModalComponent>,
    @Inject(MAT_DIALOG_DATA) public session: any,
  ) {}

  closeModal(): void {
    this.dialogRef.close();
  }
}