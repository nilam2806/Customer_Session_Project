import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SessionDetailsModalComponent } from './view-session-details.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule
import { HttpClientModule } from '@angular/common/http';

describe('SessionDetailsModalComponent', () => {
  let component: SessionDetailsModalComponent;
  let fixture: ComponentFixture<SessionDetailsModalComponent>;
  let dialogRefMock: Partial<MatDialogRef<SessionDetailsModalComponent>>;

  beforeEach(async () => {
    dialogRefMock = {
      close: jest.fn()
    };

    await TestBed.configureTestingModule({
      declarations: [SessionDetailsModalComponent],
      providers: [
        { provide: MatDialogRef, useValue: dialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ],
      imports: [ReactiveFormsModule, HttpClientModule], // Import ReactiveFormsModule here
    }).compileComponents(); // Note: Use async beforeEach with compileComponents

    fixture = TestBed.createComponent(SessionDetailsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});