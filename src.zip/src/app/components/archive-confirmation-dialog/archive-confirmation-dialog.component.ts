
import { Component, Inject } from '@angular/core';

import {  MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-archive-confirmation-dialog',
  templateUrl: './archive-confirmation-dialog.component.html',
  styleUrls: ['./archive-confirmation-dialog.component.css']
})
export class ArchiveConfirmationDialogComponent {
  sessionName: string;

  constructor(
    public dialogRef: MatDialogRef<ArchiveConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.sessionName = data.sessionName;
  }

  onCancelClick(): void {
    this.dialogRef.close(false);
  }

  onArchiveClick(): void {
    this.dialogRef.close(true);
  }
}
