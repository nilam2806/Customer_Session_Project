import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ArchiveConfirmationDialogComponent } from './archive-confirmation-dialog.component';
import { MatDialogModule } from '@angular/material/dialog';

describe('ArchiveConfirmationDialogComponent', () => {
  let component: ArchiveConfirmationDialogComponent;
  let fixture: ComponentFixture<ArchiveConfirmationDialogComponent>;
  let matDialogRefMock: MatDialogRef<ArchiveConfirmationDialogComponent>;

  beforeEach(async () => {
    matDialogRefMock = {
      close: jest.fn(),
    } as any;

    await TestBed.configureTestingModule({
      declarations: [ArchiveConfirmationDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: matDialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: { sessionName: 'Test Session' } },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArchiveConfirmationDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: {} }  // Provide a mock value for MAT_DIALOG_DATA
      ]
    });
    fixture = TestBed.createComponent(ArchiveConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
