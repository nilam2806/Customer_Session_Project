import { Component, Inject } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms'; // Import Validators
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatNativeDateModule } from '@angular/material/core'; // Import the DateAdapter module you want to use (in this case, MatNativeDateModule)
import { MatCheckboxChange } from '@angular/material/checkbox';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';
import Swal from 'sweetalert2';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-createsession',
  templateUrl: './createsession.component.html',
  styleUrls: ['./createsession.component.css']
})
export class CreatesessionComponent {

  createSessionForm: FormGroup;
  customerIds: number[] = [];
  selectedCustomerDetails: any | null = null;
  maxDate: Date;
  formattedFollowUpDate: string | null = null;
  selectedDate: Date;
  potentialLeadOptions = ['YES', 'NO'];
  priorityOptions = ['HIGH', 'MEDIUM', 'LOW'];
  enableFollowUp: boolean = false;
  fieldsDisabled: boolean = true;

  onCheckboxChange(event: MatCheckboxChange): void {
    this.enableFollowUp = event.checked;
    if (!this.enableFollowUp) {
      this.createSessionForm.patchValue({ followupOn: null });
    }
  }

  constructor(
    public dialogRef: MatDialogRef<CreatesessionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private formBuilder: FormBuilder,
    private sessionService: SessionService
  ) {
    this.createSessionForm = this.formBuilder.group({
      customerId: ['', Validators.required],
      sessionName: ['', [Validators.required, this.validateSessionName.bind(this)]],
      followupOn: [null],
      potentialLead: ['', Validators.required],
      priorityLevel: ['', Validators.required],
      remarks: this.formBuilder.array(['']),
      tags: this.formBuilder.array(['']),
    });

    this.maxDate = this.getMaxDate();
    this.loadCustomerIds();
  }

  loadCustomerIds() {
    this.sessionService.getAllCustomerIds().subscribe(
      (ids) => {
        this.customerIds = ids;
      },
      (error) => {
        console.error('Error fetching customer IDs', error);
      }
    );
  }

  onCustomerIdChange() {
    const selectedCustomerId = this.createSessionForm.get('customerId')?.value;

    if (selectedCustomerId) {
      this.sessionService.getCustomerDetailsById(selectedCustomerId).subscribe(
        (customerDetails) => {
          this.selectedCustomerDetails = customerDetails;
          this.createSessionForm.patchValue({
            customerName: customerDetails.customerName,
          });
        },
        (error) => {
          console.error('Error fetching customer details', error);
        }
      );
    } else {
      this.selectedCustomerDetails = null;
    }
  }

  onDateInput(event: MatDatepickerInputEvent<Date>): void {
    const inputDate = event.value;

    if (inputDate instanceof Date && !isNaN(inputDate.getTime())) {
      const formattedDate = this.formatDate(inputDate);

      if (formattedDate) {
        this.createSessionForm.patchValue({ followupOn: formattedDate });
        this.selectedDate = inputDate;
      } else {
        this.createSessionForm.patchValue({ followupOn: null });
      }
    } else {
      this.createSessionForm.patchValue({ followupOn: null });
    }
  }

  onSaveClick(): void {
    const sessionData = this.createSessionForm.value;
    const currentDate = formatDate(new Date(), 'yyyy-MM-dd', 'en-US');
    sessionData.remarks = sessionData.remarks.map((remark: string) => `${currentDate}: ${remark}`);
    sessionData.remarks = sessionData.remarks.map((remark: string) => ({ remark }));
    sessionData.tags = sessionData.tags.map((tagName: string) => ({ tagName }));
    if (this.selectedDate) {
      const formattedDate = this.formatDate(this.selectedDate);
      sessionData.followupOn = formattedDate;
    }

    if (this.createSessionForm.valid) {
      
      this.sessionService.createSession(sessionData).subscribe(
        (response) => {
          
          Swal.fire({
            icon: 'success',
            title: 'Great',
            text: 'Session Created Successfully',
          });
          window.location.reload();

          this.dialogRef.close();
        },
        (error) => {
          console.error('Error creating session:', error);
          if (error.status === 400) {
            alert('Validation failed. Please check your input.');
          } else {
            alert('An error occurred while creating the session. Please try again later.');
          }
        }
      );
    } else {
      
      Object.keys(this.createSessionForm.controls).forEach((controlName) => {
        
      });

      alert('Validation failed. Please check your input.');
    }
  }


  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  getMaxDate(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), today.getDate() + 30);
  }

  getMinDate(): Date {
    return new Date(); // Set the minimum date to today
  }

  dateFilter = (date: Date | null): boolean => {
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() - 1); // Set to yesterday to allow today
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 30); // Add 30 days to today
    return date >= currentDate && date <= futureDate;
  };

  get tagsArray(): FormArray {
    return this.createSessionForm.get('tags') as FormArray;
  }

  getTagControl(index: number): FormControl {
    return this.tagsArray.at(index) as FormControl;
  }

  get remarksArray(): FormArray {
    return this.createSessionForm.get('remarks') as FormArray;
  }

  getRemarkControl(index: number): FormControl {
    return this.remarksArray.at(index) as FormControl;
  }

  onCloseClick(): void {
    this.dialogRef.close();
  }

  validateSessionName(control: FormControl): { [key: string]: any } | null {
    const value = control.value;
    const forbidden = /[^\w\s]/.test(value);
    const minLength = value.length < 4;

    if (forbidden && minLength) {
      return {
        'forbiddenName': true,
        'minLength': true
      };
    } else if (forbidden) {
      return {
        'forbiddenName': true
      };
    } else if (minLength) {
      return {
        'minLength': true
      };
    }

    return null;
  }
}