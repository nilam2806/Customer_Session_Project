import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule
import { CreatesessionComponent } from './createsession.component';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

describe('CreatesessionComponent', () => {
  let fixture: ComponentFixture<CreatesessionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CreatesessionComponent],
      imports: [MatDialogModule, HttpClientModule], // Add HttpClientModule to imports
      providers: [
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: {} }// Provide a mock value for MatDialogRef
      ]
    
    });
    fixture = TestBed.createComponent(CreatesessionComponent);
    fixture.detectChanges();
  });

  it('should create', () => {
    const component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });
});