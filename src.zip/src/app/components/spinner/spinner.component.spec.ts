import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { SpinnerComponent } from './spinner.component';
import { LoaderService } from 'app/service/loaderservice/loader.service';

describe('SpinnerComponent', () => {
  let component: SpinnerComponent;
  let fixture: ComponentFixture<SpinnerComponent>;

  // Mock LoaderService
  class MockLoaderService {
    getLoading() {
      // Mock implementation, return true or false as needed for your tests
      return true; // or false
    }
  }

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [SpinnerComponent],
      providers: [
        { provide: LoaderService, useClass: MockLoaderService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display spinner when loader service returns loading state', () => {
    // Mock loader service returning loading state
    jest.spyOn(component.loader, 'getLoading').mockReturnValue(true);
    fixture.detectChanges();
    setTimeout(() => {
      const spinnerElement = fixture.nativeElement.querySelector('.cssload-container');
      expect(spinnerElement).toBeTruthy();
    });
  });
});