import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA, Inject, ViewChild, ElementRef } from '@angular/core';
import { MatDrawer } from '@angular/material/sidenav';
import { CustomerGroup, CustomerGroupService } from 'app/service/CustomerGroup/customer-group-service.service';
import { Subscription } from 'rxjs';
import { DatePipe, formatDate } from '@angular/common';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';
import { Customer } from 'app/interface/Customer';
 
 
@Component({
  selector: 'app-filter-dialog',
  templateUrl: './filter-dialog.component.html',
  styleUrls: ['./filter-dialog.component.css']
})
export class FilterDialogComponent {
 
  selectedFollowUpDate: Date;

 
  @ViewChild('tagsDrawer') tagsDrawer: MatDrawer;
  @ViewChild('customerNameDrawer') customerNameDrawer: MatDrawer;
  @ViewChild('searchInput') searchInput: ElementRef;
  @ViewChild('potentialLeadSubMenu') potentialLeadSubMenu: MatDrawer;
  @ViewChild('updatedOnDrawer') updatedOnDrawer: MatDrawer;
  @ViewChild('prioritySubMenu') prioritySubMenu: MatDrawer;  
  @ViewChild('createdOnDrawer') createdOnDrawer: MatDrawer;
  @ViewChild('followUpOnDrawer') followUpOnDrawer: MatDrawer;
 
 
  showPotentialLeadSubMenu: boolean = false;
  selectedPotentialLead: string = ''; // Initialize with an empty string
  selectedPriority: string = ''; // Initialize with an empty string
  customers  : Customer [];
  customerList : Customer[]; //
  selectedFilter:any=[{}];
  tags :string [] ;
  tagsList : string []
  data:any[] ;
  subscription: Subscription;
  searchValue: string = '';
  filteredTags: string[] = [];
  filteredCustomers: Customer[] = [];
 
  constructor(
    private sessionservice: SessionService,
    private customerGroupService: CustomerGroupService,
    public dialogRef:MatDialogRef<FilterDialogComponent>,private datePipe: DatePipe
 
  ) {
    this.customerList = this.customers;
    this.tagsList = this.tags
 
   }
  toggleUpdatedOnDrawer(): void {
    this.resetDrawer();
    this.updatedOnDrawer.toggle();
    
  }
 
  toggleCreatedOnDrawer(): void {
    this.resetDrawer();
    this.createdOnDrawer.toggle();
    
  }
 
  toggleFollowUpOnDrawer(): void {
      this.resetDrawer();
         this.followUpOnDrawer.toggle();
         
  }
 
  toggleTagsDrawer(): void {
    this.resetDrawer();
    this.tagsDrawer.toggle();
    this.hidePotentialLeadSubMenu();
  }

  resetDrawer(){
    this.updatedOnDrawer.close();
    this.createdOnDrawer.close();
    this.followUpOnDrawer.close();
    this.tagsDrawer.close();
    this.customerNameDrawer.close();
    this.potentialLeadSubMenu.close();
    this.prioritySubMenu.close();
   
  }
  

filterTags(): void {
  
  if (this.searchValue.trim() === '') {
    this.filteredTags = this.tagsList;
  } else {
    this.filteredTags = this.tagsList.filter(tag =>
      tag.toLowerCase().includes(this.searchValue.toLowerCase())
    );
  }
  
}


filterCustomers(): void {
  
  if (this.searchValue.trim() === '') {
      this.filteredCustomers = this.customerList;
  } else {
      this.filteredCustomers = this.customerList.filter(customer =>
          customer.customerName.toLowerCase().includes(this.searchValue.toLowerCase()) ||
          customer.customerId.toString().includes(this.searchValue.toLowerCase())
      );
  }
  
}

isSelected(tag: string): boolean {
  return (this.selectedFilter['tag'] ?? []).includes(tag);
}

  setCustomerId(customerId: any){
    this.selectedFilter['customerId'] = customerId;
  }
 

  setTagName(tag: string): void {
    const isSelected = this.isSelected(tag);
    if (!isSelected) {
      this.selectedFilter['tag'] = [tag]; // Select only the clicked tag
    } 
    else {
      this.selectedFilter['tag'] = []; // Deselect the tag
    }
  }
  
 
  setPriorityLevel(priorityLevel:string){
    this.selectedFilter['priorityLevel'] = priorityLevel;
 
    
  }
 
  setPotentialLead(potentialLead:any){
    this.selectedFilter['potentialLead'] = potentialLead;
 
    
  }
 
  getCustomers(): void {
    this.customerGroupService.getAllCustomersDetails().subscribe(
      tempCustomers =>{
        this.customers = tempCustomers;
        this.customerList = this.customers;
        this.filteredCustomers = this.customerList;
      }
    );
  }
 
  
  getDistinctTags(): void {
    this.customerGroupService.getAllTags().subscribe(
      tags => {
        this.tagsList = tags;
        this.filteredTags = this.tagsList; // Initialize filtered tags
      }
    );
    }

  searchTags(): void {
    if (!this.searchValue.trim()) {
      this.filteredTags = this.tagsList; // Reset filtered tags if search is empty
    } else {
      this.filteredTags = this.tagsList.filter(tag =>
        tag.toLowerCase().includes(this.searchValue.toLowerCase())
      ); // Filter tags based on search value
    }
  }

 
  applyFilter(): void {
    
    if (this.selectedFilter['customerId'] != null) {
        this.sessionservice.getSessionDataByCustomerId(this.selectedFilter['customerId']).subscribe(data => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['tag'] != null) {
        this.sessionservice.getFilteredDataByTags(this.selectedFilter['tag']).subscribe((data) => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['priorityLevel'] != null) {
        this.sessionservice.getSessionDataByPriorityLevel(this.selectedFilter['priorityLevel']).subscribe((data) => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['createdOn'] != null) {
        this.sessionservice.getSessionDataByCreatedDate(this.selectedFilter['createdOn']).subscribe(data => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['followUpOn'] != null) {
        this.sessionservice.getSessionDataByFollowUpDate(this.selectedFilter['followUpOn']).subscribe(data => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['updated_On'] != null) {
        this.sessionservice.getSessionDateBymodifiedDate(this.selectedFilter['updated_On']).subscribe(data => {
            
            this.dialogRef.close(data);
        });
    }

    if (this.selectedFilter['potentialLead'] != null) {
        this.sessionservice.getSessionDataByPotentialLead(this.selectedFilter['potentialLead']).subscribe((data) => {
            
            this.dialogRef.close(data);
        });
    }
}

 
 
  toggleCustomerNameDrawer(): void {
    this.resetDrawer();
    this.customerNameDrawer.toggle();
    this.hidePotentialLeadSubMenu();
    if (this.customerNameDrawer.opened) {
      this.searchInput.nativeElement.focus();
    }
  }

 
  hidePotentialLeadSubMenu(): void {
    this.showPotentialLeadSubMenu = false;
  }
  onPotentialLeadSelection(value: string): void {
    this.selectedPotentialLead = value;
  }
 
  togglePotentialLeadSubMenu(): void {
    this.resetDrawer();
    this.potentialLeadSubMenu.toggle();
  }
 
 
  togglePrioritySubMenu():void{
    this.resetDrawer();
    this.prioritySubMenu.toggle();
  }
 
  onPrioritySelection(priority: string):void{
 
 
    this.selectedPriority = priority;
    this.getDataByPriority();
 
  }
 
    getDataByPriority() {
      if (this.selectedPriority) {
        this.subscription = this.sessionservice.getSessionDataByPriorityLevel(this.selectedPriority)
          .subscribe(data => {
            this.data = data; // Update data with filtered results
          }, error => {
            console.error('Error fetching data:', error);
          });
      } else {
        this.data = []; // Clear data if no priority is selected
      }
    }
    ngOnInit() {
      this.getDistinctTags();
      
    }
    ngOnDestroy() {
      if (this.subscription) {
        this.subscription.unsubscribe();
      }
    }


    setCreatedOnDate(event: any): void {
      const selectedDate: Date = event.value;
      const formattedDate: string = this.datePipe.transform(selectedDate, 'yyyy-MM-dd');
      this.selectedFilter['createdOn'] = formattedDate;
    }
    
    

    setmodifiedDate(event: any):void {
      const selectedDate: Date = event.value;
      const formattedDate: string = this.datePipe.transform(selectedDate, 'yyyy-MM-dd');
      this.selectedFilter['updated_On'] = formattedDate;
    }
 
  
    setFollowUpDate(event: any): void {
      // Event contains the selected date, format it as needed
      const selectedDate: Date = event.value;
      const formattedDate: string = this.datePipe.transform(selectedDate, 'yyyy-MM-dd');
      this.selectedFilter['followUpOn'] = formattedDate;
    }
  
    fetchSessions(): void {
      if (this.selectedFollowUpDate) {
        const formattedDate = this.datePipe.transform(this.selectedFollowUpDate, 'yyyy-MM-dd');
        this.sessionservice.getSessionDataByFollowUpDate(formattedDate).subscribe(
          sessions => {
            
          },
          error => {
            console.error('Error fetching sessions:', error);
          }
        );
      } else {
        console.warn('Follow-up date is not selected.');
      }
    }


    fetchSessions1(): void {
      if (this.selectedFilter['createdOn']) {
        const formattedDate = this.datePipe.transform(this.selectedFilter['createdOn'], 'yyyy-MM-dd');
        this.sessionservice.getSessionDataByCreatedDate(formattedDate).subscribe(
          sessions => {
            
          },
          error => {
            console.error('Error fetching sessions:', error);
          }
        );
      } else {
        console.warn('Created On date is not selected.');
        // Optionally, inform the user to select a Created On date before fetching sessions
      }
    }
    
    fetchSessions2(): void {
      if (this.selectedFilter['updated_On']) {
        const formattedDate = this.datePipe.transform(this.selectedFilter['updated_On'], 'yyyy-MM-dd');
        this.sessionservice.getSessionDateBymodifiedDate(formattedDate).subscribe(
          sessions => {
            
            // Handle sessions data as needed
          },
          error => {
            console.error('Error fetching sessions:', error);
          }
        );
      } else {
        console.warn('updated On date is not selected.');
      }
    }
  }
