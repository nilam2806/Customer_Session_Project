import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'; 
import { ManageCustomerGroupComponent } from './manage-customer-group.component';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { ManageCustomerGroupService, Customer,CustomerGroup } from 'app/service/manage-group/manage-customer-group.service';
import { of, throwError } from 'rxjs';


describe('ManageCustomerGroupComponent', () => {
  let component: ManageCustomerGroupComponent;
  let fixture: ComponentFixture<ManageCustomerGroupComponent>;
  let manageCustomerGroupService: ManageCustomerGroupService;
  let service: ManageCustomerGroupService;
  let httpTestingController: HttpTestingController;
  let dialog: MatDialog;
 
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManageCustomerGroupComponent],
      imports: [MatDialogModule, HttpClientTestingModule],
      providers: [
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        
        ManageCustomerGroupService
      ]
    });
    TestBed.overrideProvider(MatDialog, { useValue: {} });
    fixture = TestBed.createComponent(ManageCustomerGroupComponent);
    component = fixture.componentInstance;
    manageCustomerGroupService = TestBed.inject(ManageCustomerGroupService);
    dialog = TestBed.inject(MatDialog);
    httpTestingController = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
  });


  // afterEach(() => {
  //   httpTestingController.verify();
  // });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
 
  it('should fetch group list on initialization', () => {
    const mockGroups: CustomerGroup[] = [{ groupId: 1, groupName: 'Group 1', customers: [] }];
    jest.spyOn(manageCustomerGroupService, 'getGroupList').mockReturnValue(of(mockGroups));

    component.ngOnInit();

    expect(component.filteredCustomerGroups).toEqual(mockGroups);
  });

  it('should filter customers based on search text', () => {
    const mockCustomers: Customer[] = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 2, customerName: 'Jane Smith', customerEmail: 'jane@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    component.customers = mockCustomers;

    component.searchText = 'John';
    component.filterCustomers();

    expect(component.filteredCustomers.length).toBe(1);
    expect(component.filteredCustomers[0].customerName).toBe('John Doe');
  });

  it('should remove selected customer', () => {
    const selectedCustomer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.selectedCustomers = [selectedCustomer];
    component.customers = [selectedCustomer]; // For restoration after removal

    component.removeSelectedCustomer(selectedCustomer);

    expect(component.selectedCustomers.length).toBe(0);
    //expect(component.customers.length).toBe(1);
  });

  it('should add selected customer', () => {
    const selectedCustomer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.filteredCustomers = [selectedCustomer];
    const originalLength = component.selectedCustomers.length;

    // component.moveToSelectedUsers(selectedCustomer);

    expect(component.selectedCustomers.length).toBe(originalLength + 1);
     expect(component.filteredCustomers.length).toBe(0);
  });

  it('should open edit customer group popup', () => {
    component.showEditPopup = false;
    component.showManageCustomerGroup = true;

    component.openEditCustomerGroupPopup();

    expect(component.showEditPopup).toBe(true);
    expect(component.showManageCustomerGroup).toBe(false);
  });

  it('should close edit customer group popup', () => {
    component.showEditPopup = true;
    component.showManageCustomerGroup = false;

    component.closeEditPopup();

    expect(component.showEditPopup).toBe(false);
    expect(component.showManageCustomerGroup).toBe(true);
  });

  it('should validate input for selected customer group', () => {
    component.selectedCustomerGroupDetails = { groupName: 'Group Name' };
    component.selectedCustomerGroup = '';

    component.validateInput();

    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name cannot be blank.');
  });

  
  it('should not remove selected customer if not present', () => {
    // Arrange
    const selectedCustomer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.selectedCustomers = [selectedCustomer];
    component.customers = []; // Empty array, simulating no customers
  
    // Act
    component.removeSelectedCustomer(selectedCustomer);
  
    // Assert
    expect(component.selectedCustomers.length).toBe(0);

    //expect(component.selectedCustomers.length).toBe(1); // Ensure selectedCustomers array remains unchanged
  });
  
  it('should not add selected customer if already present', () => {
    // Arrange
    const selectedCustomer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.filteredCustomers = [selectedCustomer];
    component.selectedCustomers = [selectedCustomer]; // Selected customer already present
  
    // Act
    // component.moveToSelectedUsers(selectedCustomer);
  
    // Assert
    expect(component.selectedCustomers.length).toBe(1); // Ensure selectedCustomers array remains unchanged
  });
  
  it('should return true if selectedCustomerGroup is falsy', () => {
    // Arrange
    component.selectedCustomerGroup = null; // Falsy value
  
    // Act
    const result = component.isEditButtonDisabled();
  
    // Assert
    expect(result).toBe(true);
  });
  
  it('should return false if selectedCustomerGroup is truthy', () => {
    // Arrange
    component.selectedCustomerGroup = 'Group 1'; // Truthy value
  
    // Act
    const result = component.isEditButtonDisabled();
  
    // Assert
    expect(result).toBe(false);
  });


  it('should filter customers when search text is empty', () => {
    // Arrange
    component.customers = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 2, customerName: 'Jane Smith', customerEmail: 'jane@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 3, customerName: 'Alice', customerEmail: 'alice@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 4, customerName: 'Bob', customerEmail: 'bob@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    component.selectedCustomers = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    component.searchText = '';

    // Act
    component.filterCustomers();

    // Assert
    expect(component.filteredCustomers.length).toBe(3); // Expecting 3 customers after filtering
    expect(component.filteredCustomers.map(cust => cust.customerId)).toEqual([2, 3, 4]); // Expecting customer IDs 2, 3, 4
  });

  it('should filter customers based on search text', () => {
    // Arrange
    component.customers = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 2, customerName: 'Jane Smith', customerEmail: 'jane@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 3, customerName: 'Alice', customerEmail: 'alice@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 4, customerName: 'Bob', customerEmail: 'bob@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    component.selectedCustomers = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    component.searchText = 'Jane';

    // Act
    component.filterCustomers();

    // Assert
    expect(component.filteredCustomers.length).toBe(1); // Expecting 1 customer after filtering
    expect(component.filteredCustomers[0].customerName).toBe('Jane Smith'); // Expecting Jane Smith as the filtered customer
  });
  it('should handle error when fetching group list', () => {
    // Arrange
    jest.spyOn(manageCustomerGroupService, 'getGroupList').mockReturnValue(throwError('Error'));

    // Act
    component.ngOnInit();

    // Assert
    expect(component.errorFetchingGroups).toBe(true);
  });
  it('should handle error when fetching group list', () => {
    // Arrange
    jest.spyOn(manageCustomerGroupService, 'getGroupList').mockReturnValue(throwError('Error'));

    // Act
    component.ngOnInit();

    // Assert
    expect(component.errorFetchingGroups).toBe(true);
  });
  
  it('should handle image click', () => {
    // Arrange
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
  
    // Act
    component.handleImageClick();
  
    // Assert
    expect(consoleSpy).toHaveBeenCalledWith('Image clicked!');
    
    // Clean up
    consoleSpy.mockRestore(); // Restore the original 
  });

  it('should set customers and filteredCustomers on successful response', () => {
    // Arrange
    const mockCustomers: Customer[] = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 2, customerName: 'Jane Smith', customerEmail: 'jane@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    jest.spyOn(manageCustomerGroupService, 'getAllCustomers').mockReturnValue(of(mockCustomers));
  
    // Act
    component.getAllCustomers();
  
    // Assert
    expect(component.customers).toEqual(mockCustomers);
    expect(component.filteredCustomers).toEqual(mockCustomers);
  });
  
  it('should log error message on error response', () => {
    // Arrange
    const errorMessage = 'Error fetching customers';
    jest.spyOn(console, 'error').mockImplementation();
    jest.spyOn(manageCustomerGroupService, 'getAllCustomers').mockReturnValue(throwError(errorMessage));
  
    // Act
    component.getAllCustomers();
  
    // Assert
    expect(console.error).toHaveBeenCalledWith('Error fetching customers:', errorMessage);
  });
  it('should set isValid to false and errorMessage for group name containing symbols in the first four characters', () => {
    // Arrange
    component.selectedCustomerGroup = '##Group';
    
    // Act
    component.validateInput();
    
    // Assert
    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name cannot contain symbols in the first four characters.');
  });
  
  it('should set isValid to false and errorMessage for group name less than 4 characters long', () => {
    // Arrange
    component.selectedCustomerGroup = 'Grp';
    
    // Act
    component.validateInput();
    
    // Assert
    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name must be at least 4 characters long.');
  });


  it('should set isValid to true and errorMessage to an empty string when input is valid', () => {
    // Arrange
    component.selectedCustomerGroup = 'ValidGroupName'; // Provide a valid group name
    
    // Act
    component.validateInput();
    
    // Assert
    expect(component.isValid).toBe(true);
    expect(component.errorMessage).toBe('');
  });

  
  
  it('should return true if searchText matches customer name', () => {
    // Arrange
    component.searchText = 'John'; // Set searchText to match customer name
    const customer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    
    // Act
    const result = component.isCustomerHighlighted(customer);
    
    // Assert
    expect(result).toBe(true);
  });
  
  it('should return false if searchText does not match customer name', () => {
    // Arrange
    component.searchText = 'Jane'; // Set searchText to not match customer name
    const customer: Customer = { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    
    // Act
    const result = component.isCustomerHighlighted(customer);
    
    // Assert
    expect(result).toBe(false);
  });


  it('should toggle the dropdownOpen property and log its value', () => {
    // Arrange
    const initialDropdownState = component.dropdownOpen;
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(); // Spy on 
    
    // Act
    component.toggleDropdown();
    
    // Assert
    expect(component.dropdownOpen).toBe(!initialDropdownState); // Check if dropdownOpen property toggled
    expect(consoleSpy).toHaveBeenCalledWith('Dropdown Open:', component.dropdownOpen); // Check if 
    
    // Clean up
    consoleSpy.mockRestore(); // Restore the original 
  });

  it('should update filteredCustomerGroups based on searchText', () => {
    // Arrange
    const searchText = 'Group'; // Define a search text
    component.customerGroups = [
      { id: 1, name: 'Group 1' },
      { id: 2, name: 'Group 2' },
      { id: 3, name: 'Team A' }
    ]; // Set up customerGroups array
    
    // Act
    component.searchText = searchText; // Set the searchText
    component.updateFilteredCustomerGroups(); // Call the method
    
    // Assert
    // Expecting filteredCustomerGroups to contain groups whose names include the searchText 'Group'
    expect(component.filteredCustomerGroups).toEqual([
      { id: 1, name: 'Group 1' },
      { id: 2, name: 'Group 2' }
    ]);
  });


  it('should log the selected customer group for deletion', () => {
    // Arrange
    const selectedCustomerGroup = 'Group 1';
    component.selectedCustomerGroup = selectedCustomerGroup;
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(); // Spy on 
    
    // Act
    component.deleteCustomerGroup();
    
    // Assert
    expect(consoleSpy).toHaveBeenCalledWith('Deleting Customer Group:', selectedCustomerGroup); // Check if 
    expect(consoleSpy).toHaveBeenCalledTimes(1); // Ensure 
    
    // Clean up
    consoleSpy.mockRestore(); // Restore the original 
  });
   

  it('should handle successful response when fetching customers by group name', () => {
    // Arrange
    const groupName = 'Test Group';
    const mockCustomers: Customer[] = [
      { customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' },
      { customerId: 2, customerName: 'Jane Smith', customerEmail: 'jane@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }
    ];
    const responseMock = [{ customers: mockCustomers }];

    jest.spyOn(manageCustomerGroupService, 'getCustomersByGroupName').mockReturnValue(of(responseMock));

    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    // Act
    component.getCustomersByGroupName(groupName);

    // Assert
    expect(consoleLogSpy).toHaveBeenCalledWith('Customers for group', groupName, ':', mockCustomers);
  });

  // it('should call validateInput method', () => {
  //   // Arrange
  //   const validateInputSpy = jest.spyOn(component, 'validateInput').mockReturnValue();

  //   // Act
  //   component.updateCustomerGroup();

  //   // Assert
  //   expect(validateInputSpy).toHaveBeenCalled();
  // });

  // it('should log an error message if input validation fails', () => {
  //   // Arrange
  //   jest.spyOn(component, 'validateInput').mockImplementation(() => {
  //     component.isValid = false;
  //     component.errorMessage = 'Invalid input';
  //   });
  //   const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

  //   // Act
  //   component.updateCustomerGroup();

  //   // Assert
  //   expect(consoleErrorSpy).toHaveBeenCalledWith('Input is not valid');
  // });

  // it('should log an error message if no group is selected', () => {
  //   // Arrange
  //   jest.spyOn(component, 'validateInput').mockReturnValue();
  //   component.selectedCustomerGroupId = null;
  //   const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

  //   // Act
  //   component.updateCustomerGroup();

  //   // Assert
  //   expect(consoleErrorSpy).toHaveBeenCalledWith('No group selected');
  // });

  // it('should log an error message if no customers are selected', () => {
  //   // Arrange
  //   jest.spyOn(component, 'validateInput').mockReturnValue();
  //   component.selectedCustomerGroupId = 1; // Assuming group is selected
  //   component.selectedCustomers = [];
  //   const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

  //   // Act
  //   component.updateCustomerGroup();

  //   // Assert
  //   expect(consoleErrorSpy).toHaveBeenCalledWith('No customers selected');
  // });

  
  
  it('should call validateInput method', () => {
    // Arrange
    const validateInputSpy = jest.spyOn(component, 'validateInput').mockReturnValue();

    // Act
    component.updateCustomerGroup();

    // Assert
    expect(validateInputSpy).toHaveBeenCalled();
});

it('should log an error message if input validation fails', () => {
    // Arrange
    jest.spyOn(component, 'validateInput').mockImplementation(() => {
        component.isValid = false;
        component.errorMessage = 'Invalid input';
    });
    const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

    // Act
    component.updateCustomerGroup();

    // Assert
    expect(consoleErrorSpy).toHaveBeenCalledWith('Input is not valid');
});

it('should log an error message if no group is selected', () => {
    // Arrange
    jest.spyOn(component, 'validateInput').mockReturnValue();
    component.selectedCustomerGroupId = null;
    const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

    // Act
    component.updateCustomerGroup();

    // Assert
    expect(consoleErrorSpy).toHaveBeenCalledWith('No group selected');
});

it('should log an error message if no customers are selected', () => {
    // Arrange
    jest.spyOn(component, 'validateInput').mockReturnValue();
    component.selectedCustomerGroupId = 1; // Assuming group is selected
    component.selectedCustomers = [];
    const consoleErrorSpy = jest.spyOn(console, 'error').mockReturnValue();

    // Act
    component.updateCustomerGroup();

    // Assert
    expect(consoleErrorSpy).toHaveBeenCalledWith('No customers selected');
});

// Test for successful update
it('should log success message on successful update', () => {
  // Arrange
  jest.spyOn(component, 'validateInput').mockReturnValue();
  component.selectedCustomerGroupId = 1; // Assuming group is selected
  component.selectedCustomers = [{ customerId: 1, customerName: 'John Doe', customerEmail: 'john@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' }];
  const consoleLogSpy = jest.spyOn(console, 'log').mockReturnValue();
  const updateData = {}; // Define update data

  // Act
  component.updateCustomerGroup();

  // Assert
  expect(consoleLogSpy).toHaveBeenCalledWith('Customer group updated successfully:', component.selectedCustomerGroup);
});


});


