import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';
import { ManageCustomerGroupService } from 'app/service/manage-group/manage-customer-group.service';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2';

interface Customer {
  customerId: number;
  customerName: string;
  customerEmail: string;
  wealthMode: string;
  preferredProduct: string;
  financialGoal: string;
}

interface Group {
  groupId: number;
  groupName: string;
  customers: Customer[];
}

@Component({
  selector: 'app-manage-customer-group',
  templateUrl: './manage-customer-group.component.html',
  styleUrls: ['./manage-customer-group.component.css']
})
export class ManageCustomerGroupComponent implements OnInit {

  customerGroups: any[] = [];
  dropdownOpen: boolean = false;

  searchText: string = '';
  searchVisible: boolean = false;
  editDisabled: boolean = true;
  deleteDisabled: boolean = true;

  isMouseoverEdit: boolean = false;
  isMouseoverDelete: boolean = false;

  groupIDMap: { [groupName: string]: number } = {};

  selectedCustomerGroup: string = '';
  filteredCustomerGroups: any[] = [];
  filteredCustomers: Customer[] = [];
  showEditPopup: boolean = false;
  selectedCustomerGroupName: any;
  selectedCustomerGroupDetails: any;
  customers: Customer[] = [];
  selectedCustomers: Customer[] = [];
  editPopupOpen: boolean = false;
  showManageCustomerGroup: boolean = true;
  selectedGroupName: string = 'Select a customer group';
  selectedCustomerGroupId: number;

  count: number = 0;
  router: any;
  isValid: boolean = true;
  errorMessage: string = '';
  errorFetchingGroups: boolean = false;



  constructor(
    public dialogRef: MatDialogRef<ManageCustomerGroupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private customerGroupService: ManageCustomerGroupService
  ) { }

  isEditButtonDisabled() {
    return !this.selectedCustomerGroup;
  }

  openEditCustomerGroupPopup() {

    this.showManageCustomerGroup = false;

    this.showEditPopup = true;
    this.getCustomersByGroupName(this.selectedCustomerGroup);
  }
  ngOnInit(): void {
    this.fetchGroupList();
    this.getAllCustomers();

  }

  filterCustomers(): void {
    
    if (this.searchText.trim() === '') {

      this.filteredCustomers = this.customers.filter(customer =>
        !this.selectedCustomers.some(selCust => selCust.customerId === customer.customerId)
      );
    } else {

      this.filteredCustomers = this.customers.filter(customer =>
        (customer.customerName.toLowerCase().includes(this.searchText.toLowerCase()) ||
          customer.customerId.toString().includes(this.searchText.toLowerCase())) &&
        !this.selectedCustomers.some(selCust => selCust.customerId === customer.customerId)
      );


    }
    
  }



  filterGroups(): void {
    
    if (!this.searchText.trim()) {

      this.filteredCustomerGroups = this.customerGroups;
    } else {

      const searchTextLowerCase = this.searchText.toLowerCase();
      this.filteredCustomerGroups = this.filteredCustomerGroups.filter(group =>
        group.groupName.toLowerCase().includes(searchTextLowerCase) &&
        group.groupName !== this.selectedGroupName
      );
    }
    

  }

  fetchGroupList() {
    this.customerGroupService.getGroupList().subscribe(
      (response: any[]) => {
        this.customerGroups = response.map(group => ({
          groupId: group.groupId,
          groupName: group.groupName,
          customers: group.customers || []
        }));

        this.filteredCustomerGroups = this.customerGroups.slice();

        this.customerGroups.forEach(group => {
          this.groupIDMap[group.groupName] = group.groupId;
        });

        
        
        this.errorFetchingGroups = false;
      },
      (error: any) => {
        console.error('Error fetching group list:', error);
        this.errorFetchingGroups = true;
      }
    );
  }

  removeSelectedCustomer(selectedCustomer: Customer): void {

    this.selectedCustomers = this.selectedCustomers.filter(
      customer => customer.customerId !== selectedCustomer.customerId
    );


    this.customers.push(selectedCustomer);


    this.filteredCustomers.push(selectedCustomer);


    this.count--;

    
  }
  moveToSelectedUsers(customer: Customer, removeFromOriginalList: boolean = true, event: MouseEvent): void {
    if (event.target instanceof HTMLImageElement && event.target.src.includes('Vector.png')) {

      const index = this.selectedCustomers.findIndex(c => c.customerId === customer.customerId);

      if (index === -1) {
        this.selectedCustomers.push(customer);

        if (removeFromOriginalList) {
          this.customers = this.customers.filter(cust => cust.customerId !== customer.customerId);
        }

        this.filteredCustomers = this.filteredCustomers.filter(cust => cust.customerId !== customer.customerId);

        this.count++;

        
      }
    }
  }
  handleImageClick() {
    
  }

  getAllCustomers(): void {
    this.customerGroupService.getAllCustomers().subscribe(
      (response: Customer[]) => {
        this.customers = response;
        this.filteredCustomers = response;
      },
      (error: any) => {
        console.error('Error fetching customers:', error);
      }
    );
  }

  validateInput(): void {
    const value = this.selectedCustomerGroup.trim();

    if (value === '' && this.selectedCustomerGroupDetails.groupName !== this.selectedCustomerGroup) {
      this.isValid = false;
      this.errorMessage = 'Group Name cannot be blank.';
      return;
    }
    if (/^[^a-zA-Z0-9]{1,4}/.test(value)) {
      this.isValid = false;
      this.errorMessage = 'Group Name cannot contain symbols in the first four characters.';
      return;
    }


    if (value.length < 4) {
      this.isValid = false;
      this.errorMessage = 'Group Name must be at least 4 characters long.';
      return;
    }

    this.isValid = true;
    this.errorMessage = '';
  }


  isCustomerHighlighted(customer: Customer): boolean {
    return this.searchText && customer.customerName.toLowerCase().includes(this.searchText.toLowerCase());
  }

  cancelUpdate() {
    this.dialog.closeAll();
  }

  closeEditPopup() {
    this.showEditPopup = false;
    this.showManageCustomerGroup = true;
  }


  closeDialog(): void {
    this.dialogRef.close();
  }


  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
    
  }


  selectCustomerGroup(groupName: string): void {
    this.selectedCustomerGroup = groupName;
    this.selectedGroupName = groupName;
    this.selectedCustomerGroupId = this.groupIDMap[groupName];

    if (this.selectedCustomerGroup) {
      this.editDisabled = false;
      this.deleteDisabled = false;
    } else {
      this.editDisabled = true;
      this.deleteDisabled = true;
    }
  }
  closeSearchBox() {
    this.searchVisible = false;
  }

  updateFilteredCustomerGroups() {
    this.filteredCustomerGroups = this.customerGroups.filter(
      group => group.name.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  getCustomersByGroupName(groupName: string) {
    this.customerGroupService.getCustomersByGroupName(groupName).subscribe(
      (response: any[]) => {
        if (response.length > 0 && response[0].customers) {
          this.selectedCustomers = response[0].customers;
          
        } else {
          
        }
      },
      (error) => {
        console.error('Error fetching customers by group name:', error);
      }
    );
  }
  shouldDisableUpdateButton(): boolean {
    return this.selectedCustomers.length === 0 || !this.selectedCustomerGroup;
  }

  updateCustomerGroup(): void {
    this.validateInput();

    if (!this.isValid) {
      console.error('Input is not valid');
      return;
    }
    if (!this.selectedCustomerGroupId) {
      console.error('No group selected');
      return;
    }
    if (this.selectedCustomers.length === 0) {
      this.isValid = false;
      this.errorMessage = 'Please select at least one customer before updating the group.';
      
      return;
    }


    const updateData = {
      customers: this.selectedCustomers,
      groupName: this.selectedCustomerGroup
    };

    this.customerGroupService.updateCustomerGroup(this.selectedCustomerGroupId, updateData).subscribe(
      (response: any) => {
        
        Swal.fire({
          icon: 'success',
          title: 'Great',
          text: 'Customer Group Successfully Updated',
        });
        this.closeDialog();
        this.errorMessage = '';

      },
      (error: any) => {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Failed to Update Customer Group',
        });
        if (error.error && error.error.error) {
          this.errorMessage = error.error.text;
        } else {
          this.errorMessage = 'An error occurred while updating the customer group.';
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Failed to Update Customer Group',
          });
        }
      }
    );
  }



  preventDropdownClose(event: Event): void {
    event.preventDefault();
    event.stopPropagation();
  }
  showSearchBox(): void {
    this.searchVisible = true;
  }

  confirmDelete(): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '300px',
      data: { message: 'Are you sure you want to delete this customer group?' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'yes') {
        if (!this.selectedCustomerGroupId) {
          console.error('No group selected');
          alert("No Customer Group Selected..!")
        } else {
          this.deleteCustomerGroup();
          this.dialog.closeAll();
        }

      } else {
        

      }
    });
  }


  deleteCustomerGroup(): void {
    const groupId = this.filteredCustomerGroups.find(group => group.groupName === this.selectedCustomerGroup)?.groupId;

    if (!groupId) {
      console.error('Unable to find groupId for deletion.');
      return;
    }
    this.customerGroupService.deleteGroup(groupId)
      .subscribe(
        response => {
          Swal.fire({
            icon: 'success',
            title: 'Great',
            text: 'Customer Group Deleted',
          });

        },
        error => {
          console.error('Error deleting customer group:', error);
          Swal.fire({
            icon: 'error',
            title: 'Oops!!!',
            text: 'Failed to delete customer group',
          });
        }
      );
  }
}