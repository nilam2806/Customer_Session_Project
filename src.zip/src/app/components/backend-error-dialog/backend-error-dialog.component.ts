import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-backend-error-dialog',
  templateUrl: './backend-error-dialog.component.html',
  styleUrls: ['./backend-error-dialog.component.css']
})
export class BackendErrorDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<BackendErrorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public errorMessage: string
  ) {}

  onClose(): void {
    this.dialogRef.close();
  }
}