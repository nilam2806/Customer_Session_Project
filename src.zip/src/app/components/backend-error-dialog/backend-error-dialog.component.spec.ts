import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BackendErrorDialogComponent } from './backend-error-dialog.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';


describe('BackendErrorDialogComponent', () => {
  let component: BackendErrorDialogComponent;
  let fixture: ComponentFixture<BackendErrorDialogComponent>;
  let matDialogRefMock: MatDialogRef<BackendErrorDialogComponent>;

  beforeEach(async () => {
    matDialogRefMock = {
      close: jest.fn(),
    } as any;

    await TestBed.configureTestingModule({
      declarations: [BackendErrorDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: matDialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: 'Test Error Message' },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BackendErrorDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize errorMessage from data', () => {
    expect(component.errorMessage).toEqual('Test Error Message');
  });

  it('should close dialog on onClose', () => {
    component.onClose();
    expect(matDialogRefMock.close).toHaveBeenCalled();
  });
});
