import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-customer-view-dialog',
  templateUrl: './customer-view-dialog.component.html',
  styleUrls: ['./customer-view-dialog.component.css']
})
export class CustomerViewDialogComponent {

  fieldsDisabled: boolean = true;

  constructor(
    public dialogRef: MatDialogRef<CustomerViewDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public session: any,
  ) {}

  closeModal(): void {
    this.dialogRef.close();
  }
}