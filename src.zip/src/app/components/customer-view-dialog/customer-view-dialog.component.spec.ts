import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { CustomerViewDialogComponent } from './customer-view-dialog.component';

describe('CustomerViewDialogComponent', () => {
  let component: CustomerViewDialogComponent;
  let fixture: ComponentFixture<CustomerViewDialogComponent>;
  let dialogRefMock: Partial<MatDialogRef<CustomerViewDialogComponent>>;


  beforeEach(() => {
    dialogRefMock = {
      close: jest.fn()
    };

    TestBed.configureTestingModule({
      declarations: [CustomerViewDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: dialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    });
    fixture = TestBed.createComponent(CustomerViewDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close dialog on closeModal()', () => {
    component.closeModal();
    expect(dialogRefMock.close).toHaveBeenCalled();
  });
});