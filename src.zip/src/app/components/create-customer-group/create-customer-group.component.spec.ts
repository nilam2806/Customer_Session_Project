import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CreateCustomerGroupComponent } from './create-customer-group.component';
import { Customer, CustomerGroupService } from 'app/service/CustomerGroup/customer-group-service.service';
import { Observable, of } from 'rxjs';
import { spyOn } from 'jest-mock';


describe('CreateCustomerGroupComponent', () => {
  let component: CreateCustomerGroupComponent;
  let fixture: ComponentFixture<CreateCustomerGroupComponent>;
  let customerGroupServiceMock: Partial<CustomerGroupService>;
  let matDialogRefMock: Partial<MatDialogRef<CreateCustomerGroupComponent>>;

  beforeEach(async () => {
    customerGroupServiceMock = {
      getAllCustomers: jest.fn().mockReturnValue(of([])),
      createCustomerGroup: jest.fn().mockReturnValue(of({}))
    };
    matDialogRefMock = {
      close: jest.fn()
    };

    await TestBed.configureTestingModule({
      declarations: [CreateCustomerGroupComponent],
      providers: [
        FormBuilder,
        { provide: CustomerGroupService, useValue: customerGroupServiceMock },
        { provide: MatDialogRef, useValue: matDialogRefMock }
      ]
    }).compileComponents();
  });

  
  beforeEach(() => {
    fixture = TestBed.createComponent(CreateCustomerGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch customers on component initialization', () => {
    const customers: Customer[] = [
      { 
        customerId: 1, 
        customerName: 'Customer 1', 
        customerEmail: 'customer1@example.com',
        wealthMode: 'Some Wealth Mode', // Add wealthMode property
        preferredProduct: 'Some Preferred Product', // Add preferredProduct property
        financialGoal: 'Some Financial Goal' // Add financialGoal property
      }
    ];
    // Mock the return value of getAllCustomers
    //spyOn(customerGroupServiceMock, 'getAllCustomers').and.returnValue(of(customers));
    spyOn(customerGroupServiceMock, 'getAllCustomers').mockReturnValue(of(customers) as Observable<Customer[]>);

    component.ngOnInit();

    expect(component.customers).toEqual(customers);
    expect(component.filteredCustomers).toEqual(customers);
    expect(customerGroupServiceMock.getAllCustomers).toHaveBeenCalled();
  });

  it('should fetch customers on component initialization', () =>{

  })
  

  it('should move customer to selected list when clicked', () => {
    const customer = { customerId: 1, customerName: 'Test Customer', customerEmail: 'test@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.moveToSelectedUsers(customer);
    expect(component.selectedCustomers.length).toBe(1);
    expect(component.customers.length).toBe(0);
  });

  it('should remove customer from selected list when clicked again', () => {
    const customer = { customerId: 1, customerName: 'Test Customer', customerEmail: 'test@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.moveToSelectedUsers(customer);
    component.removeSelectedCustomer(customer);
    expect(component.selectedCustomers.length).toBe(0);
    expect(component.customers.length).toBe(1);
  });

  it('should create group when form is valid', fakeAsync(() => {
    component.selectedCustomerGroup = 'Test Group';
    const customer = { customerId: 1, customerName: 'Test Customer', customerEmail: 'test@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.moveToSelectedUsers(customer);
    fixture.detectChanges();
    component.createGroup();
    tick();
    expect(customerGroupServiceMock.createCustomerGroup).toHaveBeenCalled();
    expect(matDialogRefMock.close).toHaveBeenCalled();
  }));

  it('should not create group when form is invalid', fakeAsync(() => {
    const customer = { customerId: 1, customerName: 'Test Customer', customerEmail: 'test@example.com', wealthMode: '', preferredProduct: '', financialGoal: '' };
    component.moveToSelectedUsers(customer);
    fixture.detectChanges();
    component.createGroup();
    tick();
    expect(customerGroupServiceMock.createCustomerGroup).not.toHaveBeenCalled();
    expect(matDialogRefMock.close).not.toHaveBeenCalled();
  }));

  it('should close the popup', () => {
    // Spy on the global alert function
    const alertSpy = jest.spyOn(window, 'alert').mockImplementation(() => {});
    
    // Call the method
    component.closePopup();
    
    // Expect the alert function to have been called
    expect(alertSpy).toHaveBeenCalledWith('Popup closed');
    
    // Restore the original alert function
    alertSpy.mockRestore();
  });


  it('should handle image click', () => {
    // Spy on 
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  
    // Call the method
    component.handleImageClick();
  
    // Expect 
    expect(consoleSpy).toHaveBeenCalledWith('Image clicked!');
  
    // Restore the original 
    consoleSpy.mockRestore();
  });
  
  it('should set isValid to false and errorMessage when input is blank', () => {
    const inputElement = document.createElement('input');
    inputElement.value = '';
    component.validateInput(inputElement);
    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name cannot be blank.');
  });

  it('should set isValid to false and errorMessage when input contains symbols in the first four characters', () => {
    const inputElement = document.createElement('input');
    inputElement.value = '!@#GroupName';
    component.validateInput(inputElement);
    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name cannot contain symbols in the first four characters.');
  });

  it('should set isValid to false and errorMessage when input length is less than 4 characters', () => {
    const inputElement = document.createElement('input');
    inputElement.value = 'Gp';
    component.validateInput(inputElement);
    expect(component.isValid).toBe(false);
    expect(component.errorMessage).toBe('Group Name must be at least 4 characters long.');
  });

  it('should set isValid to true and errorMessage to empty string when input is valid', () => {
    const inputElement = document.createElement('input');
    inputElement.value = 'ValidGroupName';
    component.validateInput(inputElement);
    expect(component.isValid).toBe(true);
    expect(component.errorMessage).toBe('');
  });

  
  
});

