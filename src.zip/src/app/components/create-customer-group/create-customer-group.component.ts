import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerGroupService } from 'app/service/CustomerGroup/customer-group-service.service';
import Swal from 'sweetalert2';




interface Customer {
  customerId: number;
  customerName: string;
  customerEmail: string;
  wealthMode: string;
  preferredProduct: string;
  financialGoal: string;
}

interface CustomerGroup {
  groupId: number;
  groupName: string;
  customers: Customer[];
}

@Component({
  selector: 'app-create-customer-group',
  templateUrl: './create-customer-group.component.html',
  styleUrls: ['./create-customer-group.component.css']
})
export class CreateCustomerGroupComponent implements OnInit {
  customers: Customer[] = [];
  selectedCustomers: Customer[] = [];
  selectedCustomerGroup: string = '';
  dialog: any;
  count: number = 0;
  filteredCustomers: Customer[] = [];
  searchText: string = '';
  formGroup: FormGroup;
  isValid: boolean = true;
  errorMessage: string = '';

  constructor(private customerGroupService: CustomerGroupService, public dialogRef: MatDialogRef<CreateCustomerGroupComponent>,) { }

  ngOnInit() {
    this.getAllCustomers();
  }


  validateInput(input: HTMLInputElement): void {
    const value = input.value.trim();

    if (value === '') {
      this.isValid = false;
      this.errorMessage = 'Group Name cannot be blank.';
      return;
    }


    if (/^[^a-zA-Z0-9]{1,4}/.test(value)) {
      this.isValid = false;
      this.errorMessage = 'Group Name cannot contain symbols in the first four characters.';
      return;
    }


    if (value.length < 4) {
      this.isValid = false;
      this.errorMessage = 'Group Name must be at least 4 characters long.';
      return;
    }


    this.isValid = true;
    this.errorMessage = '';
  }


  moveToSelectedUsers(customer: Customer, removeFromOriginalList: boolean = true): void {
    const index = this.selectedCustomers.findIndex(c => c.customerId === customer.customerId);

    if (index === -1) {
      this.selectedCustomers.push(customer);
      if (removeFromOriginalList) {
        this.customers = this.customers.filter(cust => cust.customerId !== customer.customerId);
      }
      this.filteredCustomers = this.filteredCustomers.filter(cust => cust.customerId !== customer.customerId);

      this.count++;
      
    }
  }



  removeSelectedCustomer(selectedCustomer: Customer): void {
    this.selectedCustomers = this.selectedCustomers.filter(
      customer => customer.customerId !== selectedCustomer.customerId
    );

    this.customers.push(selectedCustomer);

    this.filteredCustomers.push(selectedCustomer);
    this.count--;

    
  }


  handleImageClick() {
    
  }

  getAllCustomers() {
    this.customerGroupService.getAllCustomers().subscribe(
      (response: Customer[]) => {
        this.customers = response;
        this.filteredCustomers = response;
        
        this.filterCustomers(); // Filter the customers immediately after fetching them
      },
      (error) => {
        console.error('Error fetching customers:', error);
      }
    );
  }

  createGroup(): void {
    if (this.selectedCustomerGroup.length === 0) {
      this.isValid = false;
      this.errorMessage = 'Group Name cannot be blank.';
      this.errorMessage = 'Group Name cannot be blank.';
      
      return; // Exit the method if the input is blank
    }

    // Check if at least one customer is selected
    if (this.selectedCustomers.length === 0) {
      this.isValid = false;
      this.errorMessage = 'Please select at least one customer before creating the group.';
      
      return;
    }

    const customerGroup: CustomerGroup = {
      groupId: 0,
      groupName: this.selectedCustomerGroup,
      customers: this.selectedCustomers
    };

    
    this.customerGroupService.createCustomerGroup(customerGroup).subscribe(
      (response) => {
        

        this.closeModal();
        Swal.fire({
          icon: 'success',
          title: 'Great',
          text: 'Customer Group Created Successfully',
        }).then(() => {
          window.location.reload();
        });
      },

      (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Failed to create customer group',
        }).then(() => {
        });
      }

    );
  }

  private getAuthToken(): string | null {
    const authToken = localStorage.getItem('authToken');

    if (!authToken) {
      throw new Error('Authentication token not found.');
    }

    return authToken;
  }

  cancelUpdate() {
    this.dialog.closeAll();
  }

  closePopup() {
    alert('Popup closed');
  }

  closeModal(): void {
    this.dialogRef.close();
  }

  filterCustomers(): void {
    
    if (this.searchText.trim() === '') {
      this.filteredCustomers = this.customers.filter(customer =>
        !this.selectedCustomers.some(selCust => selCust.customerId === customer.customerId)
      );
    } else {
      this.filteredCustomers = this.customers.filter(customer =>
        (customer.customerName.toLowerCase().includes(this.searchText.toLowerCase()) ||
          customer.customerId.toString().includes(this.searchText.toLowerCase())) &&
        !this.selectedCustomers.some(selCust => selCust.customerId === customer.customerId)
      );
    }
    
  }

  isCustomerHighlighted(customer: Customer): boolean {
    return this.searchText && customer.customerName.toLowerCase().includes(this.searchText.toLowerCase());
  }
}