import { TestBed, ComponentFixture, tick, fakeAsync } from '@angular/core/testing';
import { RMDashboardComponent } from './rmdashboard.component';
import { MatDialogModule, MatDialog } from '@angular/material/dialog'; // Import necessary Angular modules
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { LoginService } from 'app/service/loginservice/login.service';
import { HttpClientModule } from '@angular/common/http';

describe('RMDashboardComponent', () => {
  let component: RMDashboardComponent;
  let fixture: ComponentFixture<RMDashboardComponent>;
  let dialog: MatDialog;
  let sessionService: SessionService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RMDashboardComponent],
      imports: [MatDialogModule, MatSnackBarModule],
      providers: [SessionService, MatDialog]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RMDashboardComponent);
    component = fixture.componentInstance;
    dialog = TestBed.inject(MatDialog);
    sessionService = TestBed.inject(SessionService);
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with default values', () => {
    expect(component.showEditAndArchiveColumns).toBe(true);
    expect(component.showIcons).toBe(true);
    // Add more assertions for other variables
  });

  it('should load sessions on initialization', () => {
    spyOn(component, 'loadSessions');
    component.ngOnInit();
    expect(component.loadSessions).toHaveBeenCalled();
  });

  it('should open logout dialog when method openLogoutDialog is called', () => {
    const dialogRefMock = { afterClosed: () => of(true) };
    const spy = jest.spyOn(dialog, 'open').mockReturnValue(dialogRefMock as any);
    component.openLogoutDialog();
    expect(spy).toHaveBeenCalledWith(expect.any(Function), { width: '250px' });
  });


  it('should call logout method of service on logout', () => {
    const clearTokenSpy = spyOn(TestBed.inject(LoginService), 'clearToken');
    const navigateByUrlSpy = spyOn(TestBed.inject(Router), 'navigateByUrl');
    const windowOpenSpy = spyOn(window, 'open');
    spyOn(component, 'logout').and.callThrough();

    component.logout();

    expect(clearTokenSpy).toHaveBeenCalled();
    expect(navigateByUrlSpy).toHaveBeenCalledWith("/login");
    expect(windowOpenSpy).toHaveBeenCalled();
  });


  // Write more specific test cases to cover different methods, event handlers, etc.

  describe('loadSessions method', () => {
    it('should call getSessionData method of sessionService and update activeSessions and archivedSessions', fakeAsync(() => {
      const response = [
        { sessionId: 1, sessionName: 'Session 1', isArchived: false },
        { sessionId: 2, sessionName: 'Session 2', isArchived: true }
      ];
      spyOn(sessionService, 'getSessionData').and.returnValue(of(response));

      component.loadSessions();
      tick();

      expect(component.activeSessions).toEqual([
        { sessionId: 1, sessionName: 'Session 1', isArchived: false },
      ]);
      expect(component.archivedSessions).toEqual([
        { sessionId: 2, sessionName: 'Session 2', isArchived: true }
      ]);
    }));
  });

  describe('toggleDropdown method', () => {
    it('should toggle isDropdown2Open and close Apply Product options', () => {
      component.isDropdown2Open = false;
      component.toggleDropdown('dropdown2');
      expect(component.isDropdown2Open).toBe(true);
      expect(component.isApplyProductOpen).toBe(false);

      component.toggleDropdown('dropdown1'); // Test for another dropdown
      expect(component.isDropdown1Open).toBe(false);
    });
  });

  describe('applyProduct method', () => {
    it('should toggle isApplyProductOpen and close SME List', () => {
      component.isApplyProductOpen = false;
      component.applyProduct('Apply Product');
      expect(component.isApplyProductOpen).toBe(true);
      expect(component.isSMEListOpen).toBe(false);
    });
  });

  describe('openQuickLinks method', () => {
    it('should set isDropdown2Open to true', () => {
      component.openQuickLinks();
      expect(component.isDropdown2Open).toBe(true);
    });
  });

  describe('closeQuickLinks method', () => {
    it('should set isDropdown2Open and isApplyProductOpen to false', () => {
      component.isDropdown2Open = true;
      component.isApplyProductOpen = true;
      component.closeQuickLinks();
      expect(component.isDropdown2Open).toBe(false);
      expect(component.isApplyProductOpen).toBe(false);
    });
  });

  describe('openApplyProduct method', () => {
    it('should set isApplyProductOpen to true', () => {
      component.openApplyProduct();
      expect(component.isApplyProductOpen).toBe(true);
    });
  });

  describe('closeApplyProduct method', () => {
    it('should set isApplyProductOpen to false', () => {
      component.isApplyProductOpen = true;
      component.closeApplyProduct();
      expect(component.isApplyProductOpen).toBe(false);
    });
  });

  describe('selectProduct method', () => {
    it('should open the specified website in a new tab based on the selected product', () => {
      const windowOpenSpy = spyOn(window, 'open');
      component.selectProduct('Credit Card');
      expect(windowOpenSpy).toHaveBeenCalledWith('https://maveric-systems.com/', '_blank');
      // Test for other cases
    });
  });

  describe('contactSME method', () => {
    it('should open the specified website in a new tab', () => {
      const windowOpenSpy = spyOn(window, 'open');
      component.contactSME();
      expect(windowOpenSpy).toHaveBeenCalledWith('https://maveric-systems.com/', '_blank');
    });
  });

  // Add more specific test cases for other methods, event handlers, etc.

  describe('loadSessions method', () => {
    it('should call getSessionData method of sessionService and update activeSessions and archivedSessions', fakeAsync(() => {
      const response = [
        { sessionId: 1, sessionName: 'Session 1', isArchived: false },
        { sessionId: 2, sessionName: 'Session 2', isArchived: true }
      ];
      spyOn(sessionService, 'getSessionData').and.returnValue(of(response));

      component.loadSessions();
      tick();

      expect(component.activeSessions).toEqual([
        { sessionId: 1, sessionName: 'Session 1', isArchived: false },
      ]);
      expect(component.archivedSessions).toEqual([
        { sessionId: 2, sessionName: 'Session 2', isArchived: true }
      ]);
    }));
  });

  it('should reload the page when cancelFilter is called', () => {
    const reloadSpy = spyOn(window.location, 'reload');
    component.cancelFilter();
    expect(reloadSpy).toHaveBeenCalled();
  });


  it('should toggle dropdown 2 and close Apply Product options when toggleDropdown is called with dropdown2', () => {
    component.isDropdown2Open = false;
    component.isApplyProductOpen = true;

    component.toggleDropdown('dropdown2');

    expect(component.isDropdown2Open).toBe(true);
    expect(component.isApplyProductOpen).toBe(false);
  });

  it('should toggle Apply Product options and close SME List when applyProduct is called with Apply Product option', () => {
    component.isApplyProductOpen = false;
    component.isSMEListOpen = true;

    component.applyProduct('Apply Product');

    expect(component.isApplyProductOpen).toBe(true);
    expect(component.isSMEListOpen).toBe(false);
  });

  it('should set dropdown 2 to open when openQuickLinks is called', () => {
    component.isDropdown2Open = false;

    component.openQuickLinks();

    expect(component.isDropdown2Open).toBe(true);
  });

  it('should close dropdown 2 and Apply Product options when closeQuickLinks is called', () => {
    component.isDropdown2Open = true;
    component.isApplyProductOpen = true;

    component.closeQuickLinks();

    expect(component.isDropdown2Open).toBe(false);
    expect(component.isApplyProductOpen).toBe(false);
  });

  it('should set Apply Product options to open when openApplyProduct is called', () => {
    component.isApplyProductOpen = false;

    component.openApplyProduct();

    expect(component.isApplyProductOpen).toBe(true);
  });

  it('should close Apply Product options when closeApplyProduct is called', () => {
    component.isApplyProductOpen = true;

    component.closeApplyProduct();

    expect(component.isApplyProductOpen).toBe(false);
  });

  it('should set showActiveSessions to false and update currentTab to "archived"', () => {
    component.showActiveSessions = true;
    component.currentTab = 'active';
    component.onArchivedSessionsClick();
    expect(component.showActiveSessions).toBe(false);
    expect(component.currentTab).toBe('archived');
  });

  it('should update paged sessions and hide edit and archive columns', () => {
    component.showEditAndArchiveColumns = true;

    const updatePagedSessionsSpy = jest.spyOn(component, 'updatePagedSessions');

    component.onArchivedSessionsClick();

    expect(updatePagedSessionsSpy).toHaveBeenCalled();
    expect(component.showEditAndArchiveColumns).toBe(false);
  });

  it('should update searchInput and call loadSessions if showActiveSessions is true', () => {
    component.showActiveSessions = true;
    const mockEvent = { target: { value: 'search query' } };
    const loadSessionsSpy = jest.spyOn(component, 'loadSessions');
    component.onSearchChange(mockEvent);
    expect(component.searchInput).toBe('search query');
    expect(loadSessionsSpy).toHaveBeenCalled();
  });

  it('should update searchInput and call filterArchivedSessions if showActiveSessions is false', () => {
    component.showActiveSessions = false;
    const mockEvent = { target: { value: 'search query' } };
    const filterArchivedSessionsSpy = jest.spyOn(component, 'filterArchivedSessions');
    component.onSearchChange(mockEvent);
    expect(component.searchInput).toBe('search query');
    expect(filterArchivedSessionsSpy).toHaveBeenCalled();
  });

  it('should decrement currentPageArchived and update paged sessions', () => {
    component.currentPageArchived = 3;
    component.prevPageArchived();
    expect(component.currentPageArchived).toBe(2);
  });

  it('should increment currentPageArchived and update paged sessions', () => {
    component.currentPageArchived = 2;
    component.totalPagesArchived = 5;
    component.nextPageArchived();
    expect(component.currentPageArchived).toBe(3);
  });

  it('should update paged sessions based on currentPageArchived', () => {
    component.archivedSessions = [
      { sessionId: 1, sessionName: 'Session 1', isArchived: true },
      { sessionId: 2, sessionName: 'Session 2', isArchived: true },
    ];
    component.recordsPerPageArchived = 2;
    component.currentPageArchived = 1;
    component.updatePagedArchivedSessions();
    expect(component.pagedSessions.length).toBe(2);
  });

  it('should filter archived sessions based on search input', () => {
    component.filteredArchivedSessions = [
      { sessionId: 1, sessionName: 'Session 1', isArchived: true, customerName: 'John Doe', formattedSessionId: 'ABC123' },
      { sessionId: 2, sessionName: 'Session 2', isArchived: true, customerName: 'Jane Smith', formattedSessionId: 'XYZ456' },
    ];
    component.searchInput = 'John';
    component.filterArchivedSessions();
    expect(component.archivedSessions.length).toBe(1);
  });

  it('should update searchInput and call loadSessions or filterArchivedSessions based on showActiveSessions', () => {
    // Arrange
    const event = { target: { value: 'searchQuery' } } as any;
    component.showActiveSessions = true;
    spyOn(component, 'loadSessions');
    
    // Act
    component.onSearchChange(event);
    
    // Assert
    expect(component.searchInput).toEqual('searchQuery');
    expect(component.loadSessions).toHaveBeenCalled();
  });

  it('should update searchInput and call filterArchivedSessions when showActiveSessions is false', () => {
    // Arrange
    const event = { target: { value: 'searchQuery' } } as any;
    component.showActiveSessions = false;
    spyOn(component, 'filterArchivedSessions');
    
    // Act
    component.onSearchChange(event);
    
    // Assert
    expect(component.searchInput).toEqual('searchQuery');
    expect(component.filterArchivedSessions).toHaveBeenCalled();
  });

  it('should update paged sessions when calling nextPageArchived', () => {
    // Mock some example archived sessions
    component.archivedSessions = [
      { customerName: 'Customer A', formattedSessionId: '123', sessionName: 'Session 1' },
      { customerName: 'Customer B', formattedSessionId: '456', sessionName: 'Session 2' },
      // Add more sample sessions as needed
    ];

    component.currentPageArchived = 1;
    component.totalPagesArchived = 2; // Assuming there are 2 pages with 2 sessions each

    component.nextPageArchived();

    // Expect currentPageArchived to be incremented
    expect(component.currentPageArchived).toEqual(2);

    // Expect pagedSessions to be updated
    expect(component.pagedSessions.length).toBeGreaterThan(0); // Assuming there are sessions in the pagedSessions array
  });
});