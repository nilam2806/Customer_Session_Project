import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { LogoutDialogComponent } from '../logout-dialog/logout-dialog.component';
import Swal from 'sweetalert2';
import { interval, Subscription } from 'rxjs';
import { MatIconModule } from '@angular/material/icon';
import { EditSessionFormComponent } from '../edit-session-form/edit-session-form.component';
import { SessionDetailsModalComponent } from '../view-session-details/view-session-details.component';
import { FormControl } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';
import { OverlayContainer } from '@angular/cdk/overlay';
import { CustomerViewDialogComponent } from '../customer-view-dialog/customer-view-dialog.component';
import { BackendErrorDialogComponent } from '../backend-error-dialog/backend-error-dialog.component';
import { ArchiveConfirmationDialogComponent } from '../archive-confirmation-dialog/archive-confirmation-dialog.component';
import { CreatesessionComponent } from '../createsession/createsession.component';
import { ChangeDetectorRef } from '@angular/core';
import { CreateCustomerGroupComponent } from '../create-customer-group/create-customer-group.component';
import { FilterDialogComponent } from '../filter-dialog/filter-dialog.component';
import { ManageCustomerGroupComponent } from '../manage-customer-group/manage-customer-group.component';
import { MatTableDataSource } from '@angular/material/table';
import { LoginService } from 'app/service/loginservice/login.service';
import { SessionService } from 'app/service/rmdashboardservice/get-session-data.service';
import { ManageCustomerGroupService } from 'app/service/manage-group/manage-customer-group.service';



@Component({
  selector: 'app-dashboard',
  templateUrl: './rmdashboard.component.html',
  styleUrls: ['./rmdashboard.component.css'],
  providers: [DatePipe]
})
export class RMDashboardComponent implements OnInit {


  showEditAndArchiveColumns: boolean = true;
  showIcons: boolean = true;
  message: string;
  successMessage: string | null = null;
  dataSource: MatTableDataSource<any>;
  loggedInUser: string | null = null; // Initialize loggedInUser
  selectedGroup: string | null = null;

  recordsPerPageControl = new FormControl(5);
  setRecordsPerPage(value: number) {
    this.recordsPerPageControl.setValue(value);
    this.currentPage = 1;
    this.pageSize = this.recordsPerPageControl.value;
    this.updatePagedSessions();
  }
  groupList: any[] = [];
  selectedGroupName: string = '';
  selectedCustomerGroup: any;
  filteredCustomerGroups: any[] = [];
  showTagDetails: any;
  activeSessions: any[] = [];
  archivedSessions: any[] = [];
  currentTab: number | string = 0;
  pageSize = 5;
  currentPage = 1;
  pagedSessions: any[] = [];
  showActiveSessions: boolean = true;
  filterApplied: boolean = false;


  newSessionTab: any = {
    label: 'Add New Session',
    icon: 'add',
  };

  searchInput: string = '';
  filteredActiveSessions: any[] = [];
  filteredArchivedSessions: any[] = [];

  sortColumn: string | null = 'sessionId'; // set to the default sorting column
  sortDirection: 'asc' | 'desc' = 'asc';

  session: any; // Adjust the type based on your actual session data structure
  customerName: string;

  activeTab: 'active' | 'archived' = 'active';
  constructor(
    private service: LoginService,
    private router: Router,
    private dialog: MatDialog,
    private sessionservice: SessionService,
    private snackBar: MatSnackBar,
    private datePipe: DatePipe,
    private overlayContainer: OverlayContainer,
    private cdr: ChangeDetectorRef,
    private customerGroupService: ManageCustomerGroupService,
    private activatedRoute: ActivatedRoute,



  ) { }

  isDropdown1Open: boolean = false;
  isDropdown2Open: boolean = false;
  isApplyProductOpen: boolean = false;

  toggleDropdown(dropdown: string): void {
    if (dropdown === 'dropdown2') {
      this.isDropdown2Open = !this.isDropdown2Open;
      this.isApplyProductOpen = false; // Close the Apply Product options
    }
  }
  applyProduct(option: string): void {
    this.isApplyProductOpen = !this.isApplyProductOpen;
    if (option === 'Apply Product') {
      this.isSMEListOpen = false;
    }
  }
  openQuickLinks(): void {
    this.isDropdown2Open = true;
  }

  closeQuickLinks(): void {
    this.isDropdown2Open = false;
    this.isApplyProductOpen = false;
  }

  openApplyProduct(): void {
    this.isApplyProductOpen = true;
  }

  closeApplyProduct(): void {
    this.isApplyProductOpen = false;
  }

  selectProduct(product: string): void {

    switch (product) {
      case 'Credit Card':
        window.open('https://maveric-systems.com/', '_blank');
        break;
      case 'Travel Insurance':
        window.open('https://maveric-systems.com/', '_blank');
        break;
      case 'Life Insurance':
        window.open('https://maveric-systems.com/', '_blank');
        break;
      case 'Loans':
        window.open('https://maveric-systems.com/', '_blank');
        break;
      default:
        break;
    }
  }


  contactSME(): void {
    window.open('https://maveric-systems.com/', '_blank');

  }


  ngOnInit() {
    // Retrieve loggedInUser from local storage
    const storedLoggedInUser = localStorage.getItem('loggedInUser');

    if (storedLoggedInUser != null) {
      const trimmedLoggedInUser = storedLoggedInUser.trim().split(' ')[0];
      this.loggedInUser = trimmedLoggedInUser;
    } else {
      this.loggedInUser = null;
    }

    this.loadSessions();
    this.sessionservice.getSessionData().subscribe(data => {
      this.session = data;
    });
    this.loadArchivedSessions();
    this.filterArchivedSessions();
    this.fetchGroupList();
  }
  fetchGroupList() {
    this.sessionservice.getGroupList().subscribe(
      (groups: any[]) => {
        this.groupList = groups;
      },
      (error: any) => {
        console.error('Error fetching group list:', error);
        // Handle error
      }
    );
  }
  onGroupClick(groupName: string): void {
    this.selectedGroup = groupName;
    this.sessionservice.getSessionByGroupName(groupName).subscribe(
      (data) => {




        if (data) {

          data = this.processData(data);


          this.pagedSessions = data;
          this.updatePagedSessions();
          this.filterApplied = true;



        } else {
          console.error('Invalid data format or no sessions found.');
        }
      },
      (error) => {

        console.error('Error fetching customer and session data:', error);
      }
    );
  }

  filterSessions(sessions: any[], searchInputLowerCase: string): any[] {
    return sessions.filter(session =>
      session.customerName.toLowerCase().includes(searchInputLowerCase) ||
      session.SessionName.toLowerCase().includes(searchInputLowerCase) ||
      session.formattedSessionId.toLowerCase().includes(searchInputLowerCase)
    );
  }


  openLogoutDialog(): void {
    document.body.classList.add('blur-background');

    const dialogRef = this.dialog.open(LogoutDialogComponent, {
      width: '450px',
    });

    dialogRef.afterClosed().subscribe(result => {
      document.body.classList.remove('blur-background');

      if (result) {
        this.logout();
      }
    });
  }

  logout() {
    this.service.clearToken();
    this.router.navigateByUrl("/login");

    Swal.fire({
      icon: 'success',
      title: 'Sign Out Successful!',
      showConfirmButton: false,
      timer: 1500,
    });
  }


  onViewClick(session: any) {

    this.openSessionDetailsModal(session);
  }

  onCustomerViewClick(session: any) {

    this.openCustomerDetailsModal(session);
  }

  openCustomerDetailsModal(session: any): void {
    const dialogRef = this.dialog.open(CustomerViewDialogComponent, {
      height: '700px',
      width: '500px',
      data: session
    });

    dialogRef.afterOpened().subscribe(() => {
      this.addBlurClass();
    });

    dialogRef.afterClosed().subscribe(result => {

      this.removeBlurClass();
    });
  }

  openSessionDetailsModal(session: any): void {
    const dialogRef = this.dialog.open(SessionDetailsModalComponent, {
      height: '700px',
      width: '500px',
      data: session
    });

    dialogRef.afterOpened().subscribe(() => {
      this.addBlurClass();
    });

    dialogRef.afterClosed().subscribe(result => {

      this.removeBlurClass();
    });
  }

  onCreateSessionClick(): void {
    this.openCreateSessionDialog();
  }

  openCreateSessionDialog(): void {
    const dialogRef = this.dialog.open(CreatesessionComponent, {
      width: '520px',
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }

  private addBlurClass(): void {
    const container = this.overlayContainer.getContainerElement();
    container.classList.add('overlay-blur');
  }

  private removeBlurClass(): void {
    const container = this.overlayContainer.getContainerElement();
    container.classList.remove('overlay-blur');
  }


  onEditClick(session: any) {

    this.openEditSessionDialog(session);
  }

  openEditSessionDialog(session: any): void {
    const dialogRef = this.dialog.open(EditSessionFormComponent, {
      height: 'auto',
      width: '600px',
      data: { ...session },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.sessionservice.updateSession(result).subscribe(
          (response) => {
            this.snackBar.open('Session updated successfully!', 'Close', {
              duration: 2000,
              panelClass: 'success-snackbar'
            });

            const index = this.activeSessions.findIndex(s => s.SessionID === result.SessionID);
            if (index !== -1) {
              this.activeSessions[index] = result;
              this.updatePagedSessions();
            }

            this.cdr.detectChanges();
          },
          (error) => {
            console.error('Error updating session:', error);
            this.snackBar.open('Failed to update session. Please try again.', 'Close', {
              duration: 2000,
              panelClass: 'error-snackbar'
            });
          }
        );
      }
    });
  }


  isToday(dateString: string): boolean {
    const currentDate = new Date();
    const formattedCurrentDate = this.datePipe.transform(currentDate, 'yyyy-MM-dd');
    const formattedDate = this.datePipe.transform(dateString, 'yyyy-MM-dd');

    return formattedDate === formattedCurrentDate;
  }

  isPastDate(dateString: string): boolean {
    const currentDate = new Date();
    const formattedCurrentDate = this.datePipe.transform(currentDate, 'yyyy-MM-dd');
    const formattedDate = this.datePipe.transform(dateString, 'yyyy-MM-dd');

    return formattedDate < formattedCurrentDate;
  }

  onActiveSessionsClick() {

    this.showActiveSessions = true;
    this.updatePagedSessions();
    this.currentTab = 'active';

    this.activeTab = 'active';

  }

  onArchivedSessionsClick() {

    this.showActiveSessions = false;
    this.updatePagedSessions();
    this.showEditAndArchiveColumns = false;
    this.currentTab = 'archived';

    this.activeTab = 'archived';
  }

  loadArchivedSessions() {
    this.sessionservice.getArchivedSessions().subscribe(
      (response: any[]) => {
        if (response && response.length >= 0) {
          this.archivedSessions = response.map(item => this.mapSession(item));
          this.filteredArchivedSessions = [...this.archivedSessions];
          this.totalPagesArchived = Math.ceil(this.filteredArchivedSessions.length / this.recordsPerPageArchived);
          this.updatePagedSessions();
        }
      },
    );
  }


  onRestoreClick(sessionId: string) {

  }

  changeTab(event: any) {
    this.currentTab = event.index;
    this.currentPage = 1;

    if (this.currentTab === 'active') {
      this.updatePagedSessions();
    } else if (this.currentTab === 'archived') {
      this.updatePagedArchivedSessions();
    }
  }


  updatePagedSessions() {
    let sessions = this.showActiveSessions ? this.activeSessions : this.archivedSessions;

    if (this.sortColumn) {
      sessions = sessions.sort((a, b) => {
        const aValue = a[this.sortColumn];
        const bValue = b[this.sortColumn];
        if (aValue < bValue) {
          return this.sortDirection === 'asc' ? -1 : 1;
        } else if (aValue > bValue) {
          return this.sortDirection === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      });
    }

    const startIndex = (this.currentPage - 1) * this.pageSize;
    this.pagedSessions = sessions.slice(startIndex, startIndex + this.pageSize);
  }

  prevPage() {

    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePagedSessions();
    }
  }

  nextPage() {

    const sessions = this.showActiveSessions ? this.activeSessions : this.archivedSessions;
    if (this.currentPage < Math.ceil(sessions.length / this.pageSize)) {
      this.currentPage++;
      this.updatePagedSessions();
    }
  }

  get totalPages(): number {
    const sessions = this.showActiveSessions ? this.activeSessions : this.archivedSessions;
    return Math.ceil(sessions.length / this.pageSize);
  }

  onPageSizeChange() {
    this.currentPage = 1;
    this.updatePagedSessions();
  }

  processData(response: any): any {


    this.activeSessions = response
      .filter(item => !item.isArchived)
      .map(item => this.mapSession(item));

    this.archivedSessions = response
      .filter(item => item.isArchived)
      .map(item => this.mapSession(item));

    if (this.searchInput) {
      const searchInputLowerCase = this.searchInput.toLowerCase();

      this.activeSessions = this.activeSessions.filter(session =>
        session.customerName.toLowerCase().includes(searchInputLowerCase) ||
        session.formattedSessionId.toLowerCase().includes(searchInputLowerCase) ||
        session.sessionName.toLowerCase().includes(searchInputLowerCase) ||  // Adding search by session name
        session.tags.some(tag => tag.toLowerCase().includes(searchInputLowerCase))  // Adding search by tag
      );

      this.archivedSessions = this.archivedSessions.filter(session =>
        session.customerName.toLowerCase().includes(searchInputLowerCase) ||
        session.formattedSessionId.toLowerCase().includes(searchInputLowerCase) ||
        session.sessionName.toLowerCase().includes(searchInputLowerCase) ||  // Adding search by session name
        session.tags.some(tag => tag.toLowerCase().includes(searchInputLowerCase))  // Adding search by tag
      );
    }




    return response;
  }

  loadSessions() {
    this.sessionservice.getSessionData().subscribe(
      (response: any[]) => {
        if (response && response.length > 0) {

          response = this.processData(response);
          this.updatePagedSessions();
        } else {
          console.error('Invalid API response format:', response);
        }
      },
      (error) => {
        console.error('Error fetching sessions:', error);
      }
    );
  }

  mapSession(item: any): any {
    const sessionData = item;
    let customerName = '';
    let wealthMode = '';
    let preferredProduct = '';
    let financialGoal = '';
    let remarks = [];
    let tags = [];

    if (item.customerDetails != null) {

      customerName = item.customerDetails.customerName || '';
      wealthMode = item.customerDetails.wealthMode || '';
      preferredProduct = item.customerDetails.preferredProduct || '';
      financialGoal = item.customerDetails.financialGoal || '';
      remarks = item.customerDetails.remarks || [];
    } else {

    }

    if (sessionData.tags) {
      tags = sessionData.tags || [];
    }

    if (sessionData.remarks) {
      remarks = sessionData.remarks || [];
    }


    const extractDate = (timestamp: string): string => {
      if (!timestamp) {
        return '';
      }
      return timestamp.split(' ')[0];
    };

    const formattedSessionId = `Session00${sessionData.sessionId.toString().padStart(4, '0')}`;

    const session = {
      sessionId: sessionData.sessionId, // Keep it as integer
      formattedSessionId, // Use this for display with prefix
      sessionName: sessionData.sessionName,
      customerId: sessionData.customerId,
      createdOn: extractDate(sessionData.createdOn),
      modifiedOn: extractDate(sessionData.modifiedOn),
      followupOn: extractDate(sessionData.followupOn),
      priorityLevel: sessionData.priorityLevel,
      potentialLead: sessionData.potentialLead,
      wealthMode: wealthMode,
      preferredProduct: preferredProduct,
      financialGoal: financialGoal,
      tag: tags.map((tag: any) => tag.tagName),
      remarks: remarks.map((remark: any) => remark.remark),
      tags: tags.map((tag: any) => tag.tagName),
      isActive: sessionData.isActive,
      customerName: customerName,
      additionalInfo: `Additional info for ${sessionData.sessionName}`,
    };
    return session;
  }


  onSearchChange(event: any) {
    this.searchInput = event.target.value;
    if (this.showActiveSessions) {
      this.loadSessions();
    } else {
      this.filterArchivedSessions();
    }

  }

  onArchiveClick(sessionId: string, sessionName: string) {
    const session = this.activeSessions.find(s => s.sessionId === sessionId);

    if (session) {
      if (!session.followupOn) {
        const dialogRef = this.dialog.open(ArchiveConfirmationDialogComponent, {
          width: '435px',
          height: '212px',
          data: { sessionName: sessionName },
        });

        dialogRef.afterClosed().subscribe((result: boolean) => {
          if (result) {
            this.archiveSession(sessionId);
          } else {

          }
        });
      } else {
        this.openBackendErrorDialog('Cannot archive a session with a follow-up date');
      }
    } else {
      console.error('Session not found for ID:', sessionId);
    }
  }

  archiveSession(sessionId: string | number) {
    this.sessionservice.archiveSession(sessionId).subscribe(
      (response) => {
        const sessionIndex = this.activeSessions.findIndex(session => session.sessionId === sessionId);

        if (sessionIndex !== -1) {
          const archivedSession = this.activeSessions.splice(sessionIndex, 1)[0];
          archivedSession.isArchived = true;
          this.archivedSessions.unshift(archivedSession);
          this.updatePagedSessions();

          Swal.fire({
            icon: 'success',
            title: 'Great',
            text: `Session '${archivedSession.sessionName}' archived successfully.`,
          });
        } else {
          console.error('Session not found for ID:', sessionId);
        }
      },
      (error) => {
        console.error('Error archiving session:', error);
        this.openBackendErrorDialog('An error occurred while archiving the session');
      }
    );
  }

  openCreateCustomerGroupDialog(): void {
    const dialogRef = this.dialog.open(CreateCustomerGroupComponent, {
      width: 'auto',
      height: 'auto',
      data: {
        customerGroupName: 'Initial Value',
      },
      autoFocus: true,
      disableClose: true,
    });

  }

  openManageCustomerGroupDialog(): void {
    const dialogRef = this.dialog.open(ManageCustomerGroupComponent, {
      width: 'auto',
      height: 'auto',
      data: {
        customerGroupName: 'Initial Value',
      },
      autoFocus: true,
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }

  openBackendErrorDialog(errorMessage: string): void {
    const dialogRef = this.dialog.open(BackendErrorDialogComponent, {
      data: errorMessage,
      height: '156px',
      width: '440px',
    });

    dialogRef.afterClosed().subscribe(() => {
    });
  }


  onSort(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    if (this.sortColumn === 'priorityLevel') {
      this.activeSessions.sort((a, b) => {
        const priorityOrder = { 'HIGH': 3, 'MEDIUM': 2, 'LOW': 1 };
        const priorityA = priorityOrder[a.priorityLevel];
        const priorityB = priorityOrder[b.priorityLevel];

        if (priorityA < priorityB) {
          return this.sortDirection === 'asc' ? -1 : 1;
        } else if (priorityA > priorityB) {
          return this.sortDirection === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      });
    } else {
    }

    this.updatePagedSessions();
  }



  calculatePaginationRange(): string {
    const startIndex = (this.currentPage - 1) * this.pageSize + 1;
    const endIndex = Math.min(this.currentPage * this.pageSize, this.activeSessions.length);
    return `${startIndex} - ${endIndex} of ${this.activeSessions.length}`;
  }

  currentPageArchived: number = 1;
  recordsPerPageArchived: number = 5; // Set your default value
  totalPagesArchived: number;

  calculatePaginationRangeArchived(): string {
    const start = (this.currentPageArchived - 1) * this.recordsPerPageArchived + 1;
    const end = Math.min(start + this.recordsPerPageArchived - 1, this.archivedSessions.length);
    return `${start} - ${end} of ${this.archivedSessions.length}`;
  }

  prevPageArchived() {
    if (this.currentPageArchived > 1) {
      this.currentPageArchived--;
      this.updatePagedArchivedSessions(); // Add this line to update paged sessions
    }
  }

  nextPageArchived() {
    if (this.currentPageArchived < this.totalPagesArchived) {
      this.currentPageArchived++;
      this.updatePagedArchivedSessions(); // Add this line to update paged sessions
    }
  }

  updatePagedArchivedSessions() {
    const startIndex = (this.currentPageArchived - 1) * this.recordsPerPageArchived;
    this.pagedSessions = this.archivedSessions.slice(startIndex, startIndex + this.recordsPerPageArchived);
  }

  filterArchivedSessions() {
    this.archivedSessions = this.filteredArchivedSessions;
    const searchInputLowerCase = this.searchInput.toLowerCase();

    this.archivedSessions = this.archivedSessions.filter(session => {
      return session.customerName.toLowerCase().includes(searchInputLowerCase)
        || session.formattedSessionId.toLowerCase().includes(searchInputLowerCase)
        || session.sessionName.toLowerCase().includes(searchInputLowerCase);
    }
    );
    this.totalPagesArchived = Math.ceil(this.filteredArchivedSessions.length / this.recordsPerPageArchived);
    this.updatePagedSessions();
  }


  openFilterDialog(): void {
    const dialogRef = this.dialog.open(FilterDialogComponent, {
      height: '521px',
      width: '531px', // Adjust as needed
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (result && result.length > 0) {


          this.activeSessions = result
            .filter(item => !item.isArchived)
            .map(item => this.mapSession(item));

          this.archivedSessions = result
            .filter(item => item.isArchived)
            .map(item => this.mapSession(item));
          this.filterApplied = true;


          if (this.searchInput) {
            const searchInputLowerCase = this.searchInput.toLowerCase();
            const searchInputNumber = parseInt(this.searchInput, 10); // Parse search input as an integer

            this.activeSessions = this.activeSessions.filter(session =>
              session.customerName.toLowerCase().includes(searchInputLowerCase) ||
              session.formattedSessionId.toLowerCase().includes(searchInputLowerCase)
            );

            this.archivedSessions = this.archivedSessions.filter(session =>
              session.customerName.toLowerCase().includes(searchInputLowerCase) ||
              session.formattedSessionId.toLowerCase().includes(searchInputLowerCase)
            );
          }




          this.updatePagedSessions();

        } else {
          console.error('Invalid API response format:', result);
          this.updatePagedSessions();
        }
      }
    });
  }

  cancelFilter() {
    window.location.reload();
    this.filterApplied = false;
  }
  applyFilters(filters: any) {
    if (filters.potentialLead) {
      this.filteredActiveSessions = this.activeSessions.filter(session => session.potentialLead === filters.potentialLead);
      this.filteredArchivedSessions = this.archivedSessions.filter(session => session.potentialLead === filters.potentialLead);
    }
    else {
      this.filteredActiveSessions = [...this.activeSessions];
      this.filteredArchivedSessions = [...this.archivedSessions];
    }
    this.updatePagedSessions();
  }

  isSMEListOpen: boolean = false;
  smeList: { name: string, role: string }[] = [
    { name: 'Mr. Manoj', role: 'Tax consultant' },
    { name: 'Ms. Anusha', role: 'Legal Advisor' },
    { name: 'Mr. Akash', role: 'Insurance agent' }
  ];


  toggleSMEList(closeApplyProduct: boolean): void {
    this.isSMEListOpen = !this.isSMEListOpen;
    if (closeApplyProduct) {
      this.isApplyProductOpen = false;
    }
  }
}
