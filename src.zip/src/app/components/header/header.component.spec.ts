import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent]
    });
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the HeaderComponent', () => {
    expect(component).toBeTruthy();
  });

  it('should render the app name', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.app-name').textContent).toContain('Customer Session Portal');
  });

  it('should contain the logo', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.logo-container img')).toBeTruthy();
  });

  it('should have a primary color toolbar', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.app-header').getAttribute('color')).toBe('primary');
  });
});