import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogoutDialogComponent } from './logout-dialog.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';


describe('LogoutDialogComponent', () => {
  let component: LogoutDialogComponent;
  let fixture: ComponentFixture<LogoutDialogComponent>;
  let dialogRefMock: Partial<MatDialogRef<LogoutDialogComponent>>;
  

  beforeEach(() => {
    dialogRefMock = {
      close: jest.fn() // Mock the close method using jest.fn()
    };
    TestBed.configureTestingModule({
      declarations: [LogoutDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: dialogRefMock },
        { provide: MAT_DIALOG_DATA, useValue: {} }  // Provide the mock MatDialogRef
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(LogoutDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close dialog with true value when "Sign Out" button is clicked', () => {
    component.onYesClick();
    expect(dialogRefMock.close).toHaveBeenCalledWith(true); // Check if close method was called with true
  });

  it('should close dialog with false value when "Cancel" button is clicked', () => {
    component.onNoClick();
    expect(dialogRefMock.close).toHaveBeenCalledWith(false); // Check if close method was called with false
  });
});