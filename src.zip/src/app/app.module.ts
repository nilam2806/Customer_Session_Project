import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RMDashboardComponent } from './components/rmdashboard/rmdashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { MatDialogModule } from '@angular/material/dialog';
import { LogoutDialogComponent } from './components/logout-dialog/logout-dialog.component';
import { SessionService } from './service/rmdashboardservice/get-session-data.service';
import { SessionDetailsModalComponent } from './components/view-session-details/view-session-details.component';
import { FormsModule } from '@angular/forms';
import { EditSessionFormComponent } from './components/edit-session-form/edit-session-form.component';
import { MatSelectModule } from '@angular/material/select';
import { BnNgIdleService } from 'bn-ng-idle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CustomerViewDialogComponent } from './components/customer-view-dialog/customer-view-dialog.component';
import { ArchiveConfirmationDialogComponent } from './components/archive-confirmation-dialog/archive-confirmation-dialog.component';
import { BackendErrorDialogComponent } from './components/backend-error-dialog/backend-error-dialog.component';
import { CreatesessionComponent } from './components/createsession/createsession.component';
import { CreateCustomerGroupComponent } from './components/create-customer-group/create-customer-group.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FilterDialogComponent } from './components/filter-dialog/filter-dialog.component';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { ManageCustomerGroupComponent } from './components/manage-customer-group/manage-customer-group.component';
import { LoadingInterceptor } from 'loading.interceptor';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DatePipe } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RMDashboardComponent,
    HeaderComponent,
    HomeComponent,
    SpinnerComponent,
    LogoutDialogComponent,
    SessionDetailsModalComponent,
    EditSessionFormComponent,
    CustomerViewDialogComponent,
    ArchiveConfirmationDialogComponent,
    BackendErrorDialogComponent,
    CreatesessionComponent,
    CreateCustomerGroupComponent,
    ManageCustomerGroupComponent,
    FilterDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatMenuModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDialogModule,
    FormsModule,
    MatSelectModule,
    MatTabsModule,
    MatSnackBarModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatDividerModule,
    MatChipsModule,
    MatSidenavModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTabsModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTabsModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatTableModule,

   
  ],
  providers: [DatePipe,SessionService, BnNgIdleService, {
    provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true
  }],
  bootstrap: [AppComponent, CreateCustomerGroupComponent]
})
export class AppModule { }
