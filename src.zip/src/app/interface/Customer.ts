
export interface Customer {
    customerId: number;
    customerName: string;
    customerEmail: string;
    wealthMode: string;
    preferredProduct: string;
    financialGoal: string;
  }