import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BnNgIdleService } from 'bn-ng-idle';

import {environment} from '../environments/environment'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CustomerSessionPortal';

  private API_URL = environment.BASE_URL;

  constructor(
    private bnIdle: BnNgIdleService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.bnIdle.startWatching(10000).subscribe((isTimedOut: boolean) => {
      if (isTimedOut) {
        
        // Navigate to login route when the session is expired
        this.router.navigate(['/login']);
      }
    });
  }
}