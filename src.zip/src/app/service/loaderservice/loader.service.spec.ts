import { TestBed } from '@angular/core/testing';
import { LoaderService } from './loader.service';

describe('LoaderService', () => {
  let service: LoaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initially have loading state as false', () => {
    expect(service.getLoading()).toBe(false);
  });

  it('should set loading state correctly', () => {
    service.setLoading(true);
    expect(service.getLoading()).toBe(true);

    service.setLoading(false);
    expect(service.getLoading()).toBe(false);
  });
});