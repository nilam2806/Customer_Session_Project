import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, catchError } from 'rxjs';
import { environment } from 'environments/environment.prod';
import * as apiConstants from 'constants/api.constants';



// Define the Customer interface
export interface Customer {
  customerId: number;
  customerName: string;
  customerEmail: string;
  wealthMode: string;
  preferredProduct: string;
  financialGoal: string;
}

export interface CustomerGroup {
  groupId: number;
  groupName: string;
  customers: Customer[];
}

@Injectable({
  providedIn: 'root'
})
export class CustomerGroupService {

  constructor(private http: HttpClient) { }

  getAllCustomers(): Observable<Customer[]> {

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.getAuthToken()
    });

    return this.http.get<Customer[]>(apiConstants.GET_ALL_CUSTOMERS_URL, { headers });
  }

  private getAuthToken(): string {
    const authToken = localStorage.getItem('jwt');

    if (!authToken) {
      console.warn('Authentication token not found. Returning empty string.');

      
    }

    return authToken || ''; // Provide a default value or handle the missing token appropriately
  }

  createCustomerGroup(customerGroup: CustomerGroup): Observable<CustomerGroup> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.getAuthToken()
    });

    // customer-group.service.ts
    return this.http.post<CustomerGroup>(apiConstants.CREATE_CUSTOMER_GROUP, customerGroup, { headers }).pipe(
      catchError(this.handleError) // You can define your error handling logic here
    );
  }

  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    return new Observable<never>();
  }


  getAllCustomersDetails(): Observable<Customer[]> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.getAuthToken()
    });

    return this.http.get<Customer[]>(apiConstants.GET_ALL_CUSTOMERS_URL, { headers });
  }

  public getAllTags(): Observable<any[]> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.getAuthToken()
    });

    return this.http.get<Customer[]>(apiConstants.get_all_tags, { headers });
  }

  public getCustomersDetailbyName(customerName: string): Observable<Customer[]> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.getAuthToken()
    });

    return this.http.get<Customer[]>(apiConstants.getCustomersDetailbyName + customerName, { headers });
  }

  private handlerError(error: any): void {
    
  }

}
