import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CustomerGroupService, CustomerGroup, Customer } from './customer-group-service.service';
import  * as apiConstants from 'constants/api.constants';

describe('CustomerGroupService', () => {
  let service: CustomerGroupService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CustomerGroupService]
    });
    service = TestBed.inject(CustomerGroupService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should create customer group', () => {
    const mockCustomerGroup: CustomerGroup = {
      groupId: 1,
      groupName: 'Test Group',
      customers: []
    };

    service.createCustomerGroup(mockCustomerGroup).subscribe((response) => {
      expect(response).toEqual(mockCustomerGroup);
    });

    const req = httpMock.expectOne(apiConstants.CREATE_CUSTOMER_GROUP);
    expect(req.request.method).toBe('POST');
    req.flush(mockCustomerGroup);
  });

  it('should handle errors when creating customer group', () => {
    const errorMessage = 'Error creating customer group';
    const errorResponse = { status: 400, statusText: 'Bad Request' };

    service.createCustomerGroup(null).subscribe(
      () => fail('expected an error'),
      (error) => {
        expect(error.message).toContain(errorMessage);
      }
    );

    const req = httpMock.expectOne(apiConstants.CREATE_CUSTOMER_GROUP);
    req.error(new ErrorEvent('error', { message: errorMessage }), errorResponse);
  });
});
