import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { LoginService } from '../loginservice/login.service';

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let mockLoginService: Partial<LoginService>;
  let mockRouter: Partial<Router>;

  beforeEach(() => {
    mockLoginService = {
      isLoggedIn: jest.fn()
    };

    mockRouter = {
      navigate: jest.fn()
    };

    TestBed.configureTestingModule({
      providers: [
        AuthGuard,
        { provide: LoginService, useValue: mockLoginService },
        { provide: Router, useValue: mockRouter }
      ]
    });
    guard = TestBed.inject(AuthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  describe('canActivate', () => {
    it('should return true if user is logged in', () => {
      // Mock user being logged in
      mockLoginService.isLoggedIn = jest.fn(() => true);

      const result = guard.canActivate();

      expect(result).toBe(true);
    });

    it('should return false and navigate to /login if user is not logged in', () => {
      // Mock user not being logged in
      mockLoginService.isLoggedIn = jest.fn(() => false);

      const result = guard.canActivate();

      expect(result).toBe(false);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
    });
  });
});