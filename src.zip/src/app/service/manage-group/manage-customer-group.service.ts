
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { LoginService } from '../loginservice/login.service';
import  * as apiConstants from 'constants/api.constants';


export interface Customer {
  customerId: number;
  customerName: string;
  customerEmail: string;
  wealthMode: string;
  preferredProduct: string;
  financialGoal: string;
}

export interface CustomerGroup {
  groupId: any;
  // groupId: number;
  groupName: string;
  customers: Customer[];
}
@Injectable({
  providedIn: 'root'
})
export class ManageCustomerGroupService {

  private ApiUrl = apiConstants.APP_URL;
  private GET_ALL_CUST_BY_NAME = apiConstants.GET_BY_NAME;
  private GET_ALL_CUST = apiConstants.GET_ALL_CUST;
  private GROUP_LIST = apiConstants.GROUP_LIST;
  private  UPDATE_GROUP = apiConstants. UPDATE_GROUP;
  private DELETE_GROUP = apiConstants.DELETE_GROUP;


  constructor(
    private http: HttpClient,
    private loginService: LoginService
  ) { }

  getGroupList(): Observable<any> {
    const headers = this.createAuthorizationHeader();
    // return this.http.get(`${this.ApiUrl}/customerGroup/getGroupList`, { headers });
    // manage-customer-group.service.ts
    return this.http.get(this.GROUP_LIST, { headers });

  }

  getAllCustomers(): Observable<Customer[]> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<Customer[]>(this.GET_ALL_CUST, { headers });
  }

   getCustomersByGroupName(groupName: string): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get(this.GET_ALL_CUST_BY_NAME+groupName, { headers })
      .pipe(
        catchError(error => {
          console.error('Error fetching customers by group name:', error);
          return throwError(error); // Rethrow the error to be handled by the caller
        })
      );
  }

  private createAuthorizationHeader(): HttpHeaders {
    const authToken = localStorage.getItem('jwt');
    if (authToken) {
      return new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`
      });
    } else {
      console.warn('Authentication token not found. Returning empty headers.');
      return new HttpHeaders();
    }
  }
  private getAuthToken(): string {
    const authToken = localStorage.getItem('jwt');

    if (!authToken) {
      console.warn('Authentication token not found. Returning empty string.');
      // Log additional information if needed
      
    }

    return authToken || ''; // Provide a default value or handle the missing token appropriately
  }


  
  updateCustomerGroup(groupId: number, groupData: any): Observable<any> {
    const authToken = localStorage.getItem('jwt');


    if (!authToken) {
      console.warn('Authentication token not found. Unable to update customer group.');
      return throwError('Unauthorized');
    }


    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`
    });

    const updatedGroupData = { groupId, ...groupData }; 
    
    return this.http.put(this.UPDATE_GROUP, updatedGroupData, { headers }).pipe(
      catchError((error: any) => {
        console.error('Error updating customer group:', error);
        return throwError(error);
      })
    );
  }

  deleteGroup(groupId: number): Observable<any> {
    const headers = this.createAuthorizationHeader();

    return this.http.delete(this.DELETE_GROUP+groupId, { headers })
      .pipe(
        catchError((error: any) => {
          console.error('Error deleting customer group:', error);
          return throwError(error); // Rethrow the error to be handled by the caller
        })
      );
  }
}