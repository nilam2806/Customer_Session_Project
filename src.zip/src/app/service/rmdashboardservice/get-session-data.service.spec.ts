import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SessionService } from './get-session-data.service';
import { Filter_URL, SESSION_URL } from 'constants/api.constants';
import { HttpClient } from '@angular/common/http';

describe('SessionService', () => {
  let service: SessionService;
  let httpMock: HttpTestingController;

  const BASE_URL = 'http://192.168.97.42:9090'; // Base URL for testing
  const POTENTIAL_LEAD_URL = Filter_URL + '/potentialLead/';
  const CREATE_SESSION_URL = SESSION_URL+'/create';
  const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];
  const sessionData = { id: 1, name: 'New Session' };
  const mockResponse = { success: true };
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SessionService]
    });
    service = TestBed.inject(SessionService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should retrieve session data', () => {
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getSessionData().subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne('api/constants/activeSessionsURL');
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should update session', () => {
    const sessionData = { id: 1, name: 'Updated Session' };

    service.updateSession(sessionData).subscribe(data => {
      expect(data).toEqual(sessionData);
    });

    const req = httpMock.expectOne('api/constants/updateSessionURL');
    expect(req.request.method).toBe('PUT');
    req.flush(sessionData);
  });

  it('should retrieve archived sessions', () => {
    const mockData = [{ id: 1, name: 'Archived Session 1' }, { id: 2, name: 'Archived Session 2' }];

    service.getArchivedSessions().subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne('api/constants/archivedSessionsURL');
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should archive session', () => {
    const sessionId = '1';

    service.archiveSession(sessionId).subscribe(data => {
      expect(data).toBeTruthy();
    });

    const req = httpMock.expectOne(`api/constants/archive_session${sessionId}`);
    expect(req.request.method).toBe('POST');
    req.flush({});
  });

  it('should retrieve session data by follow-up date', () => {
    const followUpDate = '2024-02-20';
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getSessionDataByFollowUpDate(followUpDate).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`${service.getBaseUrl()}?followupOn=${followUpDate}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve session data by created date', () => {
    const createdDate = '2024-02-20';
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getSessionDataByCreatedDate(createdDate).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`${service.getBaseUrl()}?createdOn=${createdDate}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve group list', () => {
    const mockData = ['Group 1', 'Group 2'];

    service.getGroupList().subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(service.getGroupListUrl());
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve customer and session by group name', () => {
    const groupName = 'Group 1';
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getCustomerAndSessionByGroupName(groupName).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`${service.getCustomerSessionByGroupUrl()}${groupName}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve customer details by ID', () => {
    const customerId = 123;
    const mockData = { id: customerId, name: 'Customer 1' };

    service.getCustomerDetailsById(customerId).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`api/constants/GET_CUST_DETAIL_BY_ID${customerId}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve session data by modified date', () => {
    const modifiedDate = '2024-02-20';
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getSessionDateBymodifiedDate(modifiedDate).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`${BASE_URL}?modifiedOn=${modifiedDate}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should retrieve session data by potential lead', () => {
    const potentialLead = 'someLead';
    const mockData = [{ id: 1, name: 'Session 1' }, { id: 2, name: 'Session 2' }];

    service.getSessionDataByPotentialLead(potentialLead).subscribe(data => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne(`${POTENTIAL_LEAD_URL}${potentialLead}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should create session', () => {
    spyOn(TestBed.inject(HttpClient), 'post').and.callThrough();

    service.createSession(sessionData).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(CREATE_SESSION_URL);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(sessionData); // Ensure request body matches sessionData
    req.flush(mockResponse);
  });

});
