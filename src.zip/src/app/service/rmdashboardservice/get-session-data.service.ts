// mock-data.service.ts
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginService } from '../loginservice/login.service';
import  * as apiConstants from 'constants/api.constants';

@Injectable({
  providedIn: 'root',
})
export class SessionService {
  private apiURL = apiConstants.APP_URL;
  private activesession = apiConstants.ACTIVE_SESSIONS_URL;
  private getTags = apiConstants.get_tags;
  private archivedSessionsURL = apiConstants.ARCHIVED_SESSIONS_URL; 
  private updateSessionURL = apiConstants.UPDATE_SESSION_URL; 
  private allCustomersURL = apiConstants.GET_ALL_CUSTOMERS_URL;
  private create_session_url = apiConstants.CREATE_SESSION_URL;
  private archive_session = apiConstants.ARCHIVE_SESSION_URL;
  private get_cust_detail_By_Id = apiConstants.GET_CUST_DETAIL_BY_ID ;
  private group_list = apiConstants.GROUP_LIST;
  private customer_session_by_group= apiConstants.CUST_SESSION_BY_GROUP;
  private GetSessionDataByCustomerId = apiConstants.getSessionDataByCustomerId;
  private Getpriority = apiConstants.getSessionDataByCustomerpriority;
  private getpotentiallead = apiConstants.getSessionDataByCustomerpotentiallead;
  private baseUrl = apiConstants.ALL_SESSION_URL;
  private get_Session_DataByDateCritera = apiConstants.getSessionDataByDateCritera;
  

  constructor(private http: HttpClient, private loginservice: LoginService) { }

  getSessionData(): Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.activesession, { headers });
  }

  updateSession(sessionData: any): Observable<any> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.put<any>(this.updateSessionURL, sessionData, { headers });
  }

  getArchivedSessions(): Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.archivedSessionsURL, { headers });
  }

  archiveSession(sessionId: string | number): Observable<any> {
    const headers = this.loginservice.createAuthorizationHeader();
    const url = this.archive_session+sessionId;
    return this.http.post<any>(url, null, { headers });
  }

  getAllCustomerIds(): Observable<number[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.allCustomersURL, { headers })
      .pipe(
        map(customers => customers.map(customer => customer.customerId))
      );
  }

  getCustomerDetailsById(customerId: number): Observable<any> {
    const headers = this.loginservice.createAuthorizationHeader();
    const url = this.get_cust_detail_By_Id+customerId;
    return this.http.get<any>(url, { headers });
  }

  createSession(sessionData: any): Observable<any> {
    
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.post<any>(this.create_session_url, sessionData, { headers });
  }

 getFilteredDataByTags(tag: any): Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.getTags+tag, { headers });
  }
 

  getSessionDataByCustomerId (customerId: string):Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.GetSessionDataByCustomerId+customerId, { headers });
  }

  getSessionDataByPriorityLevel(priorityLevel:string):Observable<any[]>{
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.Getpriority+priorityLevel,{ headers })
 
  }
 
  getSessionDataByPotentialLead(potentialLead:string):Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any>(this.getpotentiallead+potentialLead,{headers})
  }
 
  getSessionDataByDateCritera(dateSearch:string , date:string):Observable<any[]> {
    const headers = this.loginservice.createAuthorizationHeader();

   return this.http.get<any>(`${this.baseUrl}/session/sessions?${dateSearch}=${date}`,{headers});
 
  }
  
  getSessionDataByFollowUpDate(followUpDate: string): Observable<any[]> {
    const url = `${this.baseUrl}?followupOn=${followUpDate}`;
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(url, { headers });
  }

  getSessionDataByCreatedDate(createdDate: string): Observable<any[]> {
    const url = `${this.baseUrl}?createdOn=${createdDate}`;
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(url, { headers });
  }

  getSessionDateBymodifiedDate(modifiedDate: string): Observable<any[]> {
    const url = `${this.baseUrl}?modifiedOn=${modifiedDate}`;
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(url, { headers });
  }

  getGroupList(): Observable<any> {
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.group_list, { headers });
  }

  getSessionByGroupName(groupName: string):Observable<any>{
    const headers = this.loginservice.createAuthorizationHeader();
    return this.http.get<any[]>(this.customer_session_by_group+groupName, { headers });
  }

  getBaseUrl(): string {
    return this.baseUrl;
  }
  
  getGroupListUrl(): string {
    return this.group_list;
  }
  
  getCustomerSessionByGroupUrl(): string {
    return this.customer_session_by_group;
  }
}