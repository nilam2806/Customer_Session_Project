import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { LoginService } from './login.service';

describe('LoginService', () => {
  let service: LoginService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [LoginService]
    });
    service = TestBed.inject(LoginService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should register a user', fakeAsync(() => {
    const mockUserData = { username: 'testUser', password: 'testPassword' };
    const mockResponse = { success: true };

    service.register(mockUserData).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpTestingController.expectOne(request => request.url === service['REGISTER_URL']); // Accessing private property
    expect(req.request.method).toEqual('POST');
    req.flush(mockResponse);

    tick();
  }));

  it('should log in a user', fakeAsync(() => {
    const mockLoginData = { username: 'testUser', password: 'testPassword' };
    const mockResponse = { token: 'mockToken' };

    service.login(mockLoginData).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpTestingController.expectOne(request => request.url === service['LOGIN_URL']); // Accessing private property
    expect(req.request.method).toEqual('POST');
    req.flush(mockResponse);

    tick();
  }));

  it('should clear the JWT token from local storage', () => {
    const initialToken = 'mockToken';
    localStorage.setItem('jwt', initialToken);
    service.clearToken();
    expect(localStorage.getItem('jwt')).toBeNull();
  });
  
});