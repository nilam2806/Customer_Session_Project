// jwt.service.ts

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'environments/environment.prod';
import * as apiConstants from 'constants/api.constants';

const TOKEN_KEY = 'jwt';



@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public TOKEN_KEY = 'jwt';
  private BASE_URL = apiConstants.SESSION_URL;
  private REGISTER_URL = apiConstants.REGISTER_URL;
  private LOGIN_URL = apiConstants.LOGIN_URL;

  constructor(private http: HttpClient) { }

  register(signRequest: any): Observable<any> {

    return this.http.post(this.REGISTER_URL, signRequest);

  }

  login(loginRequest: any): Observable<any> {
    return this.http.post(this.LOGIN_URL, loginRequest);
  }

  // Make createAuthorizationHeader method public
  createAuthorizationHeader(): HttpHeaders | null {
    const jwtToken = localStorage.getItem('jwt');
    if (jwtToken) {
      
      return new HttpHeaders().set(
        "Authorization", "Bearer " + jwtToken
      );
    } else {
      
    }
    return null;
  }

  isLoggedIn(): boolean {
    const jwtToken = localStorage.getItem('jwt');
    return !!jwtToken;
  }

  clearToken() {
    localStorage.removeItem('jwt');
  }
}