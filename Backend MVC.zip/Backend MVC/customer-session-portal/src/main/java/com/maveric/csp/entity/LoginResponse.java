package com.maveric.csp.entity;

public record LoginResponse(String jwt, String loggedInUser) {
}
