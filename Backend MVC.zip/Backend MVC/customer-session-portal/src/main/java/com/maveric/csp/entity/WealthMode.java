package com.maveric.csp.entity;

public enum WealthMode {
	
	CREATION,PRESERVATION,COMBO;

}
