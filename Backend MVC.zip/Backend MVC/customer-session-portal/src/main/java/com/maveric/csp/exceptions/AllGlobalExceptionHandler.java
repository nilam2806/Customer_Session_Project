package com.maveric.csp.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
@RestController
public class AllGlobalExceptionHandler {

	@ExceptionHandler(UserNotFoundException.class)
	public final ResponseEntity<String> handleUserNotFoundException(UserNotFoundException e, WebRequest request) {

		String msg = "User not found.Please enter valid UserId";

		return new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(AllExceptions.class)
	public final ResponseEntity<String> handleAllExceptions(AllExceptions e, WebRequest request) {

		String msg = "Somthing went wrong: " + e.getMessage();

		return new ResponseEntity<>(msg, HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)

	public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {

		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {

			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);

		});
		return errors;
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<String> handleCustomerNotFoundException(CustomerNotFoundException ex) {
		return new ResponseEntity<>("Customer not found: " + ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SessionSaveException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<String> handleSessionSaveException(SessionSaveException ex) {
		return new ResponseEntity<>("Failed to save the session: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	
	@ExceptionHandler(SessionNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<String> handleSessionNotFoundException(SessionNotFoundException ex) {
		return new ResponseEntity<>("Session not found: " + ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(GetActiveSessionsException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<String> handleGetActiveSessionsException(GetActiveSessionsException ex) {
		return new ResponseEntity<>("Failed to get active sessions: " + ex.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(ArchivedSessionNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<String> handleArchivedSessionNotFoundException(ArchivedSessionNotFoundException ex) {
		return new ResponseEntity<>("Archived session not found: " + ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(GetArchivedSessionsException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<String> handleGetArchivedSessionsException(GetArchivedSessionsException ex) {
		return new ResponseEntity<>("Failed to get archived sessions: " + ex.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	 @ExceptionHandler(ArchiveSessionException.class)
	    @ResponseStatus(HttpStatus.OK)
	    public ResponseEntity<String> handleArchiveSessionException(ArchiveSessionException ex) {
	        return new ResponseEntity<>("Follow-up date is in the future. Cannot archive Session", HttpStatus.OK);
	    }
	 
	 @ExceptionHandler(DuplicateNameException.class)
	 @ResponseStatus(HttpStatus.OK)
		public ResponseEntity<String> handleDuplicateNameException(DuplicateNameException ex) {
			return new ResponseEntity<>("Duplicate name: " + ex.getMessage(),
					HttpStatus.OK);
		}
	 
	 @ExceptionHandler(Exception.class)
		@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
		public ResponseEntity<String> handleGeneralException(Exception ex) {
			return new ResponseEntity<>("An error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

}
