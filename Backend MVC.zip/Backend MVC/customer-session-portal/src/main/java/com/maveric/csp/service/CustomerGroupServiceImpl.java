package com.maveric.csp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.csp.entity.Customer;
import com.maveric.csp.entity.CustomerGroup;
import com.maveric.csp.entity.CustomerGroupReference;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.exceptions.DuplicateNameException;
import com.maveric.csp.repository.CustomerGroupReferenceRepository;
import com.maveric.csp.repository.CustomerGroupRepository;
import com.maveric.csp.repository.CustomerRepository;
import com.maveric.csp.repository.SessionRepository;

import jakarta.transaction.Transactional;

@Service
public class CustomerGroupServiceImpl implements CustomerGroupService {

	@Autowired
	CustomerGroupRepository customerGroupRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerGroupReferenceRepository referenceRepository;
	
	@Autowired
	private SessionRepository SessionRepository;

//*************************************** createCustomerGroup **************************************************
	
	@Override
	public CustomerGroup createCustomerGroup(CustomerGroup group) {

		Optional<CustomerGroup> dbGroup = customerGroupRepository.findByGroupName(group.getGroupName());

		System.out.println(dbGroup);

		if (dbGroup.isPresent()) {

			throw new DuplicateNameException("Group name is Duplicate");

		} else {
			CustomerGroup savedGroup = customerGroupRepository.save(group);
			List<Customer> customers = group.getCustomers();
			if (customers != null) {
				for (Customer customer : customers) {

					CustomerGroupReference reference = new CustomerGroupReference();
					Optional<Customer> foundCustomer = customerRepository.findById(customer.getCustomerId());

					if (foundCustomer.isPresent()) {

						Customer dbCustomer = foundCustomer.get();
						reference.setCustomerId(dbCustomer.getCustomerId());
					}
					reference.setGroupId(savedGroup.getGroupId());

					referenceRepository.save(reference);
				}
			}
			return savedGroup;
		}
	}

//*************************************** GetCustomerByGroupName *************************************************************************************************
	

	@Override
	public List<CustomerGroup> getCustomerByGroupName(String groupName) {

		CustomerGroup customerGroup = new CustomerGroup();

		List<CustomerGroup> customerGroups = new ArrayList<>();
		List<Customer> customers = new ArrayList<>();

		Optional<CustomerGroup> foundGroup = customerGroupRepository.findByGroupName(groupName);

		if (foundGroup.isPresent()) {

			CustomerGroup group = foundGroup.get();

			List<CustomerGroupReference> reference = referenceRepository.findByGroupId(group.getGroupId());

			for (CustomerGroupReference cref : reference) {
				Optional<Customer> customer = customerRepository.findById(cref.getCustomerId());

				if (customer.isPresent()) {
					Customer cust = customer.get();
					customers.add(cust);
				}
			}

			customerGroup.setGroupName(groupName);
			customerGroup.setCustomers(customers);
			customerGroup.setGroupId(group.getGroupId());

			customerGroups.add(customerGroup);

		}

		return customerGroups;
	}

//*************************************** deleteCustomerGroup * *************************************************
	

	@Override
	public String deleteCustomerGroup(int groupId) {

		Optional<CustomerGroup> foundGroup = customerGroupRepository.findById(groupId);

		if (foundGroup.isPresent()) {
			customerGroupRepository.deleteById(groupId);

			List<CustomerGroupReference> groupReferences = referenceRepository.findByGroupId(groupId);
			referenceRepository.deleteAll(groupReferences);

			return "Success";
		} else {
			throw new AllExceptions("CustomerGroup is not Found");
		}
	}

//* *************************************** getAllCustomerGroup **************************************************
	

	@Override
	public List<CustomerGroup> getAllCustomerGroup() {

		List<CustomerGroup> list = customerGroupRepository.findAll();

		return list;
	}

	

	
	@Transactional

	public CustomerGroup updateCustomerGroup(CustomerGroup group) {

		Optional<CustomerGroup> dbGroup = customerGroupRepository.findById(group.getGroupId());

		if (dbGroup.isEmpty()) {

			throw new AllExceptions("Group not found with ID: " + group.getGroupId());

		}

		CustomerGroup existingGroup = dbGroup.get();

		// Check if the group name has been changed

		if (!group.getGroupName().equals(existingGroup.getGroupName())) {

			// Check if the new group name already exists among other groups

			List<CustomerGroup> dbGroupList = customerGroupRepository.findAll();

			boolean flag = dbGroupList.stream().anyMatch(t -> t.getGroupName().equals(group.getGroupName()));

			if (flag) {

				throw new DuplicateNameException("Group name already exists");

			}

		}

		// Update the group name if it has been changed

		existingGroup.setGroupName(group.getGroupName());

		// Save the updated group

		CustomerGroup savedGroup = customerGroupRepository.save(existingGroup);

		// Delete existing references

		referenceRepository.deleteByGroupId(savedGroup.getGroupId());

		// Save updated references

		List<Customer> updatedCustomers = group.getCustomers();

		if (updatedCustomers != null) {

			for (Customer customer : updatedCustomers) {

				Optional<Customer> foundCustomer = customerRepository.findById(customer.getCustomerId());

				if (foundCustomer.isPresent()) {

					Customer dbCustomer = foundCustomer.get();

					CustomerGroupReference reference = new CustomerGroupReference();

					reference.setCustomerId(dbCustomer.getCustomerId());

					reference.setGroupId(savedGroup.getGroupId());

					referenceRepository.save(reference);

				}

			}

		}

		return savedGroup;

	}
	
//	
//	@Override
//    public  List<Object[]> getSessionByGroupName(String groupName) {
//        return SessionRepository.findByCustomerGroupName(groupName);
//    }
	
	public List<Map<String, Object>> getSessionByGroupName(String groupName) {
        List<Object[]> sessions = SessionRepository.findByCustomerGroupName(groupName);
        List<Map<String, Object>> sessionList = new ArrayList<>();
 
        for (Object[] session : sessions) {
            Map<String, Object> sessionMap = new HashMap<>();
            sessionMap.put("customerId", session[0]);
            sessionMap.put("customerName", session[1]);
            sessionMap.put("sessionId", session[2]);
            sessionMap.put("modifiedBy", session[3]);
            sessionMap.put("modifiedOn", session[4]);
           // sessionMap.put("sessionId", session[5]);
            sessionMap.put("followupOn", session[6]);
            sessionMap.put("potentialLead", session[7]);
            sessionMap.put("createdBy", session[8]);
            sessionMap.put("createdOn", session[9]);
            // Add other session attributes in the same format
            sessionMap.put("isActive", session[10]);
            sessionMap.put("priorityLevel", session[11]);
            sessionMap.put("sessionName", session[12]);
            sessionList.add(sessionMap);
        }
 
        return sessionList;
    }

}