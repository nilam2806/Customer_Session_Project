package com.maveric.csp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.csp.entity.PotentialLead;
import com.maveric.csp.entity.PriorityLevel;
import com.maveric.csp.entity.Session;

@Service
public interface SessionService {

	Session createSession(Session sessionRequest);
	
	Session updateSession(Session session);
	
	Session makeArchiveSession(int sessionId);

	List<Session> getActiveSessions();

	List<Session> getArchivedSessions();

	Session getSessionById(int sessionId);

	List<Session> getSessionBycustomerID(long customerID);

	List<Session> getSessionByPotentialLead(PotentialLead potentialLead);

	List<Session> getByCreatedOn(String createdOn);
	
	List<Session> getSessionByPriorityLevel(PriorityLevel priorityLevel);

	List<Session> getCreatedOnFromDateTodateSession(String fromDate, String toDate);

	List<Session> getModifiedOnFromDateTodateSession(String fromDate, String toDate);

	List<Session> getByModifiedOn(String modifiedOn);

	List<Session> getByfollowUpOn(String followupOn);

	public void autoArchiveSessionsDaily();

	List<Session> getSessionsByDateRange(String fromDate, String toDate, String dateType);

	List<Session> getBygroupName(String groupName);


	

}
