package com.maveric.csp.entity;

public enum PotentialLead {
	 
	YES("Yes"), NO("No");
	private String level;
	
	private PotentialLead() {
	}
	
	private PotentialLead(String level) {
		this.level=level;
	}
 
	public String getLevel() {
		return level;
	}
 
	public void setLevel(String level) {
		this.level = level;
	}
	
	
}
 