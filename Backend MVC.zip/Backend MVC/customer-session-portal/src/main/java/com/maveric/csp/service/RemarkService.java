package com.maveric.csp.service;

import org.springframework.stereotype.Service;

import com.maveric.csp.entity.Remark;

@Service
public interface RemarkService {

	Remark addRemark(Remark remark);

}
