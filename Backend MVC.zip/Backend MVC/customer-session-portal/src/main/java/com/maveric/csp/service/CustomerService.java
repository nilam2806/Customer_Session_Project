package com.maveric.csp.service;

import java.util.List;

import com.maveric.csp.entity.Customer;

public interface CustomerService {

	public Customer saveCustomer(Customer customer);

	public Customer getCustomerById(long customerId);

	public List<Customer> getAllCustomers();

	public Customer updateCustomer(Customer customer);

	public List<Customer> getCustomerBycustomerName(String customerName);

}
