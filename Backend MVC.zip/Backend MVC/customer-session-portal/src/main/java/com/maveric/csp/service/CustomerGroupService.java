package com.maveric.csp.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.maveric.csp.entity.CustomerGroup;
import com.maveric.csp.entity.Session;

@Service
public interface CustomerGroupService {

	CustomerGroup createCustomerGroup(CustomerGroup group);
	
	CustomerGroup updateCustomerGroup(CustomerGroup group);
	
	List<CustomerGroup> getCustomerByGroupName(String groupName);
	
	List<CustomerGroup> getAllCustomerGroup();
	
	String deleteCustomerGroup(int groupId);
	 List<Map<String, Object>> getSessionByGroupName(String groupName);
}
