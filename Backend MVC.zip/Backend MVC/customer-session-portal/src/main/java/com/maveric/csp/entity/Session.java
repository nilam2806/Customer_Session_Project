package com.maveric.csp.entity;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
public class Session implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sessionId;
	
	@NotNull(message = " sessionName cannot be null")
	private String sessionName;

	@NotNull(message = " customerId cannot be null")
	private long customerId;

	private String createdOn;

	private String modifiedOn;

	private String createdBy;

	private String modifiedBy;

	private String followupOn;

	@Enumerated(EnumType.STRING)
	private PriorityLevel priorityLevel;

	@Enumerated(EnumType.STRING)
	private PotentialLead potentialLead;

	@Transient
	private List<Remark> remarks;

	@Transient
	private Customer customerDetails;

	@Transient
	private List<Tag> tags;

	private String isActive;

	

}
