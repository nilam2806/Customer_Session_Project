package com.maveric.csp.util;

import java.util.Random;

public class AppUtil {

	public static int getRandomNumber() {

		Random random = new Random();
		int number = random.nextInt(900) + 100;
		return number;
	}

}
