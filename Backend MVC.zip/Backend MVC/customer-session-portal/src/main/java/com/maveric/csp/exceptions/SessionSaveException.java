package com.maveric.csp.exceptions;
public class SessionSaveException extends RuntimeException {

    public SessionSaveException(String message) {
        super(message);
    }
}
