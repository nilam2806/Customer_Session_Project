package com.maveric.csp.exceptions;
public class ArchivedSessionNotFoundException extends RuntimeException {

    public ArchivedSessionNotFoundException(String message) {
        super(message);
    }
}