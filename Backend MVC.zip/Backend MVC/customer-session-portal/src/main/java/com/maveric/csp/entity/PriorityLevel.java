package com.maveric.csp.entity;

public enum PriorityLevel {
	
	 
    HIGH("HIGH"), MEDIUM("HIGH"), LOW("HIGH");
	
	private String level;
	private PriorityLevel() {
	}
	
	private PriorityLevel(String level) {
		this.level=level;
	}
 
	public String getLevel() {
		return level;
	}
 
	public void setLevel(String level) {
		this.level = level;
	}
	
	
	
 
}