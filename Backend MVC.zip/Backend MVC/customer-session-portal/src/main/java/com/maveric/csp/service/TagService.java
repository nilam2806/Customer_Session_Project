package com.maveric.csp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.csp.entity.Session;
import com.maveric.csp.entity.Tag;

@Service
public interface TagService {

	Tag addRemark(Tag tag);

	List<Session> getSessionByTagName(String tagName);

	List<String> getAllTags();

	

}
