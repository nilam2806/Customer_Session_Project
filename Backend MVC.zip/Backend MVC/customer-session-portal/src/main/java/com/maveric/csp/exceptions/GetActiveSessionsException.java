package com.maveric.csp.exceptions;
public class GetActiveSessionsException extends RuntimeException {

    public GetActiveSessionsException(String message) {
        super(message);
    }
}