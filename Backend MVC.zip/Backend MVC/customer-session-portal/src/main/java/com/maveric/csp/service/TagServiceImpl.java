package com.maveric.csp.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.csp.entity.Customer;
import com.maveric.csp.entity.Remark;
import com.maveric.csp.entity.Session;
import com.maveric.csp.entity.Tag;
import com.maveric.csp.repository.CustomerRepository;
import com.maveric.csp.repository.RemarkRepository;
import com.maveric.csp.repository.SessionRepository;
import com.maveric.csp.repository.TagRepository;

@Service
public class TagServiceImpl implements TagService {

	private static final Logger log = LoggerFactory.getLogger(TagServiceImpl.class);

	@Autowired
	TagRepository tagRepository;

	@Autowired
	SessionRepository sessionRepository;

	@Autowired
	RemarkRepository remarkRepository;
	
	@Autowired 
	CustomerRepository customerRepository;

	@Override
	public Tag addRemark(Tag tag) {

		Tag savedTag = tagRepository.save(tag);

		if (savedTag != null) {
			return savedTag;
		}
		return savedTag;
	}

	@Override
	public List<Session> getSessionByTagName(String tagName) {

		List<Tag> tagList = tagRepository.findByTagName(tagName);
		List<Session> sessionList = new ArrayList<>();

		for (Tag tag : tagList) {

			Session session = sessionRepository.findById(tag.getSessionId()).get();
			List<Tag> tags = tagRepository.findBySessionId(session.getSessionId());
			List<Remark> remarks = remarkRepository.findBySessionId(session.getSessionId());
			Customer customer = customerRepository.findById(session.getCustomerId()).get();
			session.setCustomerDetails(customer);
			session.setTags(tags);
			session.setRemarks(remarks);
			sessionList.add(session);

		}

		return sessionList;
	}

	@Override
	public List<String> getAllTags() {
		List<String> tags = tagRepository.findAllTags();

		if (tags.isEmpty()) {

			log.error("list is empty");
		}
		
		return tags;

	}



}
