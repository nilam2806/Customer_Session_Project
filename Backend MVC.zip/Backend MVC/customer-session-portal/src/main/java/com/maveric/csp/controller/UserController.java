package com.maveric.csp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.csp.entity.User;
import com.maveric.csp.service.UserSevice;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

	private static final Logger log = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserSevice userSevice;

	@Operation(summary = "API to Create User")
	@PostMapping("/save")
	public ResponseEntity<User> saveUser(@Valid @RequestBody User user) {

		log.info("UserController : saveUser() : Call Started");
		log.info("RequestBody = " + user);

		
		User savedUser = userSevice.saveUser(user);

		if (savedUser != null) {

			log.info("UserController : saveUser() : Call Ended");
			return new ResponseEntity<>(savedUser, HttpStatus.CREATED);

		} else {

			log.error("Something Went wrong while saving User");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Operation(summary = "API to Get user details by Id")
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable int userId) {

		log.info("UserController : getUserById() : Call Started");
		log.info("UserId= " + userId);

		User user = userSevice.getUserById(userId);

		if (user != null) {

			log.info("UserController : getUserById() : Call Ended");
			return new ResponseEntity<>(user, HttpStatus.OK);
		} else {

			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@Operation(summary = "API to Get all Users")
	@GetMapping("/getAll")
	public ResponseEntity<List<User>> getAllUser() {

		log.info("UserController : getAll() : Call Started");

		List<User> allUser = userSevice.getAllUser();

		log.info("UserController : getAll() : Call Ended");

		return new ResponseEntity<>(allUser, HttpStatus.OK);
	}

	@Operation(summary = "API to update User details")
	@PutMapping("/update")
	public ResponseEntity<User> updateUser(@RequestBody User user) {

		log.info("UserController : updateUser() : Call Started");

		User updatedUser = userSevice.updateUser(user);

		if (updatedUser != null) {

			log.info("UserController : updateUser() : Call Ended");
			return new ResponseEntity<>(updatedUser, HttpStatus.OK);

		} else {

			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Operation(summary = "Api to delete User")
	@DeleteMapping("/delete/{userId}")
	public String deleteById(@Parameter(description = "User of this ID will delete") @PathVariable int userId) {

		log.info("UserController : deleteById() : Call Started");

		userSevice.deleteUserById(userId);

		log.info("UserController : deleteById() : Call Ended");
		return "User Deleted Successfully";
	}

}
