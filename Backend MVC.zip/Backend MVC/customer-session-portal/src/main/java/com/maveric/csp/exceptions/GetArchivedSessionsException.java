package com.maveric.csp.exceptions;
public class GetArchivedSessionsException extends RuntimeException {

    public GetArchivedSessionsException(String message) {
        super(message);
    }
}