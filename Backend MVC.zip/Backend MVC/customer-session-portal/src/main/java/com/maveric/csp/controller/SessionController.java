package com.maveric.csp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.csp.entity.PotentialLead;
import com.maveric.csp.entity.PriorityLevel;
import com.maveric.csp.entity.Session;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.repository.CustomerRepository;
import com.maveric.csp.service.SessionService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/session")
public class SessionController {

	private static final Logger log = LoggerFactory.getLogger(SessionController.class);

	@Autowired
	SessionService sessionService;

	@Autowired
	CustomerRepository customerRepository;

// **********************************Create Session*************************************************************	
	@Operation(summary = "API to Create Session")
	@PostMapping("/create")
	public ResponseEntity<Session> createSession(@Valid @RequestBody Session session) {

		Session savedSession = null;

		log.info("SessionController : createSession() : Call Started");
		log.info("RequestBody = " + session);

		savedSession = sessionService.createSession(session);

		if (savedSession != null) {
			log.info("SessionController : createSession() : Call Ended");
			log.info("RequestBody = " + session);
			return new ResponseEntity<>(savedSession, HttpStatus.CREATED);
		} else {
			throw new SessionSaveException("Failed to save the session");
		}

	}

// **********************************Make Session Archived*************************************************************	

	@Operation(summary = "API to make Session Archive")
	@PostMapping("/archive/{sessionId}")
	public ResponseEntity<Session> makeArchiveSession(@PathVariable("sessionId") int sessionId) {
		log.info("SessionController : makeArchiveSession() : Call Started");

		Session archivedSession = sessionService.makeArchiveSession(sessionId);
		if (archivedSession != null) {
			log.info("SessionController : makeArchiveSession() : Call Ended");
			return new ResponseEntity<>(archivedSession, HttpStatus.OK);
		} else {
			throw new ArchiveSessionException("Failed to archive session");

		}

	}

// **********************************Updated Session Api*************************************************************	

	@Operation(summary = "API to update Session")
	@PutMapping("/update")
	public ResponseEntity<Session> updateSession(@RequestBody Session session) {

		log.info("SessionController : updateSession() : Call Started");

		Session updatedSession = sessionService.updateSession(session);

		if (updatedSession != null) {
			log.info("SessionController : updateSession() : Call Ended");
			return new ResponseEntity<>(updatedSession, HttpStatus.OK);
		} else {
			throw new AllExceptions("Failed to update session");
		}

	}
// **********************************View session by sessionId*************************************************************	

	@Operation(summary = "API to view session by sessionId")
	@GetMapping("/{sessionId}")
	public ResponseEntity<Session> getSessionById(@PathVariable("sessionId") int sessionId) {
		log.info("SessionController : getSessionById() : Call Started");
		Session session = sessionService.getSessionById(sessionId);

		if (session != null) {
			log.info("SessionController : getSessionById() : Call Ended");
			return new ResponseEntity<>(session, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

// *******************************View Active Sessions on Dashboard*************************************************************	

	@Operation(summary = "API to View Active Sessions on Dashboard")
	@GetMapping("/activeSessions")
	public ResponseEntity<List<Session>> getActiveSessions() {

		log.info("SessionController : getActiveSessions() : Call Started");

		List<Session> sessionList = sessionService.getActiveSessions();

		if (sessionList != null && !sessionList.isEmpty()) {

			log.info("SessionController : getActiveSessions() : Call Ended");
			return new ResponseEntity<>(sessionList, HttpStatus.OK);

		} else {

			throw new SessionNotFoundException("No active sessions found");
		}

	}

//*********************************view Archived session on dashboard******************************************************

	@Operation(summary = "API to view Archived session on dashboard")
	@GetMapping("/archivedsessions")
	public ResponseEntity<List<Session>> getArchiveSessions() {

		
			log.info("SessionController : getArchiveSessions() : Call Started");

			List<Session> sessionList = sessionService.getArchivedSessions();

			if (sessionList != null && !sessionList.isEmpty()) {

				log.info("SessionController : getArchiveSessions() : Call Ended");
				return new ResponseEntity<>(sessionList, HttpStatus.OK);

			} else {

				throw new SessionNotFoundException("No archived sessions found");
			}

		} 
	
/* *********************************View session by customerID************************************************************ */

	@Operation(summary = "API to view session by customerID")
	@GetMapping("/customerID/{customerID}")
	public ResponseEntity<List<Session>> getSessionsBycustomerId(@PathVariable("customerID") Long customerID) {
		log.info("SessionController : getSessionsBycustomerId() : Call Started");
		List<Session> sessionList = sessionService.getSessionBycustomerID(customerID);

		if (sessionList != null) {
			log.info("SessionController : getSessionById() : Call Ended");
			return new ResponseEntity<>(sessionList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

/* **********************************View session by potentialLead*********************************************************** */

	@Operation(summary = "API to Get Session by PotentialLead")
	@GetMapping("/potentialLead/{potentialLead}")
	public ResponseEntity<List<Session>> getByPotentialLead(
			@PathVariable("potentialLead") String potentialLead) {
		log.info("SessionController : getByPotentialLead() : Call Started");
		List<Session> sessionList = sessionService.getSessionByPotentialLead(PotentialLead.valueOf(potentialLead));
 
		if (sessionList != null) {
			log.info("SessionController : getByPotentialLead() : Call Ended");
			return new ResponseEntity<>(sessionList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
 
	}

/* **********************************View session by priorityLevel************************************************************ */	

	@Operation(summary = "API to Get Session by priorityLevel")
	@GetMapping("/priorityLevel/{priorityLevel}")
	public ResponseEntity<List<Session>> getByPriorityLevel(
			@PathVariable("priorityLevel") String priorityLevel) {
		log.info("SessionController : getByPriorityLevel() : Call Started");
		List<Session> sessionList = sessionService.getSessionByPriorityLevel(PriorityLevel.valueOf(priorityLevel));
 
		if (sessionList != null) {
			log.info("SessionController : getByPriorityLevel() : Call Ended");
			return new ResponseEntity<>(sessionList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
 
	}

	
////********************************** Auto Archive*************************************************************	
	@Operation(summary = "API to Auto Archive Session")
	@GetMapping("/auto-archive")
    public ResponseEntity<String> autoArchiveSessions() {
        try {
            sessionService.autoArchiveSessionsDaily();
            return new ResponseEntity<>("Sessions auto-archived successfully.", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error auto-archiving sessions: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	
	

////**********************************filter By date************************************************************	
	
//	
//	@Operation(summary = "API to get sessions based on date criteria")
//	@GetMapping("/sessions")
//	public ResponseEntity<List<Session>> getSessions(
//	        @RequestParam(name = "createdOn", required = false) String createdOn,
//	        @RequestParam(name = "modifiedOn", required = false) String modifiedOn,
//	        @RequestParam(name = "followupOn", required = false) String followupOn,
//	        @RequestParam(name = "fromDate", required = false) String fromDate,
//	        @RequestParam(name = "toDate", required = false) String toDate,
//	        @RequestParam(name = "dateType", defaultValue = "") String dateType) {
// 
//	    log.info("SessionController : getSessions() : Call Started");
// 
//	    try {
//	        List<Session> sessionList = null;
// 
//	        if (!dateType.isEmpty()) {
//	            // Use the provided dateType parameter
//	            sessionList = sessionService.getSessionsByDateRange(fromDate, toDate, dateType);
//	        } else if (createdOn != null) {
//	            // Use createdOn parameter for searching
//	            sessionList = sessionService.getByCreatedOn(createdOn);
//	        } else if (modifiedOn != null) {
//	            // Use modifiedOn parameter for searching
//	            sessionList = sessionService.getByModifiedOn(modifiedOn);
//	        } else if (followupOn != null) {
//	            // Use followupOn parameter for searching
//	            sessionList = sessionService.getByfollowUpOn(followupOn);
//	        } else {
//	            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//	        }
// 
//	        if (sessionList != null && !sessionList.isEmpty()) {
//	            log.info("SessionController : getSessions() : Call Ended");
//	            return ResponseEntity.ok(sessionList);
//	        } else {
//	            return ResponseEntity.notFound().build();
//	        }
//	    } catch (SessionNotFoundException e) {
//	    	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//	    } catch (Exception e) {
//	        // Log the exception or handle it based on your application's error-handling strategy
//	    	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	    }
//	}
	
	
	@Operation(summary = "API to get sessions based on date criteria")
	@GetMapping("/sessions")
	public ResponseEntity<List<Session>> getSessions(
	        @RequestParam(name = "createdOn", required = false) String createdOn,
	        @RequestParam(name = "modifiedOn", required = false) String modifiedOn,
	        @RequestParam(name = "followupOn", required = false) String followupOn,
	        @RequestParam(name = "fromDate", required = false) String fromDate,
	        @RequestParam(name = "toDate", required = false) String toDate,
	        @RequestParam(name = "dateType", defaultValue = "") String dateType) {
 
	    log.info("SessionController : getSessions() : Call Started");
 
	    try {
	        List<Session> sessionList = null;
 
	        if (!dateType.isEmpty()) {
	            sessionList = sessionService.getSessionsByDateRange(fromDate, toDate, dateType);
	        } else if (createdOn != null) {
	            sessionList = sessionService.getByCreatedOn(createdOn);
	        } else if (modifiedOn != null) {
	            sessionList = sessionService.getByModifiedOn(modifiedOn);
	        } else if (followupOn != null) {
	            sessionList = sessionService.getByfollowUpOn(followupOn);
	        } else {
	            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        }
 
	        if (sessionList != null && !sessionList.isEmpty()) {
	            log.info("SessionController : getSessions() : Call Ended");
	            return ResponseEntity.ok(sessionList);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    } catch (SessionNotFoundException e) {
	    	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    } catch (Exception e) {
	    	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	    }
	}

	
	@Operation(summary = "API to get session by Group Name")
	@GetMapping("/groupName/{groupName}")
	public ResponseEntity<List<Session>> getBygroupName(@PathVariable("groupName") String groupName) {
		log.info("SessionController : getBygroupName() : Call Started");
		List<Session> sessionList = sessionService.getBygroupName(groupName);

		if (sessionList != null) {
			log.info("SessionController : getBygroupName() : Call Ended");
			return new ResponseEntity<>(sessionList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

}
