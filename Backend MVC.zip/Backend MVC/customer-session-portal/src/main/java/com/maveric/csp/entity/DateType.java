package com.maveric.csp.entity;
public enum DateType {
    CREATED_ON,
    MODIFIED_ON,
    FOLLOWUP_ON
}
