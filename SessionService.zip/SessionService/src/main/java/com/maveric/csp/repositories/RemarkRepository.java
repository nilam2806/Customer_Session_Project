package com.maveric.csp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.maveric.csp.entities.Remark;

@Repository
public interface RemarkRepository extends JpaRepository<Remark, Integer>{
	
	List<Remark> findBySessionId(int i);

}
