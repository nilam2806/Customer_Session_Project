package com.maveric.csp.entities;

public enum PotentialLead {

	YES, NO;
}
