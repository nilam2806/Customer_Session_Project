package com.maveric.csp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.services.TagService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/tag")
public class TagController {

	private static final Logger log = LoggerFactory.getLogger(TagController.class);

	@Autowired
	public TagService tagService;

	@Operation(summary = "API to add Tag")
	@PostMapping("/add")
	public ResponseEntity<Tag> addTag(@RequestBody Tag tag) {

		log.info("TagController : addTag() : Call Started");

		Tag addedTag = tagService.addRemark(tag);

		if (tag != null) {

			log.info("TagController : addTag() : Call Ended");
			return new ResponseEntity<>(addedTag, HttpStatus.CREATED);

		} else {

			log.error("Something Went wrong while saving Tag");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Operation(summary = "API to get Tags by TagName")
	@GetMapping("/get/{tagName}")
	public ResponseEntity<List<Session>> getSessionByTagName(@PathVariable("tagName") String tagName) {

		log.info("TagController : getSessionByTagName() : Call Started");

		List<Session> tagList = tagService.getSessionByTagName(tagName);

		if (tagList != null) {

			log.info("TagController : getSessionByTagName() : Call Ended");
			return new ResponseEntity<>(tagList, HttpStatus.OK);

		} else {

			log.error("Something Went wrong while saving Tag");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Operation(summary = "API to get All tags")
	@GetMapping("/allTags")
	public ResponseEntity<List<String>> allTags() {

		log.info("TagController : getSessionByTagName() : Call Started");

		List<String> tagList = tagService.getAllTags();

		if (tagList != null) {

			log.info("TagController : getSessionByTagName() : Call Ended");
			return new ResponseEntity<>(tagList, HttpStatus.OK);

		} else {

			log.error("Something Went wrong while saving Tag");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}
