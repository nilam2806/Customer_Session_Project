package com.maveric.csp.dtos;

import java.util.List;

import jakarta.persistence.Transient;
import lombok.Data;

@Data
public class CustomerGroupDTO {
	private int groupId;
	private String groupName;
	private List<CustomerDTO> customers;

}
