package com.maveric.csp.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;

@ControllerAdvice
public class AllGlobalExceptionHandler {
	
	@ExceptionHandler(SessionSaveException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<String> handleSessionSaveException(SessionSaveException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(SessionNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<String> handleSessionNotFoundException(SessionNotFoundException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	 @ExceptionHandler(ArchiveSessionException.class)
	    @ResponseStatus(HttpStatus.OK)
	    public ResponseEntity<String> handleArchiveSessionException(ArchiveSessionException e) {
	        return new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
	    }
	 
	 @ExceptionHandler(Exception.class)
		@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
		public ResponseEntity<String> handleGeneralException(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

}
