package com.maveric.csp.repositories;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;

@Repository
public interface SessionRepository extends JpaRepository<Session, Integer> {
	
	Optional<Session> findBySessionId(int sessionId);
	List<Session> findByCustomerId(long customerId);
	List<Session> findByIsActive(String isactive);
	List<Session> findByPotentialLead(PotentialLead potentialLead);
	List<Session> findByPriorityLevel(PriorityLevel priorityLevel);
	
	List<Session> findByCreatedOn(String createdOn);
	
	@Query(value = "SELECT * FROM session s where s.created_on like %?1%", nativeQuery = true)
	List<Session> getSessionByCreatedOn(String createdOn);
	
	@Query(value = "SELECT * FROM session s where s.created_on between ?1 And ?2", nativeQuery = true)
	List<Session> getCreatedOnFromDateTodateSession(String fromDate, String todate);
	
	@Query(value = "SELECT * FROM session s where s.modified_on like %?1%", nativeQuery = true)
	List<Session> getSessionByModifiedOn(String modifiedOn);
	
	@Query(value = "SELECT * FROM session s where s.modified_on between ?1 And ?2", nativeQuery = true)
	List<Session> getModifiedOnFromDateTodateSession(String fromDate, String toDate);
	
	
	@Query(value = "SELECT * FROM session s where s.followup_on like %?1%", nativeQuery = true)
	List<Session> getSessionByFollowupOn(String followupOn);
	
	@Query(value = "SELECT * FROM session s where followup_on between ?1 And ?2", nativeQuery = true)
	List<Session> getFollowUpOnFromDateTodateSession(String fromDate, String toDate);
	
	
	@Query(value = "SELECT * FROM session WHERE modified_on < DATE_SUB(CURDATE(), INTERVAL 10 DAY);", nativeQuery = true)
	List<Session> findByUpdatedDateBefore(LocalDate date);
	
	@Query( 
	        nativeQuery = true, 
	        value 
	        = "SELECT c.customer_id, c.customer_name, s.*\r\n"
	        		+ "FROM customer_group g\r\n"
	        		+ "JOIN customer_group_reference gr ON gr.group_id=g.group_id\r\n"
	        		+ "join customer c on c.customer_id=gr.customer_id\r\n"
	        		+ "JOIN session s ON s.customer_id = c.customer_id\r\n"
	        		+ "WHERE g.group_name = :groupName") 
	 List<Object[]> findByCustomerGroupName( @Param("groupName") String groupName);
	
}


