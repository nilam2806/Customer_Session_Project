package com.maveric.csp.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;

@Service
public interface TagService {

	Tag addRemark(Tag tag);

	List<Session> getSessionByTagName(String tagName);

	List<String> getAllTags();

	

}
