package com.maveric.csp.exceptions;
public class SessionSaveException extends Exception {

    public SessionSaveException(String message) {
        super(message);
    }
}
