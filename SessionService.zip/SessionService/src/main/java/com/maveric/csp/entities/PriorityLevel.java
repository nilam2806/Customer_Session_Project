package com.maveric.csp.entities;

public enum PriorityLevel {

    HIGH, MEDIUM, LOW;

}
