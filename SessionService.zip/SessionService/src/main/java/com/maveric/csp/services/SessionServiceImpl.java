package com.maveric.csp.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.maveric.csp.conversion.AppConversions;
import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.dtos.CustomerGroupDTO;
import com.maveric.csp.dtos.CustomerGroupReferenceDTO;
import com.maveric.csp.dtos.UserDTO;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.repositories.RemarkRepository;
import com.maveric.csp.repositories.SessionRepository;
import com.maveric.csp.repositories.TagRepository;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class SessionServiceImpl implements SessionService {

	private static final Logger log = LoggerFactory.getLogger(SessionServiceImpl.class);

	@Autowired
	HttpServletRequest request;

	@Autowired
	public SessionRepository sessionRepository;

	@Autowired
	public RemarkRepository remarkRepository;

	@Autowired
	public TagRepository tagRepository;

	@Autowired
	public WebClient webClient;
	
	@Autowired
	public RestTemplate restTemplate;

	static String CUSTOMERURL = "http://CUSTOMER-SERVICE/api/v1/customers/";
	static String USERURL = "http://USER-SERVICE/api/v1/users/getby/";

	@Override
	public Session createSession(Session sessionRequest, String username) throws SessionSaveException {

		CustomerDTO customer = webClient.get().uri(CUSTOMERURL + sessionRequest.getCustomerId()).retrieve()
				.bodyToMono(CustomerDTO.class).block();

		UserDTO user = webClient.get().uri(USERURL + username).retrieve().bodyToMono(UserDTO.class).block();

		LocalDateTime currentDate = LocalDateTime.now();
		String formattedDate = AppConversions.convertDateToString(currentDate);

		sessionRequest.setCreatedOn(formattedDate);
		sessionRequest.setModifiedOn(formattedDate);
		sessionRequest.setIsActive("Yes");
		sessionRequest.setCreatedBy(user.getFirstName() + " " + user.getLastName());
		sessionRequest.setModifiedBy(user.getFirstName() + " " + user.getLastName());

		Session session = null;
		LocalDate currentLocalDate = LocalDate.now();

		if (sessionRequest.getFollowupOn() == null) {
			session = sessionRepository.save(sessionRequest);
		} else {
			LocalDate followupDate = AppConversions.convertStringToDate(sessionRequest.getFollowupOn());

			if (followupDate.isAfter(currentLocalDate)) {
				session = sessionRepository.save(sessionRequest);
			} else {
				throw new AllExceptions("Follow-up date is not in future");
			}
		}

		Remark remark = sessionRequest.getRemarks().get(0);
		remark.setSessionId(session.getSessionId());
		remark.setCreatedDate(formattedDate);
		remarkRepository.save(remark);

		Tag tag = sessionRequest.getTags().get(0);
		tag.setSessionId(session.getSessionId());
		tagRepository.save(tag);

		session.setCustomerDetails(customer);
		return session;
	}

	@Override
	public Session updateSession(Session session, String username) throws SessionNotFoundException {

		UserDTO user = webClient.get().uri(USERURL + username).retrieve().bodyToMono(UserDTO.class).block();

		Session updatedSession = null;
		Optional<Session> databaseSession = sessionRepository.findById(session.getSessionId());

		LocalDateTime currentDate = LocalDateTime.now();
		String formatedDate = AppConversions.convertDateToString(currentDate);

		if (databaseSession.isPresent()) {
			Session dbSession = databaseSession.get();
			dbSession.setSessionName(
					session.getSessionName() == null ? dbSession.getSessionName() : session.getSessionName());
			dbSession.setCreatedOn(session.getCreatedOn() == null ? dbSession.getCreatedOn() : session.getCreatedOn());
			dbSession.setCustomerId(session.getCustomerId() == 0 ? dbSession.getCustomerId() : session.getCustomerId());
			dbSession.setFollowupOn(session.getFollowupOn() == null ? dbSession.getFollowupOn()
					: session.getFollowupOn() == "" ? null : session.getFollowupOn());
			dbSession.setIsActive(session.getIsActive() == null ? dbSession.getIsActive() : session.getIsActive());
			dbSession.setPotentialLead(
					session.getPotentialLead() == null ? dbSession.getPotentialLead() : session.getPotentialLead());
			dbSession.setPriorityLevel(
					session.getPriorityLevel() == null ? dbSession.getPriorityLevel() : session.getPriorityLevel());
			dbSession.setModifiedOn(formatedDate);
			dbSession.setCreatedBy(session.getCreatedBy() == null ? dbSession.getCreatedBy() : session.getCreatedBy());
			dbSession.setModifiedBy(user.getFirstName() + " " + user.getLastName());

			if (session.getRemarks() != null) {

				Remark remark = session.getRemarks().get(0);
				remark.setCreatedDate(formatedDate);
				remark.setSessionId(dbSession.getSessionId());
				remarkRepository.save(remark);
			}

			if (session.getTags() != null) {
				Tag tag = session.getTags().get(0);
				tag.setSessionId(session.getSessionId());
				tagRepository.save(tag);
			}

			updatedSession = sessionRepository.save(dbSession);
			return updatedSession;
		} else {
			throw new SessionNotFoundException("session not found");
		}
	}

	@Override
	public Session makeArchiveSession(int sessionId) throws ArchiveSessionException, SessionNotFoundException {
		Optional<Session> foundSession = sessionRepository.findById(sessionId);
		Session archivedSession = null;

		if (foundSession.isPresent()) {
			Session session = foundSession.get();
			String followupOn = session.getFollowupOn();

			LocalDate followupDate = AppConversions.convertStringToDate(session.getFollowupOn());
			LocalDate currentDate = LocalDate.now();

			if (followupOn == null || !followupDate.isAfter(currentDate)) {
				session.setIsActive("No");
				archivedSession = sessionRepository.save(session);
			} else {

				throw new ArchiveSessionException("Follow-up date is in the future. Cannot archive the session.");
			}

		} else {

			throw new SessionNotFoundException("Session not found");
		}
		CustomerDTO customer = webClient.get().uri(CUSTOMERURL + +archivedSession.getCustomerId()).retrieve()
				.bodyToMono(CustomerDTO.class).block();
		List<Remark> remarksList = remarkRepository.findBySessionId(archivedSession.getSessionId());
		List<Tag> tagList = tagRepository.findBySessionId(sessionId);
		archivedSession.setRemarks(remarksList);
		archivedSession.setTags(tagList);
		archivedSession.setCustomerDetails(customer);
		return archivedSession;
	}

	@Override
	public List<Session> getActiveSessions(String username) throws SessionNotFoundException {
		List<Session> activeSessionList = sessionRepository.findByIsActive("Yes");
		List<Session> sessionList = new ArrayList<>();

		System.out.println("username>>>" + username);
		UserDTO user = webClient.get().uri(USERURL + username).retrieve().bodyToMono(UserDTO.class).block();

		if (!activeSessionList.isEmpty()) {
			for (Session session : activeSessionList) {
				String LoggedInuser = user.getFirstName() + " " + user.getLastName();
				if (LoggedInuser.equals(session.getCreatedBy())) {
					CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
							.bodyToMono(CustomerDTO.class).block();

					List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
					List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());

					session.setRemarks(remarksList);
					session.setTags(tagList);
					session.setCustomerDetails(customer);

					sessionList.add(session);
				}
			}
			return sessionList;
		} else {
			return Collections.emptyList();
		}
	}

	@Override
	public List<Session> getArchivedSessions(String username) throws SessionNotFoundException {
		List<Session> activeSessionList = sessionRepository.findByIsActive("No");
		List<Session> sessionList = new ArrayList<>();

		System.out.println("username>>>" + username);
		UserDTO user = webClient.get().uri(USERURL + username).retrieve().bodyToMono(UserDTO.class).block();

		if (!activeSessionList.isEmpty()) {

			for (Session session : activeSessionList) {
				String LoggedInuser = user.getFirstName() + " " + user.getLastName();
				if (LoggedInuser.equals(session.getCreatedBy())) {
					CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
							.bodyToMono(CustomerDTO.class).block();

					List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
					List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());

					session.setRemarks(remarksList);
					session.setTags(tagList);
					session.setCustomerDetails(customer);

					sessionList.add(session);
				}
			}
			return sessionList;
		} else {
			return Collections.emptyList();
		}
	}

	@Override
	public Session getSessionDetails(int sessionId) throws SessionNotFoundException {
		Optional<Session> databaseSession = sessionRepository.findBySessionId(sessionId);

		if (databaseSession.isPresent()) {

			Session foundSession = databaseSession.get();

			CustomerDTO customer = webClient.get().uri(CUSTOMERURL + foundSession.getCustomerId()).retrieve()
					.bodyToMono(CustomerDTO.class).block();

			List<Remark> remarksList = remarkRepository.findBySessionId(foundSession.getSessionId());
			List<Tag> tagList = tagRepository.findBySessionId(foundSession.getSessionId());
			foundSession.setRemarks(remarksList);
			foundSession.setCustomerDetails(customer);
			foundSession.setTags(tagList);

			return foundSession;
		} else {
			throw new SessionNotFoundException("Session not fount with Id:" + sessionId);
		}
	}

	@Override
	public List<Session> getSessionDetails(long customerID) throws SessionNotFoundException {
		List<Session> databaseSessionList = sessionRepository.findByCustomerId(customerID);

		if (databaseSessionList != null) {

			for (Session session : databaseSessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return databaseSessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getSessionDetails(PotentialLead potentialLead) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.findByPotentialLead(potentialLead);

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}

	}

	@Override
	public List<Session> getSessionDetails(PriorityLevel priorityLevel) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.findByPriorityLevel(priorityLevel);

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public List<Session> getByCreatedOn(String createdOn) throws SessionNotFoundException {

		List<Session> sessionList = sessionRepository.getSessionByCreatedOn(createdOn);

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}

			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}

	}

	@Override
	public List<Session> getByModifiedOn(String modifiedOn) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.getSessionByModifiedOn(modifiedOn);

		if (sessionList != null) {

			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}

	}

	@Override
	public List<Session> getByfollowUpOn(String followupOn) throws SessionNotFoundException {
		List<Session> sessionList = sessionRepository.getSessionByFollowupOn(followupOn);
		if (sessionList != null) {
			for (Session session : sessionList) {
				CustomerDTO customer = webClient.get().uri(CUSTOMERURL + session.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
				List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
				List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());
				session.setRemarks(remarksList);
				session.setTags(tagList);
				session.setCustomerDetails(customer);
			}
			return sessionList;
		} else {
			throw new SessionNotFoundException("Session Not found");
		}
	}

	@Override
	public void autoArchiveSessions() {
		List<Session> sessionsToArchive = sessionRepository.findByUpdatedDateBefore(LocalDate.now().minusDays(10));
		for (Session session : sessionsToArchive) {

			String followupOn = session.getFollowupOn();
			LocalDate followupDate = AppConversions.convertStringToDate(session.getFollowupOn());
			LocalDate currentDate = LocalDate.now();

			if (followupOn == null || !followupDate.isAfter(currentDate)) {
				session.setIsActive("No");
				sessionRepository.save(session);
			} else {
				session.setIsActive("Yes");
				sessionRepository.save(session);
			}
		}
	}

	@Override
	public List<Session> getByGroupName(String groupName) {
	    List<Session> sessionList = new ArrayList<>();
	    List<CustomerDTO> customerList = new ArrayList<>();

	    List<CustomerGroupDTO> customerGroups = webClient.get()
	            .uri("http://CUSTOMER-SERVICE/api/v1/customerGroup/getCustomerByGroupName/" + groupName)
	            .retrieve()
	            .bodyToFlux(CustomerGroupDTO.class)
	            .collectList()
	            .block();

	    if (customerGroups != null && !customerGroups.isEmpty()) {
	        CustomerGroupDTO customerGroup = customerGroups.get(0);

	        log.info("CustomerGroup: " + customerGroup.toString());

	        String url = "http://CUSTOMER-SERVICE/api/v1/customerGroup/getRefByGroupId/" + customerGroup.getGroupId();

	        List<CustomerGroupReferenceDTO> referenceList = restTemplate.exchange(
	                url,
	                HttpMethod.GET,
	                null,
	                new ParameterizedTypeReference<List<CustomerGroupReferenceDTO>>() {}
	        ).getBody();

	        log.info("Reference: " + referenceList.toString());

	        customerList = getCustomersFromReferenceList(referenceList);

	        log.info("CustomerList: " + customerList.toString());

	        for (CustomerDTO customer : customerList) {
	        	
	        	CustomerDTO CustomerDTO = webClient.get().uri(CUSTOMERURL + customer.getCustomerId()).retrieve()
						.bodyToMono(CustomerDTO.class).block();
	        	
	            List<Session> customerSessions = sessionRepository.findByCustomerId(customer.getCustomerId());

	            for (Session session : customerSessions) {
	                session.setCustomerDetails(CustomerDTO);

	                List<Remark> remarksList = remarkRepository.findBySessionId(session.getSessionId());
	                List<Tag> tagList = tagRepository.findBySessionId(session.getSessionId());

	                session.setRemarks(remarksList);
	                session.setTags(tagList);

	                sessionList.add(session);
	            }
	        }
	    }
	    return sessionList;
	}

	private List<CustomerDTO> getCustomersFromReferenceList(List<CustomerGroupReferenceDTO> referenceList) {

	    List<CustomerDTO> customerList = new ArrayList<>();
	    for (CustomerGroupReferenceDTO cref : referenceList) {
	        CustomerDTO customer = new CustomerDTO();
	        customer.setCustomerId(cref.getCustomerId());
	        customerList.add(customer);
	    }
	    return customerList;
	}

}
