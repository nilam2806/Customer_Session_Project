package com.maveric.csp.exceptions;
public class ArchiveSessionException extends Exception {

    public ArchiveSessionException(String message) {
        super(message);
    }
}