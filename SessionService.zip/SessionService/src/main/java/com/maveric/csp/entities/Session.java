package com.maveric.csp.entities;

import java.util.List;

import com.maveric.csp.dtos.CustomerDTO;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import reactor.core.publisher.Flux;

@Data
@Entity
public class Session{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sessionId;
	
	@NotNull(message = " sessionName cannot be null")
	private String sessionName;

	@NotNull(message = " customerId cannot be null")
	private long customerId;

	private String createdOn;

	private String modifiedOn;

	private String createdBy;

	private String modifiedBy;

	private String followupOn;
	
	@Transient
	private List<Remark> remarks;
	
	@Transient
	private CustomerDTO customerDetails;
	
	@Transient
	private List<Tag> tags;
	
	@Enumerated(EnumType.STRING)
	private PriorityLevel priorityLevel;

	@Enumerated(EnumType.STRING)
	private PotentialLead potentialLead;

	private String isActive;

}
