package com.maveric.csp.dtos;

import lombok.Data;

@Data
public class RemarkDTO {
	
	private int remarkId;

	private String createdDate;

	private String remark;
	
	private int sessionId;

}
