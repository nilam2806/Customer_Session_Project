package com.maveric.csp.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserDTO {
		private int userId;
		private String email;
		private String password;
		private String firstName;
		private String lastName;
		private String createdOn;
		private String lastLogin;
}
