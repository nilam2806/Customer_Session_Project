package com.maveric.csp.dtos;

import lombok.Data;

@Data
public class CustomerGroupReferenceDTO {
	
	private int id;
	private int groupId;
	private long customerId;
	
}
