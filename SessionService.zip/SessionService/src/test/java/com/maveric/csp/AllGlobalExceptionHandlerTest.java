package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.exceptionhandler.AllGlobalExceptionHandler;

public class AllGlobalExceptionHandlerTest {

	private AllGlobalExceptionHandler exceptionHandler;

	@BeforeEach
	public void setUp() {
		exceptionHandler = new AllGlobalExceptionHandler();
	}

	@Test
	public void testHandleSessionSaveException() {

		SessionSaveException exception = new SessionSaveException("Session save error");

		ResponseEntity<String> responseEntity = exceptionHandler.handleSessionSaveException(exception);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
		assertEquals("Session save error", responseEntity.getBody());
	}

	@Test
	public void testHandleSessionNotFoundException() {
		SessionNotFoundException exception = new SessionNotFoundException("Session not found");

		ResponseEntity<String> responseEntity = exceptionHandler.handleSessionNotFoundException(exception);

		assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
		assertEquals("Session not found", responseEntity.getBody());
	}

	@Test
	public void testHandleArchiveSessionException() {

		ArchiveSessionException exception = new ArchiveSessionException("Archive session error");

		ResponseEntity<String> responseEntity = exceptionHandler.handleArchiveSessionException(exception);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals("Archive session error", responseEntity.getBody());
	}

	@Test
	public void testHandleGeneralException() {

		Exception exception = new Exception("General error");

		ResponseEntity<String> responseEntity = exceptionHandler.handleGeneralException(exception);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
		assertEquals("General error", responseEntity.getBody());
	}
}
