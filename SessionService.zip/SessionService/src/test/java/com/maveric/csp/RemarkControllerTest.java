package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.maveric.csp.controller.RemarkController;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.services.RemarkService;

class RemarkControllerTest {

	@Test
	void testAddRemark() throws AllExceptions {

		RemarkService remarkServiceMock = mock(RemarkService.class);

		RemarkController remarkController = new RemarkController();
		remarkController.remarkService = remarkServiceMock;

		Remark remarkToBeAdded = new Remark();

		when(remarkServiceMock.addRemark(remarkToBeAdded)).thenReturn(remarkToBeAdded);

		ResponseEntity<Remark> responseEntity = remarkController.addRemark(remarkToBeAdded);

		verify(remarkServiceMock).addRemark(remarkToBeAdded);

		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
		assertEquals(remarkToBeAdded, responseEntity.getBody());
	}
}
