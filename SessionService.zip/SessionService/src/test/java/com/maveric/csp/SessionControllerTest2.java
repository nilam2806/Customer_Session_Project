package com.maveric.csp;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.maveric.csp.controller.SessionController;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;
import com.maveric.csp.services.SessionService;

@SpringJUnitConfig
@WebMvcTest(SessionController.class)
public class SessionControllerTest2 {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SessionService sessionService;

	@InjectMocks
	private SessionController sessionController;

	@Test
	public void testGetByPriorityLevel() throws Exception {
		List<Session> sessionList = new ArrayList<>();

		when(sessionService.getSessionDetails(any(PriorityLevel.class))).thenReturn(sessionList);

		mockMvc.perform(MockMvcRequestBuilders.get("/session/priorityLevel/HIGH"))
				.andExpect(MockMvcResultMatchers.status().isOk())

				.andExpect(MockMvcResultMatchers.jsonPath("$").isArray());
	}

	@Test
	public void testGetByPotentialLead() throws Exception {
		List<Session> sessionList = new ArrayList<>();

		when(sessionService.getSessionDetails(any(PotentialLead.class))).thenReturn(sessionList);

		mockMvc.perform(MockMvcRequestBuilders.get("/session/potentialLead/LEAD_TYPE"));

	}

	@Test
	public void testUpdateSession() throws Exception {
		Session session = new Session();
		session.setSessionId(1);
		session.setSessionName("Updated Test Session");

		when(sessionService.updateSession(any(Session.class), any(String.class))).thenReturn(session);

		mockMvc.perform(
				MockMvcRequestBuilders.put("/session/update").content(new ObjectMapper().writeValueAsString(session))

						.header("LoggedInUser", "testUser"));
	}
}
