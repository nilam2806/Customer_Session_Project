package com.maveric.csp;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;

import com.maveric.csp.entities.Remark;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RemarkTest {

	private Remark remark;

	@Before(value = "")
	public void setUp() {
		remark = new Remark();
		remark.setRemarkId(1);
		remark.setCreatedDate("2024-02-28");
		remark.setRemark("Test Remark");
		remark.setSessionId(123);
	}

	@Test
	public void testNoArgsConstructor() {
		Remark newRemark = new Remark();
		assertNotNull(newRemark);
	}

}
