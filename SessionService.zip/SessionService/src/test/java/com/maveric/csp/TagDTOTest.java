package com.maveric.csp;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.TagDTO;

public class TagDTOTest {

    @Test
    public void testConstructor() {
        // Create an instance of TagDTO
        TagDTO tagDTO = new TagDTO();

        // Assert not null
        assertNotNull(tagDTO);
    }

    // Add more test cases as per the functionality of the TagDTO class
}
