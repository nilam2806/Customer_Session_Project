package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.reactive.function.client.WebClient;

import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.repositories.RemarkRepository;
import com.maveric.csp.repositories.SessionRepository;
import com.maveric.csp.repositories.TagRepository;
import com.maveric.csp.services.SessionService;
import com.maveric.csp.services.SessionServiceImpl;

@SpringBootTest
class SessionServiceImplTest {
	@Mock
	private WebClient.Builder webClientBuilder;

	@MockBean
	private SessionRepository sessionRepository;

	@MockBean
	private RemarkRepository remarkRepository;

	@MockBean
	private TagRepository tagRepository;

	@MockBean
	private WebClient webClient;
	@MockBean
	private SessionServiceImpl sessionService;
	@InjectMocks
	private SessionService sessionService1 = new SessionServiceImpl();

	@BeforeEach
	void setUp() {
		sessionService = new SessionServiceImpl();
		sessionService.sessionRepository = sessionRepository;
		sessionService.remarkRepository = remarkRepository;
		sessionService.tagRepository = tagRepository;
		sessionService.webClient = webClient;
	}



	@Test
	void testUpdateSession() {
		Session mockSession = new Session(); // Prepare mock session
		mockSession.setSessionId(1); // Set session ID
		Mockito.when(sessionRepository.findById(1)).thenReturn(Optional.of(mockSession)); // Mock findById
		Mockito.when(sessionRepository.save(Mockito.any(Session.class))).thenReturn(mockSession); // Mock save

		Session updatedSession = new Session(); // Prepare updated session
		updatedSession.setSessionId(1); // Set session ID
		updatedSession.setSessionName("Updated Session Name"); // Update session name

	}

	@Test
	void testMakeArchiveSession_SessionFoundAndArchivedSuccessfully()
			throws ArchiveSessionException, SessionNotFoundException {

		Session session = new Session();
		session.setSessionId(1);
		session.setFollowupOn("2022-01-01");

		when(sessionRepository.findById(1)).thenReturn(Optional.of(session));

	}

	@Test
	void testGetActiveSessions() throws SessionNotFoundException {

		Session session1 = new Session();
		session1.setSessionId(1);
		session1.setCustomerId(101);

		Session session2 = new Session();
		session2.setSessionId(2);
		session2.setCustomerId(102);

		List<Session> activeSessions = new ArrayList<>();
		activeSessions.add(session1);
		activeSessions.add(session2);

		CustomerDTO customer1 = new CustomerDTO();
		customer1.setCustomerId(101L);
		customer1.setCustomerName("Customer 1");

		CustomerDTO customer2 = new CustomerDTO();
		customer2.setCustomerId(102L);
		customer2.setCustomerName("Customer 2");

		List<Remark> remarks1 = new ArrayList<>();
		List<Tag> tags1 = new ArrayList<>();

		List<Remark> remarks2 = new ArrayList<>();
		List<Tag> tags2 = new ArrayList<>();

		// Mock repository methods
		when(sessionRepository.findByIsActive("Yes")).thenReturn(activeSessions);
		when(remarkRepository.findBySessionId(1)).thenReturn(remarks1);
		when(remarkRepository.findBySessionId(2)).thenReturn(remarks2);
		when(tagRepository.findBySessionId(1)).thenReturn(tags1);
		when(tagRepository.findBySessionId(2)).thenReturn(tags2);

	}

	@Test
	void testGetSessionDetailsInt() throws SessionNotFoundException {

		int sessionId = 123; // Sample session ID
		Session session = new Session(); // Create a sample session object
		when(sessionRepository.findBySessionId(sessionId)).thenReturn(java.util.Optional.of(session));

	}

	@Test
	void testGetSessionDetailsLong() throws SessionNotFoundException {

		long customerId = 123;
		List<Session> sessions = new ArrayList<>();
		when(sessionRepository.findByCustomerId(customerId)).thenReturn(sessions);

		List<Session> result = sessionService.getSessionDetails(customerId);

		assertNotNull(result);

	}

	@Test
	void testGetSessionDetailsPotentialLead() throws SessionNotFoundException {

		PotentialLead potentialLead = PotentialLead.YES;
		List<Session> sessions = new ArrayList<>();
		when(sessionRepository.findByPotentialLead(potentialLead)).thenReturn(sessions);

		List<Session> result = sessionService.getSessionDetails(potentialLead);

		assertNotNull(result);

	}

	@Test
	void testGetSessionDetailsPriorityLevel() throws SessionNotFoundException {

		PriorityLevel priorityLevel = PriorityLevel.HIGH;
		List<Session> sessions = new ArrayList<>();

		when(sessionRepository.findByPriorityLevel(priorityLevel)).thenReturn(sessions);

		List<Session> result = sessionService.getSessionDetails(priorityLevel);

		assertNotNull(result);

	}

	@Test
	void testGetSessionByCreatedOnString() throws SessionNotFoundException {

		String createdOn = "2024-02-27";
		List<Session> sessions = new ArrayList<>();

		when(sessionRepository.findByCreatedOn(createdOn)).thenReturn(sessions);

		List<Session> result = sessionService.getByCreatedOn(createdOn);

		assertNotNull(result);

	}

	@Test
	void testGetSessionByCreatedOnStringString() throws SessionNotFoundException {

		String fromDate = "2024-02-27";
		String toDate = "2024-02-28";
		List<Session> sessions = new ArrayList<>();
		when(sessionRepository.getCreatedOnFromDateTodateSession(fromDate + " 00:00", toDate + " 23:59"))
				.thenReturn(sessions);

	}

	@Test
	void testGetSessionByModifiedOnStringString() throws SessionNotFoundException {

		String fromDate = "2024-02-27";
		String toDate = "2024-02-28";
		List<Session> sessions = new ArrayList<>();

		when(sessionRepository.getModifiedOnFromDateTodateSession(fromDate + " 00:00", toDate + " 23:59"))
				.thenReturn(sessions);

		List<Session> result = sessionService.getByModifiedOn(fromDate);

		assertNotNull(result);

	}

	@Test
	void testGetSessionByModifiedOnString() throws SessionNotFoundException {
		// Arrange
		String modifiedOn = "2024-02-27";
		List<Session> sessions = new ArrayList<>();
		when(sessionRepository.getSessionByModifiedOn(modifiedOn)).thenReturn(sessions);

		List<Session> result = sessionService.getByModifiedOn(modifiedOn);

		assertNotNull(result);

	}

	@Test
	void testGetSessionByFollowUpOn() throws SessionNotFoundException {

		String followupOn = "2024-02-27";
		List<Session> sessions = new ArrayList<>();
		when(sessionRepository.getSessionByFollowupOn(followupOn)).thenReturn(sessions);

		List<Session> result = sessionService.getByfollowUpOn(followupOn);

		assertNotNull(result);

	}

	@Test
	void testAutoArchiveSessions() {

		LocalDate currentDate = LocalDate.now();
		List<Session> sessionsToArchive = new ArrayList<>();

		Session session1 = new Session();
		session1.setFollowupOn("2024-02-25");
		sessionsToArchive.add(session1);
		Session session2 = new Session();
		session2.setFollowupOn(currentDate.toString());
		sessionsToArchive.add(session2);

		when(sessionRepository.findByUpdatedDateBefore(currentDate.minusDays(10))).thenReturn(sessionsToArchive);

		sessionService.autoArchiveSessions();

	}

	@Test
	void testGetBygroupName() {

		SessionServiceImpl sessionService = new SessionServiceImpl();

		List<Session> sessions = null;
		SessionRepository sessionRepository = mock(SessionRepository.class);

	}
}
