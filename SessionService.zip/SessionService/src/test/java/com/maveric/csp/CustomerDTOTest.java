package com.maveric.csp;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.dtos.PreferredInvestmentProduct;
import com.maveric.csp.dtos.WealthMode;

public class CustomerDTOTest {

    @Test
    public void testGettersAndSetters() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(1L);
        customerDTO.setCustomerName("John Doe");
        customerDTO.setCustomerEmail("john@example.com");
        customerDTO.setWealthMode(WealthMode.COMBO);
        customerDTO.setPreferredProduct(PreferredInvestmentProduct.EQUITY_STOCKS);
        customerDTO.setFinancialGoal("Retirement");

        assertEquals(1L, customerDTO.getCustomerId());
        assertEquals("John Doe", customerDTO.getCustomerName());
        assertEquals("john@example.com", customerDTO.getCustomerEmail());
        assertEquals(WealthMode.COMBO, customerDTO.getWealthMode());
        assertEquals(PreferredInvestmentProduct.EQUITY_STOCKS, customerDTO.getPreferredProduct());
        assertEquals("Retirement", customerDTO.getFinancialGoal());
    }

    @Test
    public void testEnumFields() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setWealthMode(WealthMode.COMBO);
        customerDTO.setPreferredProduct(PreferredInvestmentProduct.EQUITY_STOCKS);

        assertEquals(WealthMode.COMBO, customerDTO.getWealthMode());
        assertEquals(PreferredInvestmentProduct.EQUITY_STOCKS, customerDTO.getPreferredProduct());
    }

    @Test
    public void testNullCustomerId() {
        CustomerDTO customerDTO = new CustomerDTO();
        assertNull(customerDTO.getCustomerId());
    }

    @Test
    public void testEmptyCustomerName() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerName("");

        assertEquals("", customerDTO.getCustomerName());
    }

    @Test
    public void testFinancialGoal() {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setFinancialGoal("Education");

        assertEquals("Education", customerDTO.getFinancialGoal());
    }

    @Test
    public void testEquality() {
        CustomerDTO customerDTO1 = new CustomerDTO();
        customerDTO1.setCustomerId(1L);
        customerDTO1.setCustomerName("John Doe");

        CustomerDTO customerDTO2 = new CustomerDTO();
        customerDTO2.setCustomerId(1L);
        customerDTO2.setCustomerName("John Doe");

        assertEquals(customerDTO1, customerDTO2);
    }
}
