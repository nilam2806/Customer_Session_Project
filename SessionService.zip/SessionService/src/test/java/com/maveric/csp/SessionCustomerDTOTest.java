package com.maveric.csp;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.dtos.SessionCustomerDTO;
import com.maveric.csp.entities.Session;

public class SessionCustomerDTOTest {

    @Test
    public void testGettersAndSetters() {
        // Create instances of Session and CustomerDTO
        Session session = new Session();
        CustomerDTO customerDTO = new CustomerDTO();

        // Set values for Session and CustomerDTO
        session.setSessionId(1);
        customerDTO.setCustomerId(1L);
        customerDTO.setCustomerName("John Doe");

        // Create SessionCustomerDTO instance
        SessionCustomerDTO sessionCustomerDTO = new SessionCustomerDTO();
        sessionCustomerDTO.setSession(session);
        sessionCustomerDTO.setCustomerDetails(customerDTO);

        // Assert values using getters
        assertEquals(session, sessionCustomerDTO.getSession());
        assertEquals(customerDTO, sessionCustomerDTO.getCustomerDetails());
    }

    @Test
    public void testEmptyConstructor() {
        // Create SessionCustomerDTO instance using empty constructor
        SessionCustomerDTO sessionCustomerDTO = new SessionCustomerDTO();

        // Assert not null
        assertNotNull(sessionCustomerDTO);
    }

    @Test
    public void testEquality() {
        // Create instances of Session and CustomerDTO
        Session session1 = new Session();
        Session session2 = new Session();
        CustomerDTO customerDTO1 = new CustomerDTO();
        CustomerDTO customerDTO2 = new CustomerDTO();

        // Set values for Session and CustomerDTO
        session1.setSessionId(1);
        session2.setSessionId(1);
        customerDTO1.setCustomerId(1L);
        customerDTO1.setCustomerName("John Doe");
        customerDTO2.setCustomerId(1L);
        customerDTO2.setCustomerName("John Doe");

        // Create SessionCustomerDTO instances
        SessionCustomerDTO sessionCustomerDTO1 = new SessionCustomerDTO();
        sessionCustomerDTO1.setSession(session1);
        sessionCustomerDTO1.setCustomerDetails(customerDTO1);

        SessionCustomerDTO sessionCustomerDTO2 = new SessionCustomerDTO();
        sessionCustomerDTO2.setSession(session2);
        sessionCustomerDTO2.setCustomerDetails(customerDTO2);

        // Assert equality
        assertEquals(sessionCustomerDTO1, sessionCustomerDTO2);
    }

    @Test
    public void testNotEqual() {
        // Create instances of Session and CustomerDTO with different values
        Session session1 = new Session();
        Session session2 = new Session();
        CustomerDTO customerDTO1 = new CustomerDTO();
        CustomerDTO customerDTO2 = new CustomerDTO();

        // Set values for Session and CustomerDTO
        session1.setSessionId(1);
        session2.setSessionId(2);
        customerDTO1.setCustomerId(1L);
        customerDTO1.setCustomerName("John Doe");
        customerDTO2.setCustomerId(2L);
        customerDTO2.setCustomerName("Jane Doe");

        // Create SessionCustomerDTO instances with different values
        SessionCustomerDTO sessionCustomerDTO1 = new SessionCustomerDTO();
        sessionCustomerDTO1.setSession(session1);
        sessionCustomerDTO1.setCustomerDetails(customerDTO1);

        SessionCustomerDTO sessionCustomerDTO2 = new SessionCustomerDTO();
        sessionCustomerDTO2.setSession(session2);
        sessionCustomerDTO2.setCustomerDetails(customerDTO2);

        // Assert not equal
        assertNotEquals(sessionCustomerDTO1, sessionCustomerDTO2);
    }
}
