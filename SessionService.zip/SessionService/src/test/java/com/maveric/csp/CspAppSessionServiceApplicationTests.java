package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.maveric.csp.controller.SessionController;
import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.services.SessionService;

@SpringBootTest
class CspAppSessionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Mock
	private SessionService sessionService;

	@InjectMocks
	private SessionController sessionController;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetSessionDetailsById() throws SessionNotFoundException {
		int sessionId = 123;
		Session session = new Session();
		doReturn(session).when(sessionService).getSessionDetails(sessionId);

		ResponseEntity<Session> response = sessionController.getSessionDetails(sessionId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(session, response.getBody());
		verify(sessionService).getSessionDetails(sessionId);
	}

	@Test
	public void testGetActiveSessions() throws SessionNotFoundException {
		List<Session> sessionList = new ArrayList<>();
		doReturn(sessionList).when(sessionService).getActiveSessions(null);

		ResponseEntity<List<Session>> response = sessionController.getActiveSessions(null);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(sessionList, response.getBody());
		verify(sessionService).getActiveSessions(null);
	}

	@Test
	public void testGetArchiveSessions() throws SessionNotFoundException {
		List<Session> sessionList = new ArrayList<>();
		doReturn(sessionList).when(sessionService).getArchivedSessions(null);

		ResponseEntity<List<Session>> response = sessionController.getArchiveSessions(null);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(sessionList, response.getBody());
		verify(sessionService).getArchivedSessions(null);
	}

	@Test
	public void testGetSessionDetailsByCustomerId() throws SessionNotFoundException {
		Long customerId = 123L;
		List<Session> sessionList = new ArrayList<>();
		doReturn(sessionList).when(sessionService).getSessionDetails(customerId);

		ResponseEntity<List<Session>> response = sessionController.getSessionDetails(customerId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(sessionList, response.getBody());
		verify(sessionService).getSessionDetails(customerId);
	}

	@Test
	public void testGetSessionDetailsByPotentialLead() throws SessionNotFoundException {
		PotentialLead potentialLead = PotentialLead.NO;
		List<Session> sessionList = new ArrayList<>();
		doReturn(sessionList).when(sessionService).getSessionDetails(potentialLead);

	}

	@Test
	public void testGetSessionsByPriorityLevel() throws SessionNotFoundException {
		PriorityLevel priorityLevel = PriorityLevel.HIGH;
		List<Session> sessionList = new ArrayList<>();
		doReturn(sessionList).when(sessionService).getSessionDetails(priorityLevel);

	}

}
