package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.maveric.csp.entities.PotentialLead;
import com.maveric.csp.entities.PriorityLevel;
import com.maveric.csp.entities.Session;

public class SessionTest {

	private Session session;

	@BeforeEach
	public void setUp() {
		session = new Session();
		session.setSessionId(1);
		session.setSessionName("Test Session");
		session.setCustomerId(123456);
		session.setCreatedOn("2024-02-28");
		session.setModifiedOn("2024-02-28");
		session.setCreatedBy("TestUser");
		session.setModifiedBy("TestUser");
		session.setFollowupOn("2024-03-05");
		session.setPriorityLevel(PriorityLevel.HIGH);
		session.setPotentialLead(PotentialLead.YES);
		session.setIsActive("Yes");
	}

	@Test
	public void testSessionId() {
		assertEquals(1, session.getSessionId());
	}

	@Test
	public void testSessionName() {
		assertEquals("Test Session", session.getSessionName());
	}

	@Test
	public void testCustomerId() {
		assertEquals(123456, session.getCustomerId());
	}

	@Test
	public void testCreatedOn() {
		assertEquals("2024-02-28", session.getCreatedOn());
	}

	@Test
	public void testModifiedOn() {
		assertEquals("2024-02-28", session.getModifiedOn());
	}

	@Test
	public void testCreatedBy() {
		assertEquals("TestUser", session.getCreatedBy());
	}

	@Test
	public void testModifiedBy() {
		assertEquals("TestUser", session.getModifiedBy());
	}

	@Test
	public void testFollowupOn() {
		assertEquals("2024-03-05", session.getFollowupOn());
	}

	@Test
	public void testPriorityLevel() {
		assertEquals(PriorityLevel.HIGH, session.getPriorityLevel());
	}

	@Test
	public void testPotentialLead() {
		assertEquals(PotentialLead.YES, session.getPotentialLead());
	}

	@Test
	public void testIsActive() {
		assertEquals("Yes", session.getIsActive());
	}

}
