package com.maveric.csp;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;

import com.maveric.csp.conversion.AppConversions;
import com.maveric.csp.entities.Remark;
import com.maveric.csp.exceptions.AllExceptions;
import com.maveric.csp.repositories.RemarkRepository;
import com.maveric.csp.services.RemarkServiceImpl;

@SpringBootTest
public class RemarkServiceImplTest {

	@Mock
	private RemarkRepository remarkRepositoryMock;

	@InjectMocks
	private RemarkServiceImpl remarkService;

	private Logger loggerMock;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		loggerMock = mock(Logger.class);
		remarkService = new RemarkServiceImpl();
	}

	@Test
	public void testAddRemark_Success() throws AllExceptions {

		Remark remark = new Remark();
		remark.setRemark("Test remark content");

		LocalDateTime currentDateTime = LocalDateTime.now();
		String formattedDate = AppConversions.convertDateToString(currentDateTime);

		when(remarkRepositoryMock.save(remark)).thenReturn(remark);

	}

	@Test
	public void testAddRemark_Failure() {

		Remark remark = new Remark();
		remark.setRemark("Test remark content");

		when(remarkRepositoryMock.save(remark)).thenReturn(null);

	}

	@Test
	public void testAddRemark_Logs() throws AllExceptions {

		Remark remark = new Remark();
		remark.setRemark("Test remark content");

		LocalDateTime currentDateTime = LocalDateTime.now();
		String formattedDate = AppConversions.convertDateToString(currentDateTime);

		when(remarkRepositoryMock.save(remark)).thenReturn(remark);

		ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);

	}
}
