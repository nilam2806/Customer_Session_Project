package com.maveric.csp;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.UserDTO;

public class UserDTOTest {

    @Test
    public void testGettersAndSetters() {
        // Create an instance of UserDTO
        UserDTO userDTO = new UserDTO();

        // Set values for UserDTO
        userDTO.setUserId(1);
        userDTO.setEmail("user@example.com");
        userDTO.setPassword("password123");
        userDTO.setFirstName("John");
        userDTO.setLastName("Doe");
        userDTO.setCreatedOn("2024-02-29");
        userDTO.setLastLogin("2024-03-01");

        // Assert values using getters
        assertEquals(1, userDTO.getUserId());
        assertEquals("user@example.com", userDTO.getEmail());
        assertEquals("password123", userDTO.getPassword());
        assertEquals("John", userDTO.getFirstName());
        assertEquals("Doe", userDTO.getLastName());
        assertEquals("2024-02-29", userDTO.getCreatedOn());
        assertEquals("2024-03-01", userDTO.getLastLogin());
    }

    @Test
    public void testEmptyConstructor() {
        // Create UserDTO instance using empty constructor
        UserDTO userDTO = new UserDTO();

        // Assert not null
        assertNotNull(userDTO);
    }

    @Test
    public void testEquality() {
        // Create instances of UserDTO with the same values
        UserDTO userDTO1 = new UserDTO();
        userDTO1.setUserId(1);
        userDTO1.setEmail("user@example.com");
        userDTO1.setPassword("password123");
        userDTO1.setFirstName("John");
        userDTO1.setLastName("Doe");
        userDTO1.setCreatedOn("2024-02-29");
        userDTO1.setLastLogin("2024-03-01");

        UserDTO userDTO2 = new UserDTO();
        userDTO2.setUserId(1);
        userDTO2.setEmail("user@example.com");
        userDTO2.setPassword("password123");
        userDTO2.setFirstName("John");
        userDTO2.setLastName("Doe");
        userDTO2.setCreatedOn("2024-02-29");
        userDTO2.setLastLogin("2024-03-01");

        // Assert equality
        assertEquals(userDTO1, userDTO2);
    }

    @Test
    public void testNotEqual() {
        // Create instances of UserDTO with different values
        UserDTO userDTO1 = new UserDTO();
        userDTO1.setUserId(1);
        userDTO1.setEmail("user@example.com");

        UserDTO userDTO2 = new UserDTO();
        userDTO2.setUserId(2);
        userDTO2.setEmail("otheruser@example.com");

        // Assert not equal
        assertNotEquals(userDTO1, userDTO2);
    }
}
