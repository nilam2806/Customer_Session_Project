package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.maveric.csp.controller.SessionController;
import com.maveric.csp.entities.Session;
import com.maveric.csp.exceptions.ArchiveSessionException;
import com.maveric.csp.exceptions.SessionNotFoundException;
import com.maveric.csp.exceptions.SessionSaveException;
import com.maveric.csp.services.SessionService;

class SessionControllerTest {

	@MockBean
	private SessionService sessionService;

	@Test
	void testCreateSession() throws SessionSaveException {
		SessionService sessionServiceMock = mock(SessionService.class);
		SessionController sessionController = new SessionController();
		sessionController.sessionService = sessionServiceMock;

		Session sessionToBeCreated = new Session(); // Initialize with your test data

		when(sessionServiceMock.createSession(sessionToBeCreated, null)).thenReturn(sessionToBeCreated);

		ResponseEntity<Session> responseEntity = sessionController.createSession(sessionToBeCreated, null);

		verify(sessionServiceMock).createSession(sessionToBeCreated, null);
		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
		assertEquals(sessionToBeCreated, responseEntity.getBody());
	}

	@Test
	void testMakeArchiveSession() throws ArchiveSessionException, SessionNotFoundException {
		SessionService sessionServiceMock = mock(SessionService.class);
		SessionController sessionController = new SessionController();
		sessionController.sessionService = sessionServiceMock;

		int sessionId = 1; // Example session ID

		Session archivedSession = new Session(); // Initialize with your test data

		when(sessionServiceMock.makeArchiveSession(sessionId)).thenReturn(archivedSession);

		ResponseEntity<Session> responseEntity = sessionController.makeArchiveSession(sessionId);

		verify(sessionServiceMock).makeArchiveSession(sessionId);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(archivedSession, responseEntity.getBody());
	}

	@Test
	void testAutoArchiveSessions() {
		SessionService sessionServiceMock = mock(SessionService.class);
		SessionController sessionController = new SessionController();
		sessionController.sessionService = sessionServiceMock;

		ResponseEntity<String> responseEntity = sessionController.autoArchiveSessions();

		verify(sessionServiceMock).autoArchiveSessions();
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals("Sessions auto-archived successfully.", responseEntity.getBody());
	}

	@Test
	void testGetByGroupName() {
		SessionService sessionServiceMock = mock(SessionService.class);
		SessionController sessionController = new SessionController();
		sessionController.sessionService = sessionServiceMock;

		String groupName = "exampleGroup"; // Example group name

		List<Session> sessionList = new ArrayList<>(); // Initialize with your test data

		when(sessionServiceMock.getByGroupName(groupName)).thenReturn(sessionList);

		ResponseEntity<List<Session>> responseEntity = sessionController.getBygroupName(groupName);

		verify(sessionServiceMock).getByGroupName(groupName);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(sessionList, responseEntity.getBody());
	}

}
