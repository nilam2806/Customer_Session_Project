package com.maveric.csp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.maveric.csp.controller.TagController;
import com.maveric.csp.entities.Session;
import com.maveric.csp.entities.Tag;
import com.maveric.csp.services.TagService;

class TagControllerTest {

	@Test
	void testAddTag() {
		TagService tagServiceMock = mock(TagService.class);
		TagController tagController = new TagController();
		tagController.tagService = tagServiceMock;

		Tag tagToBeAdded = new Tag();
		when(tagServiceMock.addRemark(tagToBeAdded)).thenReturn(tagToBeAdded);

		ResponseEntity<Tag> responseEntity = tagController.addTag(tagToBeAdded);

		// Asserts
		verify(tagServiceMock).addRemark(tagToBeAdded);
		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
		assertEquals(tagToBeAdded, responseEntity.getBody());
	}

	@Test
	void testGetSessionByTagName() {
		TagService tagServiceMock = mock(TagService.class);
		TagController tagController = new TagController();
		tagController.tagService = tagServiceMock;

		String tagName = "exampleTag";

		List<Session> sessions = Arrays.asList(new Session(), new Session()); // Initialize with your test data

		when(tagServiceMock.getSessionByTagName(tagName)).thenReturn(sessions);

		ResponseEntity<List<Session>> responseEntity = tagController.getSessionByTagName(tagName);

		// Asserts
		verify(tagServiceMock).getSessionByTagName(tagName);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(sessions, responseEntity.getBody());
	}

	@Test
	void testAllTags() {
		TagService tagServiceMock = mock(TagService.class);
		TagController tagController = new TagController();
		tagController.tagService = tagServiceMock;

		List<String> tags = Arrays.asList("tag1", "tag2", "tag3");

		when(tagServiceMock.getAllTags()).thenReturn(tags);

		ResponseEntity<List<String>> responseEntity = tagController.allTags();

		// Asserts
		verify(tagServiceMock).getAllTags();
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(tags, responseEntity.getBody());
	}
}
