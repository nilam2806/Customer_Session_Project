package com.maveric.csp;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.CustomerDTO;
import com.maveric.csp.dtos.CustomerGroupDTO;

public class CustomerGroupDTOTest {

    @Test
    public void testGettersAndSetters() {
        // Create instances of CustomerDTO
        CustomerDTO customer1 = new CustomerDTO();
        customer1.setCustomerId(1L);
        customer1.setCustomerName("John Doe");

        CustomerDTO customer2 = new CustomerDTO();
        customer2.setCustomerId(2L);
        customer2.setCustomerName("Jane Doe");

        // Create CustomerGroupDTO instance
        CustomerGroupDTO groupDTO = new CustomerGroupDTO();
        groupDTO.setGroupId(1);
        groupDTO.setGroupName("Group 1");

        // Create a list of customers and add customers to it
        List<CustomerDTO> customers = new ArrayList<>();
        customers.add(customer1);
        customers.add(customer2);

        // Set the list of customers in CustomerGroupDTO
        groupDTO.setCustomers(customers);

        // Assert values using getters
        assertEquals(1, groupDTO.getGroupId());
        assertEquals("Group 1", groupDTO.getGroupName());
        assertEquals(customers, groupDTO.getCustomers());
    }

    @Test
    public void testEmptyConstructor() {
        // Create CustomerGroupDTO instance using empty constructor
        CustomerGroupDTO groupDTO = new CustomerGroupDTO();

        // Assert not null
        assertNotNull(groupDTO);
    }

    @Test
    public void testEquality() {
        // Create instances of CustomerDTO
        CustomerDTO customer1 = new CustomerDTO();
        customer1.setCustomerId(1L);
        customer1.setCustomerName("John Doe");

        CustomerDTO customer2 = new CustomerDTO();
        customer2.setCustomerId(2L);
        customer2.setCustomerName("Jane Doe");

        // Create CustomerGroupDTO instances with the same customers
        CustomerGroupDTO groupDTO1 = new CustomerGroupDTO();
        groupDTO1.setGroupId(1);
        groupDTO1.setGroupName("Group 1");
        groupDTO1.setCustomers(List.of(customer1, customer2));

        CustomerGroupDTO groupDTO2 = new CustomerGroupDTO();
        groupDTO2.setGroupId(1);
        groupDTO2.setGroupName("Group 1");
        groupDTO2.setCustomers(List.of(customer1, customer2));

        // Assert equality
        assertEquals(groupDTO1, groupDTO2);
    }

    @Test
    public void testNotEqual() {
        // Create instances of CustomerDTO with different values
        CustomerDTO customer1 = new CustomerDTO();
        customer1.setCustomerId(1L);
        customer1.setCustomerName("John Doe");

        CustomerDTO customer2 = new CustomerDTO();
        customer2.setCustomerId(2L);
        customer2.setCustomerName("Jane Doe");

        // Create CustomerGroupDTO instances with different customers
        CustomerGroupDTO groupDTO1 = new CustomerGroupDTO();
        groupDTO1.setGroupId(1);
        groupDTO1.setGroupName("Group 1");
        groupDTO1.setCustomers(List.of(customer1));

        CustomerGroupDTO groupDTO2 = new CustomerGroupDTO();
        groupDTO2.setGroupId(2);
        groupDTO2.setGroupName("Group 2");
        groupDTO2.setCustomers(List.of(customer2));

        // Assert not equal
        assertNotEquals(groupDTO1, groupDTO2);
    }
}
