package com.maveric.csp;
import org.junit.jupiter.api.Test;

import com.maveric.csp.dtos.RemarkDTO;

import static org.junit.jupiter.api.Assertions.*;

public class RemarkDTOTest {

    @Test
    public void testGettersAndSetters() {
        RemarkDTO remarkDTO = new RemarkDTO();
        remarkDTO.setRemarkId(1);
        remarkDTO.setCreatedDate("2024-02-29");
        remarkDTO.setRemark("This is a test remark");
        remarkDTO.setSessionId(12345);

        assertEquals(1, remarkDTO.getRemarkId());
        assertEquals("2024-02-29", remarkDTO.getCreatedDate());
        assertEquals("This is a test remark", remarkDTO.getRemark());
        assertEquals(12345, remarkDTO.getSessionId());
    }

    @Test
    public void testEmptyConstructor() {
        RemarkDTO remarkDTO = new RemarkDTO();
        assertNotNull(remarkDTO);
    }

    @Test
    public void testEquality() {
        RemarkDTO remarkDTO1 = new RemarkDTO();
        remarkDTO1.setRemarkId(1);
        remarkDTO1.setCreatedDate("2024-02-29");
        remarkDTO1.setRemark("This is a test remark");
        remarkDTO1.setSessionId(12345);

        RemarkDTO remarkDTO2 = new RemarkDTO();
        remarkDTO2.setRemarkId(1);
        remarkDTO2.setCreatedDate("2024-02-29");
        remarkDTO2.setRemark("This is a test remark");
        remarkDTO2.setSessionId(12345);

        assertEquals(remarkDTO1, remarkDTO2);
    }

    @Test
    public void testNotEqual() {
        RemarkDTO remarkDTO1 = new RemarkDTO();
        remarkDTO1.setRemarkId(1);
        remarkDTO1.setCreatedDate("2024-02-29");
        remarkDTO1.setRemark("This is a test remark");
        remarkDTO1.setSessionId(12345);

        RemarkDTO remarkDTO2 = new RemarkDTO();
        remarkDTO2.setRemarkId(2);
        remarkDTO2.setCreatedDate("2024-02-28");
        remarkDTO2.setRemark("Another test remark");
        remarkDTO2.setSessionId(54321);

        assertNotEquals(remarkDTO1, remarkDTO2);
    }
}
